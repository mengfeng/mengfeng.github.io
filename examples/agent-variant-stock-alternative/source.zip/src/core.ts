export type Selection = {
  readonly color: 'linen' | 'charcoal'
  readonly size: 'S' | 'M'
}

export type Variant = Selection & {
  readonly id: string
  readonly stock: 'available' | 'sold-out' | 'unknown'
}

export type Snapshot = {
  readonly id: string
  readonly groupId: string
  readonly complete: boolean
  readonly variants: readonly Variant[]
}

export type Current = {
  readonly kind: Variant['stock'] | 'not-offered' | 'conflict'
}

export type Recommendation =
  | { readonly kind: 'none' | 'rejected' }
  | { readonly kind: 'ready'; readonly variant: Variant }

export function resolveCurrent(snapshot: Snapshot, selected: Selection): Current {
  const matches = snapshot.variants.filter(row => row.color === selected.color && row.size === selected.size)
  if (matches.length > 1) return { kind: 'conflict' }
  if (matches.length === 1) return { kind: matches[0].stock }
  return { kind: snapshot.complete ? 'not-offered' : 'unknown' }
}

export function resolveRecommendation(snapshot: Snapshot, selected: Selection,
  allowColorChange: boolean, raw: unknown): Recommendation {
  const current = resolveCurrent(snapshot, selected)
  if (!allowColorChange || !['sold-out', 'not-offered'].includes(current.kind)) {
    return { kind: 'none' }
  }

  if (typeof raw !== 'object' || raw === null || Array.isArray(raw) ||
    !('snapshotId' in raw) || raw.snapshotId !== snapshot.id ||
    !('groupId' in raw) || raw.groupId !== snapshot.groupId ||
    !('requestedColor' in raw) || raw.requestedColor !== selected.color ||
    !('requestedSize' in raw) || raw.requestedSize !== selected.size ||
    !('variantId' in raw) || typeof raw.variantId !== 'string') {
    return { kind: 'rejected' }
  }

  const matches = snapshot.variants.filter(row => row.id === raw.variantId)
  if (matches.length !== 1) return { kind: 'rejected' }
  const variant = matches[0]
  if (variant.color === selected.color || variant.size !== selected.size ||
    resolveCurrent(snapshot, variant).kind !== 'available') {
    return { kind: 'rejected' }
  }
  return { kind: 'ready', variant }
}
