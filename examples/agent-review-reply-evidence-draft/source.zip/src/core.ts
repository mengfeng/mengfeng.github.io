export type Scenario = 'ready' | 'missing_order' | 'policy_timeout' | 'order_mismatch' | 'stale_review' | 'forged_claim'
export type Claim = 'acknowledge' | 'order_delivered' | 'return_route' | 'refund_approved'
export type Review = { id: string; revision: number; orderId: string; text: string; sourceId: string }
export type Order = { id: string; status: 'delivered'; sourceId: string }
export type Policy = { allowsReturnRequest: boolean; sourceId: string }
export type Result<T> = { kind: 'ok'; value: T } | { kind: 'missing' | 'timeout'; message: string }
export type Evidence = { review: Result<Review>; order: Result<Order>; policy: Result<Policy> }
export type Candidate = { revision: number; claims: Claim[]; sourceIds: string[] }
export type Assessment = { state: 'ready' | 'partial' | 'blocked' | 'stale' | 'rejected'; message: string; claims: Claim[]; sourceIds: string[]; draft: string }

const reviewFixture = (revision: number): Review => ({
  id: 'REV-DEMO-08', revision, orderId: 'ORD-DEMO-17',
  text: '包裹到手时外盒破损，商品也有划痕，怎么处理？',
  sourceId: `review.read#REV-DEMO-08@r${revision}`
})

function settle<T>(result: PromiseSettledResult<T>, failure: 'missing' | 'timeout'): Result<T> {
  return result.status === 'fulfilled'
    ? { kind: 'ok', value: result.value }
    : { kind: failure, message: failure === 'missing' ? '记录未找到' : '读取超时' }
}

export async function collect(scenario: Scenario, revision: number): Promise<Evidence> {
  // 三个函数都是内存夹具；这里没有网络请求或真实订单数据。
  const results = await Promise.allSettled([
    Promise.resolve(reviewFixture(revision)),
    scenario === 'missing_order' ? Promise.reject(new Error('fixture missing'))
      : Promise.resolve<Order>({ id: scenario === 'order_mismatch' ? 'ORD-DEMO-99' : 'ORD-DEMO-17', status: 'delivered', sourceId: 'order.read#ORD-DEMO-17@r3' }),
    scenario === 'policy_timeout' ? Promise.reject(new Error('fixture timeout'))
      : Promise.resolve<Policy>({ allowsReturnRequest: true, sourceId: 'policy.read#damage@r2' })
  ] as const)
  return {
    review: settle(results[0], 'missing'),
    order: settle(results[1], 'missing'),
    policy: settle(results[2], 'timeout')
  }
}

function expected(evidence: Evidence, currentRevision: number): Assessment {
  if (evidence.review.kind !== 'ok') return { state: 'blocked', message: '评价未读取成功', claims: [], sourceIds: [], draft: '' }
  const review = evidence.review.value
  if (review.revision !== currentRevision) return { state: 'stale', message: '评价已经更新，请重新读取', claims: [], sourceIds: [], draft: '' }
  if (evidence.order.kind === 'ok' && evidence.order.value.id !== review.orderId) {
    return { state: 'blocked', message: '订单与评价不匹配，停止生成草稿', claims: [], sourceIds: [], draft: '' }
  }
  const claims: Claim[] = ['acknowledge']
  const sourceIds = [review.sourceId]
  if (evidence.order.kind === 'ok') {
    claims.push('order_delivered')
    sourceIds.push(evidence.order.value.sourceId)
  }
  if (evidence.policy.kind === 'ok' && evidence.policy.value.allowsReturnRequest) {
    claims.push('return_route')
    sourceIds.push(evidence.policy.value.sourceId)
  }
  const state = evidence.order.kind === 'ok' && evidence.policy.kind === 'ok' ? 'ready' : 'partial'
  return { state, message: state === 'ready' ? '证据齐全，等待人工审阅' : '证据不全，仅生成有限草稿', claims, sourceIds, draft: '' }
}

export function mockCandidate(evidence: Evidence, currentRevision: number, forged = false): Candidate {
  // 固定模拟模型候选；生产接入时必须将真实模型输出送入 verify，而不能信任引用自述。
  const plan = expected(evidence, currentRevision)
  return {
    revision: currentRevision,
    claims: forged ? [...plan.claims, 'refund_approved'] : [...plan.claims],
    sourceIds: [...plan.sourceIds]
  }
}

const sentences: Record<Exclude<Claim, 'refund_approved'>, string> = {
  acknowledge: '很抱歉这次包裹和商品状况影响了您的体验。',
  order_delivered: '我们查看了这笔演示订单，当前记录为已送达。',
  return_route: '如果您希望继续处理，可以在订单页面发起售后申请，由人工核实商品情况。'
}

export function verify(evidence: Evidence, candidate: Candidate, currentRevision: number): Assessment {
  const plan = expected(evidence, currentRevision)
  if (plan.state === 'blocked' || plan.state === 'stale') return plan
  const same = (a: readonly string[], b: readonly string[]) => a.length === b.length && a.every((value, index) => value === b[index])
  if (candidate.revision !== currentRevision || !same(candidate.claims, plan.claims) || !same(candidate.sourceIds, plan.sourceIds)) {
    return { state: 'rejected', message: '候选包含未核实主张、错误引用或旧版评价，已拒绝显示', claims: [], sourceIds: [], draft: '' }
  }
  // 受控句子表生成显示文字；候选文本不直接进入页面。
  const draft = candidate.claims.map(claim => sentences[claim as Exclude<Claim, 'refund_approved'>]).join(' ')
  return { ...plan, draft }
}
