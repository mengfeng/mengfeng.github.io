export type Unit = 'graphemes' | 'utf8Bytes'
export type Rule = {
  readonly id: string
  readonly unit: Unit
  readonly limit: number
}

const segmenter = typeof Intl.Segmenter === 'function'
  ? new Intl.Segmenter('zh-CN', { granularity: 'grapheme' })
  : undefined
const encoder = typeof TextEncoder === 'function' ? new TextEncoder() : undefined

export function measure(text: string): Record<Unit, number | undefined> {
  let graphemes: number | undefined
  if (segmenter) {
    graphemes = 0
    for (const _segment of segmenter.segment(text)) graphemes++
  }
  return { graphemes, utf8Bytes: encoder?.encode(text).length }
}

export type Assessment =
  | { readonly kind: 'unavailable' }
  | { readonly kind: 'empty' | 'fits' | 'over-limit'; readonly used: number }

export function assess(text: string, rule: Rule, counts = measure(text)): Assessment {
  const used = counts[rule.unit]
  if (used === undefined) return { kind: 'unavailable' }
  if (!text.trim()) return { kind: 'empty', used }
  if (used <= rule.limit) return { kind: 'fits', used }
  return { kind: 'over-limit', used }
}

export type Suggestion =
  | { readonly kind: 'idle' | 'missing' | 'stale' | 'invalid' | 'over-limit' }
  | { readonly kind: 'ready'; readonly text: string; readonly used: number }

export function verifySuggestion(source: string, rule: Rule, candidate: unknown): Suggestion {
  if (assess(source, rule).kind !== 'over-limit') return { kind: 'idle' }
  if (candidate === undefined) return { kind: 'missing' }
  if (typeof candidate !== 'object' || candidate === null || Array.isArray(candidate)
    || !('ruleId' in candidate) || typeof candidate.ruleId !== 'string'
    || !('source' in candidate) || typeof candidate.source !== 'string'
    || !('text' in candidate) || typeof candidate.text !== 'string') {
    return { kind: 'invalid' }
  }
  if (candidate.ruleId !== rule.id || candidate.source !== source) return { kind: 'stale' }

  const result = assess(candidate.text, rule)
  if (result.kind === 'over-limit') return { kind: 'over-limit' }
  if (result.kind !== 'fits') return { kind: 'invalid' }
  return { kind: 'ready', text: candidate.text, used: result.used }
}
