import { createApp, ref } from 'vue'
import { collect, mockCandidate, verify, type Answer, type Scenario, type Snapshot } from './core'

const scenarios: { value: Scenario; label: string }[] = [
  { value: 'reviewing', label: '申请已提交，正在审核' },
  { value: 'processing', label: '审核通过，渠道处理中' },
  { value: 'channel_done', label: '渠道标记完成，实际到账未知' },
  { value: 'not_found', label: '退款单未找到' },
  { value: 'channel_timeout', label: '支付渠道查询超时' },
  { value: 'conflict', label: '退款单与渠道状态冲突' },
  { value: 'stale', label: '证据查询时间过期' }
]
const reviewLabels = { submitted: '申请已提交', reviewing: '正在审核', approved: '审核通过', rejected: '审核未通过' }
const channelLabels = { not_started: '尚未开始', processing: '渠道处理中', channel_complete: '渠道标记完成' }

createApp({
  setup() {
    const scenario = ref<Scenario>('reviewing')
    const pageVersion = ref(7)
    const forged = ref(false)
    const busy = ref(false)
    const snapshot = ref<Snapshot | null>(null)
    const answer = ref<Answer | null>(null)
    function clear(): void { snapshot.value = null; answer.value = null }
    async function query(): Promise<void> {
      busy.value = true
      clear()
      try {
        const evidence = await collect(scenario.value, pageVersion.value)
        const candidate = mockCandidate(evidence)
        snapshot.value = evidence
        answer.value = verify(evidence, forged.value
          ? { ...candidate, sourceIds: [...candidate.sourceIds, 'refund.write#fake'] }
          : candidate)
      } finally { busy.value = false }
    }
    function changeVersion(): void {
      pageVersion.value += 1
      if (answer.value) {
        answer.value = { verdict: 'stale', headline: '页面订单版本已变化', detail: '旧快照不能继续解释当前售后状态，请重新查询。', sourceIds: [], steps: answer.value.steps }
      }
    }
    return { scenarios, scenario, pageVersion, forged, busy, snapshot, answer, reviewLabels, channelLabels, clear, query, changeVersion }
  },
  template: `
    <main class="shell">
      <header class="hero"><span class="eyebrow">AGENT / REFUND STATUS</span><h1>退款进度到哪一步？</h1><p>把申请、审核、支付渠道处理和实际到账拆开解释。所有记录和回答均为虚构的本地演示，没有真实模型调用或退款操作。</p></header>
      <section class="panel controls" aria-labelledby="scene-title"><h2 id="scene-title">选择演示场景</h2><div class="control-grid"><label>场景<select v-model="scenario" @change="clear"><option v-for="item in scenarios" :key="item.value" :value="item.value">{{ item.label }}</option></select></label><label class="check"><input type="checkbox" v-model="forged">注入伪造引用</label><div class="version">页面版本 <strong>{{ pageVersion }}</strong></div></div><div class="actions"><button @click="query" :disabled="busy">{{ busy ? '查询中…' : '查询并核对' }}</button><button class="quiet" @click="changeVersion">模拟页面状态变化</button></div><p class="fine">两个工具是本地只读 Promise。点击后才会生成本轮证据；页面版本变化会使旧回答失效。</p></section>
      <div v-if="snapshot && answer" class="grid"><section class="panel evidence"><h2>本轮只读证据</h2><dl><dt>退款单</dt><dd v-if="snapshot.refund.ok">{{ reviewLabels[snapshot.refund.value.status] }} · v{{ snapshot.refund.value.version }}<small>{{ snapshot.refund.value.sourceId }}</small></dd><dd v-else>未找到演示退款单</dd><dt>支付渠道</dt><dd v-if="snapshot.refund.ok && snapshot.channel.ok">{{ channelLabels[snapshot.channel.value.status] }}<small>{{ snapshot.channel.value.sourceId }}</small></dd><dd v-else-if="snapshot.refund.ok">查询超时</dd><dd v-else>退款单未核对，渠道记录不展示</dd></dl><p class="fine">示例编号 RF-DEMO-024 · 金额与时间均为固定演示数据</p></section><section class="panel answer"><div class="panel-head"><h2>Agent 核验后回答</h2><span class="badge" :class="answer.verdict">{{ {ready:'已核对',partial:'部分已知',conflict:'需人工核对',stale:'证据失效',unknown:'暂不能定位'}[answer.verdict] }}</span></div><h3 aria-live="polite">{{ answer.headline }}</h3><p>{{ answer.detail }}</p><p class="fine">引用：<span v-if="!answer.sourceIds.length">无</span><code v-for="source in answer.sourceIds" :key="source">{{ source }}</code></p></section></div>
      <section v-if="answer" class="panel journey"><h2>四个不同阶段</h2><ol><li v-for="(step,index) in answer.steps" :key="step"><span class="step-number">{{ index + 1 }}</span><span>{{ step }}</span><small v-if="index === 3">本示例始终没有本人账户到账证据</small></li></ol><p class="fine">渠道标记完成只代表渠道记录；本人实际到账需核对自己的支付账户或银行账单。</p></section>
      <footer>离线教学示例 · 无真实模型调用 · 无真实退款、付款或对外消息</footer>
    </main>`
}).mount('#app')
