export type Scenario = 'ready' | 'invalid_window' | 'ineligible_product' | 'no_stack' | 'coupon_timeout' | 'version_conflict' | 'stale_evidence' | 'missing_activity'
export type ToolResult<T> = { ok: true; value: T } | { ok: false; reason: 'missing' | 'timeout' | 'not_requested' }
export type Activity = {
  sourceId: string; id: string; revision: number; sku: string
  startsAt: string; endsAt: string; checkedAt: string
}
export type Product = {
  sourceId: string; sku: string; activityRevision: number
  eligible: boolean; checkedAt: string
}
export type Coupon = {
  sourceId: string; sku: string; activityRevision: number
  stackable: boolean; checkedAt: string
}
export type Snapshot = {
  activity: ToolResult<Activity>; product: ToolResult<Product>; coupon: ToolResult<Coupon>
  couponRequested: boolean; pageRevision: number
}
export type Verdict = 'ready' | 'blocked' | 'partial' | 'conflict' | 'stale' | 'unknown'
export type Reason = 'ready' | 'ready_without_coupon' | 'invalid_window' | 'ineligible_product' | 'no_stack' | 'coupon_timeout' | 'version_conflict' | 'stale_evidence' | 'missing_activity' | 'page_changed' | 'unverified_claim'
export type Assessment = { verdict: Verdict; reason: Reason; sourceIds: string[] }
export type Candidate = { verdict: Verdict; sourceIds: string[]; message: string }
export type Answer = Assessment & { headline: string; detail: string; checks: string[] }

const NOW = Date.parse('2026-11-14T20:00:00+08:00')
const MAX_AGE_MS = 5 * 60 * 1000
const CHECKED_AT = '2026-11-14T19:59:00+08:00'
const STALE_AT = '2026-11-14T19:40:00+08:00'
const SKU = 'MUG-DEMO-17'

// These are fixed local fixtures. No merchant API, coupon service, publishing tool or model is called.
export async function readActivity(scenario: Scenario): Promise<Activity> {
  if (scenario === 'missing_activity') { throw new Error('missing') }
  return {
    sourceId: 'activity.read#ACT-DEMO-41-r7', id: 'ACT-DEMO-41', revision: 7, sku: SKU,
    startsAt: scenario === 'invalid_window' ? '2026-11-17T10:00:00+08:00' : '2026-11-15T10:00:00+08:00',
    endsAt: '2026-11-16T22:00:00+08:00',
    checkedAt: scenario === 'stale_evidence' ? STALE_AT : CHECKED_AT
  }
}

export async function readProduct(scenario: Scenario): Promise<Product> {
  return {
    sourceId: 'product.read#MUG-DEMO-17-r7', sku: SKU, activityRevision: 7,
    eligible: scenario !== 'ineligible_product', checkedAt: CHECKED_AT
  }
}

export async function readCoupon(scenario: Scenario): Promise<Coupon> {
  if (scenario === 'coupon_timeout') { throw new Error('timeout') }
  return {
    sourceId: scenario === 'version_conflict' ? 'coupon.read#CP-DEMO-8-r6' : 'coupon.read#CP-DEMO-8-r7',
    sku: SKU, activityRevision: scenario === 'version_conflict' ? 6 : 7,
    stackable: scenario !== 'no_stack', checkedAt: CHECKED_AT
  }
}

export async function collect(scenario: Scenario, couponRequested: boolean, pageRevision: number): Promise<Snapshot> {
  const [activity, product, coupon] = await Promise.allSettled([
    readActivity(scenario), readProduct(scenario),
    couponRequested ? readCoupon(scenario) : Promise.resolve(null)
  ] as const)
  return {
    activity: activity.status === 'fulfilled'
      ? { ok: true, value: activity.value } : { ok: false, reason: 'missing' },
    product: product.status === 'fulfilled'
      ? { ok: true, value: product.value } : { ok: false, reason: 'timeout' },
    coupon: !couponRequested ? { ok: false, reason: 'not_requested' }
      : coupon.status === 'fulfilled' && coupon.value !== null
        ? { ok: true, value: coupon.value } : { ok: false, reason: 'timeout' },
    couponRequested, pageRevision
  }
}

function isFresh(checkedAt: string): boolean {
  const elapsed = NOW - Date.parse(checkedAt)
  return Number.isFinite(elapsed) && elapsed >= 0 && elapsed <= MAX_AGE_MS
}

function validWindow(activity: Activity): boolean {
  const start = Date.parse(activity.startsAt)
  const end = Date.parse(activity.endsAt)
  return Number.isFinite(start) && Number.isFinite(end) && start < end
}

export function assess(snapshot: Snapshot, currentPageRevision: number): Assessment {
  if (snapshot.pageRevision !== currentPageRevision) {
    return { verdict: 'stale', reason: 'page_changed', sourceIds: [] }
  }
  if (!snapshot.activity.ok) {
    return { verdict: 'unknown', reason: 'missing_activity', sourceIds: [] }
  }
  const activity = snapshot.activity.value
  if (activity.revision !== snapshot.pageRevision) {
    return { verdict: 'stale', reason: 'page_changed', sourceIds: [] }
  }
  if (!isFresh(activity.checkedAt)) {
    return { verdict: 'stale', reason: 'stale_evidence', sourceIds: [] }
  }
  const activitySource = [activity.sourceId]
  if (!validWindow(activity)) {
    return { verdict: 'blocked', reason: 'invalid_window', sourceIds: activitySource }
  }
  if (!snapshot.product.ok) {
    return { verdict: 'partial', reason: 'ineligible_product', sourceIds: activitySource }
  }
  const product = snapshot.product.value
  const productSources = [activity.sourceId, product.sourceId]
  if (!isFresh(product.checkedAt)) {
    return { verdict: 'stale', reason: 'stale_evidence', sourceIds: [] }
  }
  if (product.sku !== activity.sku || product.activityRevision !== activity.revision) {
    return { verdict: 'conflict', reason: 'version_conflict', sourceIds: productSources }
  }
  if (!product.eligible) {
    return { verdict: 'blocked', reason: 'ineligible_product', sourceIds: productSources }
  }
  if (!snapshot.couponRequested) {
    return { verdict: 'ready', reason: 'ready_without_coupon', sourceIds: productSources }
  }
  if (!snapshot.coupon.ok) {
    return { verdict: 'partial', reason: 'coupon_timeout', sourceIds: productSources }
  }
  const coupon = snapshot.coupon.value
  const allSources = [...productSources, coupon.sourceId]
  if (!isFresh(coupon.checkedAt)) {
    return { verdict: 'stale', reason: 'stale_evidence', sourceIds: [] }
  }
  if (coupon.sku !== activity.sku || coupon.activityRevision !== activity.revision) {
    return { verdict: 'conflict', reason: 'version_conflict', sourceIds: allSources }
  }
  if (!coupon.stackable) {
    return { verdict: 'blocked', reason: 'no_stack', sourceIds: allSources }
  }
  return { verdict: 'ready', reason: 'ready', sourceIds: allSources }
}

export function mockCandidate(snapshot: Snapshot): Candidate {
  const assessment = assess(snapshot, snapshot.pageRevision)
  return {
    verdict: assessment.verdict, sourceIds: assessment.sourceIds,
    message: '固定模拟候选：不会直接显示，也没有真实模型调用。'
  }
}

export function verify(snapshot: Snapshot, candidate: Candidate, currentPageRevision: number): Answer {
  const expected = assess(snapshot, currentPageRevision)
  const checks = ['活动时间窗', '商品适用资格', '优惠券叠加规则']
  if (candidate.verdict !== expected.verdict ||
      candidate.sourceIds.length !== expected.sourceIds.length ||
      candidate.sourceIds.some((id, index) => id !== expected.sourceIds[index])) {
    return {
      verdict: 'conflict', reason: 'unverified_claim', sourceIds: [], checks,
      headline: '候选回答未通过核验',
      detail: '结论或引用与本轮证据不符，已拒绝展示。'
    }
  }
  const content: Record<Reason, [string, string]> = {
    unverified_claim: ['候选回答未通过核验', '结论或引用与本轮证据不符，已拒绝展示。'],
    ready: ['本轮预检通过', '时间窗有效、商品可参加、演示券允许叠加；这不代表活动已经发布。'],
    ready_without_coupon: ['本轮预检通过', '时间窗有效、商品可参加；本轮未申请叠加优惠券，未核对券规则。'],
    invalid_window: ['活动时间窗无效', '开始时间必须早于结束时间；请先修正草稿。'],
    ineligible_product: ['商品资格未通过', '演示商品不在本活动适用范围；不会自动替换商品。'],
    no_stack: ['优惠券不可叠加', '活动与演示券不能同时使用；应调整方案并重新核对。'],
    coupon_timeout: ['券规则尚未核实', '活动时间与商品资格已知，但券规则查询超时，不能批准叠加。'],
    version_conflict: ['记录版本不一致', '两份记录不属于同一版活动草稿，请重新读取。'],
    stale_evidence: ['证据已过期', '读到的记录超过演示时效阈值，请重新查询。'],
    missing_activity: ['活动记录未找到', '本地夹具未返回活动；不能据此断言真实系统没有该活动。'],
    page_changed: ['页面草稿已变化', '旧证据不能替当前页面版本背书，请重新读取。']
  }
  const [headline, detail] = content[expected.reason]
  return { ...expected, checks, headline, detail }
}
