import assert from 'node:assert/strict'
import { collect, demoSource, mockCandidate, protect, verify, type Scenario } from './src/core'

let checks = 0
function check(value: unknown, message: string) { assert.ok(value, message); checks++ }
async function run(scenario: Scenario) {
  const source = demoSource()
  const evidence = await collect(scenario)
  const candidate = mockCandidate(protect(source).masked, source.revision, evidence, scenario)
  return { source, evidence, candidate, result: verify(source, scenario === 'stale_source' ? 2 : 1, evidence, candidate) }
}

const ready = await run('ready')
check(ready.result.state === 'ready', 'complete evidence permits draft')
check(ready.result.draft.includes('ORD-DEMO-42'), 'original order ID restored')
check(ready.result.draft.includes('$29.90'), 'original amount restored')
check(ready.result.sourceIds.length === 2, 'both sources cited')
check(!ready.result.draft.includes('⟦'), 'no placeholders visible')
check(!ready.result.draft.toLowerCase().includes('refund'), 'no refund claim')
const protectedSource = protect(ready.source)
check(protectedSource.tokens.length === 2, 'exactly two protected fields')
check(!protectedSource.masked.includes('$29.90') && !protectedSource.masked.includes('ORD-DEMO-42'), 'masked input excludes fields')

for (const scenario of ['missing_token', 'changed_amount', 'refund_promise'] as const) {
  const item = await run(scenario)
  check(item.result.state === 'rejected', `${scenario} rejected`)
  check(item.result.draft === '', `${scenario} not displayed`)
}
for (const scenario of ['policy_timeout', 'glossary_timeout'] as const) {
  const item = await run(scenario)
  check(item.result.state === 'blocked', `${scenario} blocked`)
  check(item.result.draft === '', `${scenario} no draft`)
}
const stale = await run('stale_source')
check(stale.result.state === 'stale', 'updated source invalidates old candidate')
check(stale.result.draft === '', 'stale source no draft')
check(verify(ready.source, 1, ready.evidence, { ...ready.candidate, sourceIds: ['glossary.read#fake', 'policy.read#damage@r4'] }).state === 'rejected', 'forged source rejected')
check(verify(ready.source, 1, ready.evidence, { ...ready.candidate, text: ready.candidate.text + ' ⟦UNKNOWN⟧' }).state === 'rejected', 'unknown marker rejected')
check(verify(ready.source, 1, ready.evidence, { ...ready.candidate, text: ready.candidate.text.replace('manual review', 'automatic approval') }).state === 'rejected', 'changed glossary phrase rejected')
console.log(`${checks} offline assertions passed`)
