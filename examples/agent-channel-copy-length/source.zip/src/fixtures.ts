import type { Rule } from './core'

type Channel = Rule & { readonly name: string }
export const channels = [
  { id: 'card:v1', name: '站内推荐卡', unit: 'graphemes', limit: 12 },
  { id: 'partner:v3', name: '合作渠道短标题', unit: 'utf8Bytes', limit: 24 },
] as const satisfies readonly Channel[]

const original = '春季轻盈新色今日到店'
const shorter = '新色今日到店'
const validCandidate = { ruleId: channels[1].id, source: original, text: shorter }

export const samples = [
  { id: 'mixed', label: '同一句话在两个渠道有不同结果', channel: channels[0].id, text: original, candidate: validCandidate },
  { id: 'unicode', label: '组合字符与 emoji', channel: channels[0].id, text: 'Cafe\u0301 👩‍💻', candidate: undefined },
  { id: 'exact', label: '刚好 24 字节', channel: channels[1].id, text: '春季轻盈新色到店', candidate: undefined },
  { id: 'stale', label: 'Agent 用了旧规则', channel: channels[1].id, text: original,
    candidate: { ...validCandidate, ruleId: 'partner:v2' } },
  { id: 'long', label: 'Agent 改写后仍超限', channel: channels[1].id, text: original,
    candidate: { ...validCandidate, text: '当季轻盈全新颜色今天到店' } },
  { id: 'none', label: '当前没有可用建议', channel: channels[1].id, text: original, candidate: undefined },
  { id: 'blank', label: '空白标题', channel: channels[1].id, text: '  ', candidate: undefined },
] as const
