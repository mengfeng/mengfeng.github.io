export type Scope = {
  readonly sku: string
  readonly revision: string
  readonly field: 'assembledHeight'
}

export type Fact = Scope & {
  readonly id: string
  readonly title: string
  readonly amount: number
  readonly unit: 'mm' | 'cm'
  readonly state: 'active' | 'expired'
}

export type Snapshot = Scope & {
  readonly id: string
  readonly currentMm: number
  readonly facts: readonly Fact[]
}

type Evidence = Fact & { readonly mm: number }

export type Result =
  | { kind: 'missing' | 'conflict' | 'invalid'; evidence: readonly Evidence[] }
  | { kind: 'ready'; evidence: readonly Evidence[]; proposedMm: number }

function parseSuggestion(raw: unknown) {
  if (typeof raw !== 'object' || raw === null) return undefined
  if (!('snapshotId' in raw) || typeof raw.snapshotId !== 'string') return undefined
  if (!('sku' in raw) || typeof raw.sku !== 'string') return undefined
  if (!('field' in raw) || raw.field !== 'assembledHeight') return undefined
  if (!('heightMm' in raw) || typeof raw.heightMm !== 'number') return undefined
  if (!Number.isSafeInteger(raw.heightMm) || raw.heightMm <= 0) return undefined
  if (!('evidenceIds' in raw) || !Array.isArray(raw.evidenceIds)) return undefined
  const ids: readonly unknown[] = raw.evidenceIds
  if (ids.length === 0 || ids.length > 20) return undefined
  if (!ids.every((id): id is string => typeof id === 'string' && id.length > 0)) return undefined

  return { snapshotId: raw.snapshotId, sku: raw.sku, heightMm: raw.heightMm, evidenceIds: ids }
}

export function evaluate(snapshot: Snapshot, raw: unknown): Result {
  const evidence = snapshot.facts
    .filter(fact => fact.sku === snapshot.sku && fact.revision === snapshot.revision
      && fact.field === snapshot.field && fact.state === 'active')
    .map(fact => ({ ...fact, mm: fact.unit === 'cm' ? fact.amount * 10 : fact.amount }))

  if (evidence.length === 0) return { kind: 'missing', evidence }
  if (evidence.some(fact => !Number.isSafeInteger(fact.mm) || fact.mm <= 0)
    || new Set(evidence.map(fact => fact.id)).size !== evidence.length) {
    return { kind: 'invalid', evidence }
  }
  if (new Set(evidence.map(fact => fact.mm)).size > 1) return { kind: 'conflict', evidence }

  const suggestion = parseSuggestion(raw)
  if (!suggestion || suggestion.snapshotId !== snapshot.id || suggestion.sku !== snapshot.sku
    || suggestion.heightMm !== evidence[0].mm) return { kind: 'invalid', evidence }

  const byId = new Set(evidence.map(fact => fact.id))
  if (new Set(suggestion.evidenceIds).size !== suggestion.evidenceIds.length
    || !suggestion.evidenceIds.every(id => byId.has(id))) return { kind: 'invalid', evidence }

  return { kind: 'ready', proposedMm: suggestion.heightMm, evidence }
}
