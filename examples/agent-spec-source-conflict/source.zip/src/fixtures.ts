import type { Fact, Scope, Snapshot } from './core'

const scope: Scope = { sku: 'LAMP-MINT', revision: 'R2', field: 'assembledHeight' }
const supplier: Fact = { ...scope, id: 'S2', title: '供应商规格表', amount: 32, unit: 'cm', state: 'active' }
const accepted: Fact = { ...scope, id: 'Q2', title: '质检确认单', amount: 320, unit: 'mm', state: 'active' }
const retired: Fact = { ...supplier, id: 'S1', title: '已停用规格表', amount: 30, state: 'expired' }
const differentSku: Fact = { ...accepted, id: 'G2', sku: 'LAMP-GRAY', title: '灰色款确认单', amount: 350 }
const oldRevision: Fact = { ...supplier, id: 'R1', revision: 'R1', title: '旧版底座资料', amount: 30 }
const disagreement: Fact = { ...accepted, amount: 340 }

function scenario(id: string, label: string, facts: readonly Fact[], overrides: Record<string, unknown> = {}) {
  const snapshot: Snapshot = { ...scope, id, currentMm: 300, facts }
  const suggestion: unknown = {
    snapshotId: id, sku: scope.sku, field: scope.field, heightMm: 320,
    evidenceIds: ['S2'], ...overrides,
  }
  return { id, label, snapshot, suggestion }
}

export const scenarios = [
  scenario('conflict', '有效资料冲突', [supplier, disagreement, retired]),
  scenario('ready', '不同单位，数值一致', [supplier, accepted, retired, differentSku, oldRevision]),
  scenario('missing', '没有有效资料', [retired, differentSku, oldRevision]),
  scenario('stale', 'Agent 引用旧快照', [supplier, accepted], { snapshotId: 'retired-snapshot' }),
  scenario('foreign', 'Agent 引用另一款 SKU', [supplier, accepted, differentSku], { evidenceIds: ['G2'] }),
  scenario('wrong', 'Agent 换算错误', [supplier, accepted], { heightMm: 32 }),
  scenario('malformed', 'Agent 返回结构错误', [supplier, accepted], { evidenceIds: 'S2' }),
]
