export type Scenario =
  | 'ready' | 'amount_over' | 'wrong_title' | 'wrong_source'
  | 'order_timeout' | 'profile_timeout' | 'policy_timeout'
  | 'stale_order' | 'new_refund' | 'malformed_candidate'

export type Order = {
  id: string
  revision: number
  currency: 'CNY'
  paidCents: number
  shippingCents: number
  refundedCents: number
  issuedCents: number
  sourceId: string
}

export type Profile = {
  title: string
  taxId: string
  sourceId: string
}

export type Policy = {
  rule: 'paid-minus-shipping-refunds-issued'
  currency: 'CNY'
  sourceId: string
}

export type Evidence<T> = { kind: 'ok'; value: T } | { kind: 'error'; message: string }
export type Collected = {
  order: Evidence<Order>
  profile: Evidence<Profile>
  policy: Evidence<Policy>
}

export type InvoiceDraft = {
  orderId: string
  title: string
  taxId: string
  amountCents: number
  currency: 'CNY'
  sourceIds: string[]
}

export type Assessment = {
  state: 'ready' | 'blocked' | 'stale' | 'rejected'
  message: string
  availableCents: number
  draft: InvoiceDraft | null
}

type Candidate = {
  orderId: string
  orderRevision: number
  taxId: string
  currency: 'CNY'
  amountCents: number
  sourceIds: string[]
}

function result<T>(settled: PromiseSettledResult<T>, name: string): Evidence<T> {
  if (settled.status === 'rejected') {
    return { kind: 'error', message: `${name}读取失败（固定模拟）` }
  }
  return { kind: 'ok', value: settled.value }
}

function readOrder(scenario: Scenario, revision: number): Promise<Order> {
  if (scenario === 'order_timeout') {
    return Promise.reject(new Error('simulated timeout'))
  }
  const actualRevision = scenario === 'stale_order' ? revision - 1 : revision
  return Promise.resolve({
    id: 'ORD-DEMO-72', revision: actualRevision, currency: 'CNY',
    paidCents: 25900, shippingCents: 1200,
    refundedCents: scenario === 'new_refund' ? 13000 : 3000,
    issuedCents: 5000, sourceId: `order.read#72@r${actualRevision}`
  })
}

function readProfile(scenario: Scenario): Promise<Profile> {
  if (scenario === 'profile_timeout') {
    return Promise.reject(new Error('simulated timeout'))
  }
  return Promise.resolve({
    title: '演示科技有限公司', taxId: 'DEMO-TAX-ID',
    sourceId: 'profile.read#demo@r2'
  })
}

function readPolicy(scenario: Scenario): Promise<Policy> {
  if (scenario === 'policy_timeout') {
    return Promise.reject(new Error('simulated timeout'))
  }
  return Promise.resolve({
    rule: 'paid-minus-shipping-refunds-issued', currency: 'CNY',
    sourceId: 'policy.read#invoice@r4'
  })
}

export async function collect(scenario: Scenario, revision: number): Promise<Collected> {
  const [order, profile, policy] = await Promise.allSettled([
    readOrder(scenario, revision), readProfile(scenario), readPolicy(scenario)
  ] as const)
  return {
    order: result(order, '订单'),
    profile: result(profile, '抬头资料'),
    policy: result(policy, '开票规则')
  }
}

export function availableCents(order: Order): number {
  const parts = [order.paidCents, order.shippingCents, order.refundedCents, order.issuedCents]
  if (parts.some(value => !Number.isSafeInteger(value) || value < 0)) {
    return -1
  }
  const remaining = order.paidCents - order.shippingCents - order.refundedCents - order.issuedCents
  return Number.isSafeInteger(remaining) ? remaining : -1
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

export function parseCandidate(value: unknown): Candidate | null {
  if (!isRecord(value)) {
    return null
  }
  if (typeof value.orderId !== 'string' || !/^ORD-DEMO-\d+$/.test(value.orderId)) {
    return null
  }
  if (typeof value.orderRevision !== 'number' || !Number.isSafeInteger(value.orderRevision) || value.orderRevision < 1) {
    return null
  }
  if (typeof value.taxId !== 'string' || value.taxId.length > 60) {
    return null
  }
  if (value.currency !== 'CNY' || typeof value.amountCents !== 'number' ||
      !Number.isSafeInteger(value.amountCents) || value.amountCents <= 0) {
    return null
  }
  if (!Array.isArray(value.sourceIds) || value.sourceIds.length !== 3) {
    return null
  }
  const sourceIds: string[] = []
  for (const id of value.sourceIds as unknown[]) {
    if (typeof id !== 'string' || id.length > 80) {
      return null
    }
    sourceIds.push(id)
  }
  return {
    orderId: value.orderId, orderRevision: value.orderRevision,
    taxId: value.taxId, currency: value.currency,
    amountCents: value.amountCents, sourceIds
  }
}

export function mockCandidate(scenario: Scenario, revision: number): unknown {
  const candidate = {
    orderId: 'ORD-DEMO-72', orderRevision: revision,
    taxId: scenario === 'wrong_title' ? 'DEMO-TAX-OTHER' : 'DEMO-TAX-ID',
    currency: 'CNY', amountCents: scenario === 'amount_over' ? 18700 : 16700,
    sourceIds: [
      `order.read#72@r${revision}`, 'profile.read#demo@r2',
      scenario === 'wrong_source' ? 'policy.read#other@r4' : 'policy.read#invoice@r4'
    ]
  }
  if (scenario === 'malformed_candidate') {
    return { ...candidate, amountCents: '167.00' }
  }
  return candidate
}

function assessment(state: Assessment['state'], message: string, available: number): Assessment {
  return { state, message, availableCents: available, draft: null }
}

export function verify(evidence: Collected, currentRevision: number, rawCandidate: unknown): Assessment {
  if (evidence.order.kind !== 'ok' || evidence.profile.kind !== 'ok' || evidence.policy.kind !== 'ok') {
    return assessment('blocked', '只读证据未全部取得；先恢复查询，不生成开票草稿。', -1)
  }
  const { order, profile, policy } = {
    order: evidence.order.value, profile: evidence.profile.value, policy: evidence.policy.value
  }
  if (order.revision !== currentRevision) {
    return assessment('stale', '订单已更新；旧快照不能用于本轮申请。', -1)
  }
  const available = availableCents(order)
  if (available < 0 || policy.rule !== 'paid-minus-shipping-refunds-issued' || policy.currency !== order.currency) {
    return assessment('rejected', '金额数据或规则版本不一致；请人工核对。', -1)
  }
  const candidate = parseCandidate(rawCandidate)
  if (candidate === null) {
    return assessment('rejected', '模拟候选结构无效；没有生成可确认草稿。', available)
  }
  if (candidate.orderRevision !== currentRevision) {
    return assessment('stale', '候选使用的订单版本已过期。', available)
  }
  const expectedSources = [order.sourceId, profile.sourceId, policy.sourceId]
  if (candidate.sourceIds.some((id, index) => id !== expectedSources[index])) {
    return assessment('rejected', '候选引用与本轮工具结果不匹配。', available)
  }
  if (candidate.orderId !== order.id || candidate.taxId !== profile.taxId || candidate.currency !== order.currency) {
    return assessment('rejected', '订单、抬头或币种与已读取资料不一致。', available)
  }
  if (candidate.amountCents > available) {
    return assessment('rejected', '申请金额超过本轮剩余可开金额。', available)
  }
  return {
    state: 'ready', message: '结构和演示规则通过，仍须人工确认真实开票资格。',
    availableCents: available,
    draft: {
      orderId: order.id, title: profile.title, taxId: profile.taxId,
      amountCents: candidate.amountCents, currency: order.currency,
      sourceIds: expectedSources
    }
  }
}

export function formatCny(cents: number): string {
  if (!Number.isSafeInteger(cents) || cents < 0) {
    return '—'
  }
  return `¥${(cents / 100).toFixed(2)}`
}
