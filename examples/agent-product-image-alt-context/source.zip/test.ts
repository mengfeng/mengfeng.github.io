import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { proposeAlt } from './src/core'
import { scenarios } from './src/fixtures'

const expectations = [
  ['gallery', { kind: 'ready', alt: '钴蓝色马克杯，右侧有圆形杯柄，杯内为白色' }],
  ['decoration', { kind: 'ready', alt: '' }],
  ['link', { kind: 'ready', alt: '查看马克杯规格' }],
  ['wrong-role', { kind: 'review', reason: 'purpose' }],
  ['unsupported', { kind: 'review', reason: 'facts' }],
  ['stale', { kind: 'review', reason: 'stale' }],
  ['wrong-place', { kind: 'review', reason: 'stale' }],
] as const

for (const [id, expected] of expectations) {
  test(id, () => {
    const sample = scenarios.find(item => item.id === id)
    assert.ok(sample)
    assert.deepEqual(proposeAlt(sample.placement, sample.candidate), expected)
  })
}

const gallery = scenarios[0].placement
const galleryEnvelope = { placementId: gallery.id, imageRevision: gallery.imageRevision, role: gallery.role }

test('校验缺字段和非数组细节列表', () => {
  for (const input of [null, [], {}, { ...galleryEnvelope, detailIds: 'handle' }]) {
    assert.deepEqual(proposeAlt(gallery, input), { kind: 'review', reason: 'shape' })
  }
})

test('资讯图拒绝空引用、非字符串引用、重复引用和过多引用', () => {
  for (const detailIds of [[], [123], ['handle', 'handle'], ['handle', 'interior', 'something']]) {
    assert.deepEqual(proposeAlt(gallery, { ...galleryEnvelope, detailIds }), { kind: 'review', reason: 'facts' })
  }
})

test('输出沿用页面登记顺序，且不采用模型追加的自由文本', () => {
  const candidate = { ...galleryEnvelope, detailIds: ['interior', 'handle'], alt: '适用任意洗碗机' }
  assert.deepEqual(proposeAlt(gallery, candidate),
    { kind: 'ready', alt: '钴蓝色马克杯，右侧有圆形杯柄，杯内为白色' })
})

test('视觉细节可只选一个，未选细节不生成', () => {
  assert.deepEqual(proposeAlt(gallery, { ...galleryEnvelope, detailIds: ['interior'] }),
    { kind: 'ready', alt: '钴蓝色马克杯，杯内为白色' })
})

test('装饰图及功能图不采用附带的视觉细节引用', () => {
  for (const { placement } of scenarios.slice(1, 3)) {
    const candidate = { placementId: placement.id, imageRevision: placement.imageRevision,
      role: placement.role, detailIds: ['handle'] }
    assert.deepEqual(proposeAlt(placement, candidate), { kind: 'review', reason: 'facts' })
  }
})

test('功能图缺少受信操作名称时须复核', () => {
  const { placement, candidate } = scenarios[2]
  assert.equal(placement.role, 'functional')
  assert.deepEqual(proposeAlt({ ...placement, actionLabel: ' ' }, candidate), { kind: 'review', reason: 'facts' })
})
