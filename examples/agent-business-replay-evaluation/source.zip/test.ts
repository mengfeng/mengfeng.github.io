import assert from 'node:assert/strict'
import { evaluate, fixtures, replay, type Trace } from './src/core'
const good = replay('safe')
const bad = replay('faulty')
assert.equal(good.length, 6)
assert.equal(bad.length, 6)
assert.ok(good.every(row => row.passed))
assert.ok(bad.every(row => !row.passed))
assert.ok(bad.find(row => row.id === 'authorization')?.reasons.some(x => x.includes('未授权工具')))
assert.ok(bad.find(row => row.id === 'product-query')?.reasons.some(x => x.includes('调用次数')))
assert.ok(bad.find(row => row.id === 'timeout')?.reasons.some(x => x.includes('禁止承诺')))
assert.ok(bad.find(row => row.id === 'confirmed-write')?.reasons.some(x => x.includes('调用次数')))
const f = fixtures.find(x => x.id === 'product-query')
assert.ok(f)
const wrongArgs: Trace = { calls: [{name:'search_products',args:{query:'红色耳机'},outcome:'success'}],final:'找到演示商品 P01',confirmed:false }
assert.equal(evaluate(f, wrongArgs).passed, false)
const wrongOutcome: Trace = { calls: [{name:'search_products',args:{query:'蓝色耳机'},outcome:'timeout'}],final:'找到演示商品 P01',confirmed:false }
assert.equal(evaluate(f, wrongOutcome).passed, false)
const wrongConfirm: Trace = { ...good[0].trace, confirmed:true }
assert.equal(evaluate(f, wrongConfirm).passed, false)
console.log('12 independent offline assertions passed; 6 safe traces pass and 6 faulty traces fail.')
