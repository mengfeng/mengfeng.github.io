export type Scenario = 'ready' | 'missing_token' | 'changed_amount' | 'refund_promise' | 'policy_timeout' | 'glossary_timeout' | 'stale_source'
export type Source = { revision: number; text: string }
export type Token = { marker: '⟦ORDER⟧' | '⟦AMOUNT⟧'; value: string }
export type Glossary = { request: 'after-sales request'; review: 'manual review'; sourceId: string }
export type Policy = { allowsRequest: true; refundApproved: false; sourceId: string }
export type ReadResult<T> = { kind: 'ok'; value: T } | { kind: 'timeout'; message: string }
export type Evidence = { glossary: ReadResult<Glossary>; policy: ReadResult<Policy> }
export type Candidate = { sourceRevision: number; text: string; sourceIds: string[] }
export type Assessment = { state: 'ready' | 'blocked' | 'stale' | 'rejected'; message: string; draft: string; sourceIds: string[] }

export function demoSource(revision = 1): Source {
  return { revision, text: '订单 ORD-DEMO-42 的 $29.90 商品有划痕。请客户在订单页提交售后申请；我们会在人工核实后反馈结果。' }
}

export function protect(source: Source): { masked: string; tokens: Token[] } {
  const tokens: Token[] = []
  const masked = source.text.replace(/ORD-DEMO-\d+|\$\d+\.\d{2}/g, value => {
    const marker = value.startsWith('$') ? '⟦AMOUNT⟧' : '⟦ORDER⟧'
    tokens.push({ marker, value })
    return marker
  })
  if (tokens.length !== 2 || new Set(tokens.map(token => token.marker)).size !== 2) {
    throw new Error('演示源文必须且只能包含一个订单号和一个金额')
  }
  return { masked, tokens }
}

function settle<T>(result: PromiseSettledResult<T>): ReadResult<T> {
  return result.status === 'fulfilled' ? { kind: 'ok', value: result.value } : { kind: 'timeout', message: '本地夹具模拟读取超时' }
}

export async function collect(scenario: Scenario): Promise<Evidence> {
  // 固定内存夹具，不发网络请求。
  const [glossary, policy] = await Promise.allSettled([
    scenario === 'glossary_timeout' ? Promise.reject(new Error('fixture timeout'))
      : Promise.resolve<Glossary>({ request: 'after-sales request', review: 'manual review', sourceId: 'glossary.read#support@r2' }),
    scenario === 'policy_timeout' ? Promise.reject(new Error('fixture timeout'))
      : Promise.resolve<Policy>({ allowsRequest: true, refundApproved: false, sourceId: 'policy.read#damage@r4' })
  ] as const)
  return { glossary: settle(glossary), policy: settle(policy) }
}

export function mockCandidate(maskedSource: string, sourceRevision: number, evidence: Evidence, scenario: Scenario): Candidate {
  // 固定模拟模型响应；只接收占位符，不接收真实订单号或金额。
  if (/ORD-DEMO-\d+|\$\d+\.\d{2}/.test(maskedSource)) throw new Error('模拟翻译器收到了未遮盖字段')
  let text = 'We have noted the scratches on the ⟦AMOUNT⟧ item in order ⟦ORDER⟧. Please submit an after-sales request from the order page. We will update you after manual review.'
  if (scenario === 'missing_token') text = text.replace('⟦AMOUNT⟧', 'the item')
  if (scenario === 'changed_amount') text = text.replace('⟦AMOUNT⟧', '$39.90')
  if (scenario === 'refund_promise') text += ' Your refund has been approved.'
  const sourceIds = [
    ...(evidence.glossary.kind === 'ok' ? [evidence.glossary.value.sourceId] : []),
    ...(evidence.policy.kind === 'ok' ? [evidence.policy.value.sourceId] : [])
  ]
  return { sourceRevision, text, sourceIds }
}

export function verify(source: Source, currentRevision: number, evidence: Evidence, candidate: Candidate): Assessment {
  const fail = (state: Assessment['state'], message: string): Assessment => ({ state, message, draft: '', sourceIds: [] })
  if (source.revision !== currentRevision || candidate.sourceRevision !== currentRevision) return fail('stale', '源文已更新，请重新读取并翻译')
  if (evidence.glossary.kind !== 'ok' || evidence.policy.kind !== 'ok') return fail('blocked', '术语或政策未读到，本轮不生成对外草稿')
  if (!evidence.policy.value.allowsRequest || evidence.policy.value.refundApproved) return fail('blocked', '规则状态异常，请人工核对')
  const expectedSources = [evidence.glossary.value.sourceId, evidence.policy.value.sourceId]
  if (candidate.sourceIds.length !== expectedSources.length || candidate.sourceIds.some((id, i) => id !== expectedSources[i])) {
    return fail('rejected', '候选引用与本轮证据不一致')
  }
  const { tokens } = protect(source)
  const markers = [...candidate.text.matchAll(/⟦([^⟦⟧]+)⟧/g)].map(match => match[0])
  if (markers.length !== tokens.length || tokens.some(token => markers.filter(marker => marker === token.marker).length !== 1)) {
    return fail('rejected', '订单号或金额占位符缺失、重复或被替换')
  }
  if (candidate.text.length > 500 || /ORD-DEMO-\d+|\$\d+\.\d{2}/.test(candidate.text)) return fail('rejected', '候选写入了未经保护的编号或金额')
  if (/\brefund\b|\bapproved\b/i.test(candidate.text)) return fail('rejected', '候选加入了未经证实的退款承诺')
  if (!candidate.text.includes(evidence.glossary.value.request) || !candidate.text.includes(evidence.glossary.value.review)) {
    return fail('rejected', '候选未使用本轮核对的客服术语')
  }
  let draft = candidate.text
  for (const token of tokens) draft = draft.replace(token.marker, token.value)
  if (/⟦|⟧/.test(draft)) return fail('rejected', '候选仍有未知占位符')
  return { state: 'ready', message: '结构检查通过，仍需人工核对译意与政策', draft, sourceIds: expectedSources }
}
