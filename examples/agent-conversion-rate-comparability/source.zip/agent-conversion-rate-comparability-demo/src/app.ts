import { computed, createApp, ref } from 'vue'
import { acceptsProposal, compare, mockProposal, readEvidence, type Comparison, type Scenario } from './core'

const scenarios: ReadonlyArray<{ id: Scenario; label: string }> = [
  { id: 'comparable', label: '两周口径一致' },
  { id: 'scope_changed', label: '本周改用全站会话作分母' },
  { id: 'provisional', label: '本周数据仍在结算' },
  { id: 'empty', label: '本周无结账会话' },
  { id: 'zero_paid', label: '有结账会话，付款数为零' },
  { id: 'tool_unavailable', label: '本周快照未返回' },
  { id: 'wrong_delta', label: 'Agent 报错差值' },
  { id: 'wrong_source', label: 'Agent 引用了旧快照' }
]
type Blocked = Extract<Comparison, { kind: 'blocked' }>
const reasons: Record<Blocked['reason'], string> = {
  tool_unavailable: '本周快照未返回。查询成功后再比较。',
  provisional: '本周数据待结算。等两周都结算后再比较。',
  scope_changed: '两周统计口径不同。用同一版本重算后再比较。',
  empty: '有一周没有符合口径的会话，转化率未定义。',
  invalid_counts: '计数不符合指标约定，请核对数据工具。'
}
const percent = new Intl.NumberFormat('zh-CN', { style: 'percent', maximumFractionDigits: 2, minimumFractionDigits: 2 })
const points = new Intl.NumberFormat('zh-CN', { signDisplay: 'exceptZero', maximumFractionDigits: 2, minimumFractionDigits: 2 })

createApp({
  setup() {
    const selected = ref<Scenario>('comparable')
    const evidence = computed(() => readEvidence(selected.value))
    const comparison = computed(() => compare(evidence.value))
    const proposal = computed(() => mockProposal(selected.value))
    const accepted = computed(() => acceptsProposal(evidence.value, comparison.value, proposal.value))
    const snapshots = computed(() => [evidence.value.earlier, evidence.value.later])
    return { selected, scenarios, comparison, proposal, accepted, snapshots, reasons, percent, points,
      denominatorLabel: (value: string) => value === 'checkout_sessions' ? '进入结账的会话' : '全部会话' }
  },
  template: `
    <main class="shell">
      <header>
        <h1>这两周的转化率能比较吗？</h1>
        <p>切换虚构数据场景，查看两份快照和 Agent 建议的核对结果。</p>
      </header>
      <label for="scenario">演示场景</label>
      <select id="scenario" v-model="selected">
        <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
      </select>
      <div class="snapshots">
        <section class="panel" v-for="(snapshot, index) in snapshots" :key="index">
          <h2>{{ index === 0 ? '上周' : '本周' }}</h2>
          <template v-if="snapshot">
            <p class="muted">{{ snapshot.period }} · {{ snapshot.state === 'final' ? '已结算' : '待结算' }}</p>
            <dl>
              <div><dt>分母</dt><dd>{{ denominatorLabel(snapshot.definition.denominator) }}</dd></div>
              <div><dt>会话数</dt><dd>{{ snapshot.sessions.toLocaleString('zh-CN') }}</dd></div>
              <div><dt>有付款的会话数</dt><dd>{{ snapshot.paidSessions.toLocaleString('zh-CN') }}</dd></div>
              <div><dt>版本 / 时区</dt><dd>{{ snapshot.definition.revision }} · {{ snapshot.definition.timeZone }}</dd></div>
            </dl>
            <code>{{ snapshot.id }}</code>
          </template>
          <p class="muted" v-else>快照未返回。</p>
        </section>
      </div>
      <section class="panel result" aria-live="polite">
        <h2>核对结果</h2>
        <template v-if="comparison.kind === 'comparable'">
          <p class="numbers">{{ percent.format(comparison.earlierRate) }} → {{ percent.format(comparison.laterRate) }}</p>
          <p>差值 {{ points.format(comparison.deltaBp / 100) }} 个百分点</p>
          <p v-if="accepted" class="accepted">模拟建议已通过来源和数值核对，可以作为周报草稿。</p>
          <p v-else class="blocked">已保留可复算的差值。模拟建议的来源或差值不符，已拦截。</p>
        </template>
        <p v-else class="blocked">{{ reasons[comparison.reason] }}</p>
      </section>
      <details>
        <summary>查看固定的模拟 Agent 返回</summary>
        <pre>{{ JSON.stringify(proposal, null, 2) }}</pre>
      </details>
    </main>`
}).mount('#app')
