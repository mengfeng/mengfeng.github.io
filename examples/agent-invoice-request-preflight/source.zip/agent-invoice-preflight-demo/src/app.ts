import { createApp, ref } from 'vue'
import {
  availableCents, collect, formatCny, mockCandidate, verify,
  type Assessment, type Collected, type Scenario
} from './core'

createApp({
  setup() {
    const scenario = ref<Scenario>('ready')
    const revision = ref(3)
    const evidence = ref<Collected | null>(null)
    const assessment = ref<Assessment | null>(null)
    const candidateText = ref('')
    const pending = ref(false)
    const reviewed = ref(false)
    let requestId = 0

    function invalidate(): void {
      requestId++
      evidence.value = null
      assessment.value = null
      candidateText.value = ''
      reviewed.value = false
      pending.value = false
    }

    function updateOrder(): void {
      revision.value++
      invalidate()
    }

    async function run(): Promise<void> {
      const id = ++requestId
      const selected = scenario.value
      const currentRevision = revision.value
      pending.value = true
      reviewed.value = false
      try {
        const results = await collect(selected, currentRevision)
        if (id !== requestId) {
          return
        }
        const candidate = mockCandidate(selected, currentRevision)
        evidence.value = results
        candidateText.value = JSON.stringify(candidate, null, 2)
        assessment.value = verify(results, currentRevision, candidate)
      } catch {
        if (id === requestId) {
          assessment.value = {
            state: 'blocked', message: '演示运行失败，请刷新页面后重试。',
            availableCents: -1, draft: null
          }
        }
      } finally {
        if (id === requestId) {
          pending.value = false
        }
      }
    }

    return {
      scenario, revision, evidence, assessment, candidateText, pending, reviewed,
      invalidate, updateOrder, run, formatCny, availableCents
    }
  },
  template: `
  <main class="shell">
    <header class="hero">
      <div class="eyebrow">FRONTEND AGENT LAB · 09</div>
      <h1>开发票前，先核对三份证据</h1>
      <p>只读检查订单、开票抬头和演示规则；固定模拟候选通过核对后，也只进入待人工确认的本地草稿。没有真实开票或发送接口。</p>
    </header>
    <section class="panel">
      <h2>选择演示情况</h2>
      <label>预检场景
        <select v-model="scenario" @change="invalidate">
          <option value="ready">三份证据齐全</option>
          <option value="amount_over">候选金额超额</option>
          <option value="wrong_title">候选抬头不符</option>
          <option value="wrong_source">候选引用伪造</option>
          <option value="new_refund">新增退款导致额度减少</option>
          <option value="stale_order">订单版本已变化</option>
          <option value="order_timeout">订单查询超时</option>
          <option value="profile_timeout">抬头查询超时</option>
          <option value="policy_timeout">规则查询超时</option>
          <option value="malformed_candidate">候选字段类型错误</option>
        </select>
      </label>
      <div class="actions">
        <button @click="run" :disabled="pending">{{ pending ? '核对中…' : '读取证据并预检' }}</button>
        <button class="quiet" @click="updateOrder">模拟订单更新（当前 r{{ revision }}）</button>
      </div>
    </section>
    <div class="grid">
      <section class="panel">
        <h2>本轮只读证据</h2>
        <p class="fine" v-if="!evidence">点击预检后显示订单、抬头与规则。金额单位均为人民币分。</p>
        <template v-else>
          <div class="evidence">
            <b>订单</b>
            <template v-if="evidence.order.kind === 'ok'">
              <span class="ok">已读取</span><code>{{ evidence.order.value.sourceId }}</code>
              <p>实付 {{ formatCny(evidence.order.value.paidCents) }} · 运费 {{ formatCny(evidence.order.value.shippingCents) }}<br>已退款 {{ formatCny(evidence.order.value.refundedCents) }} · 已开 {{ formatCny(evidence.order.value.issuedCents) }}</p>
              <strong class="available">本轮剩余 {{ formatCny(availableCents(evidence.order.value)) }}</strong>
            </template>
            <span v-else class="error">{{ evidence.order.message }}</span>
          </div>
          <div class="evidence">
            <b>开票抬头</b>
            <template v-if="evidence.profile.kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence.profile.value.sourceId }}</code><p>{{ evidence.profile.value.title }} · {{ evidence.profile.value.taxId }}</p></template>
            <span v-else class="error">{{ evidence.profile.message }}</span>
          </div>
          <div class="evidence">
            <b>演示规则</b>
            <template v-if="evidence.policy.kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence.policy.value.sourceId }}</code><p>实付减运费、已退款和已开金额；只生成草稿。</p></template>
            <span v-else class="error">{{ evidence.policy.message }}</span>
          </div>
        </template>
      </section>
      <section class="panel">
        <div class="panel-head"><h2>申请草稿</h2><span v-if="assessment" class="badge" :class="assessment.state">{{ assessment.state }}</span></div>
        <p class="fine" v-if="!assessment">尚未生成。候选由本地固定函数模拟，并非真实模型输出。</p>
        <template v-else>
          <p class="notice">{{ assessment.message }}</p>
          <div class="draft" v-if="assessment.draft">
            <p><b>订单</b> {{ assessment.draft.orderId }}<br><b>抬头</b> {{ assessment.draft.title }}<br><b>演示税号</b> {{ assessment.draft.taxId }}<br><b>申请金额</b> {{ formatCny(assessment.draft.amountCents) }}</p>
            <div class="sources"><span v-for="id in assessment.draft.sourceIds" :key="id">{{ id }}</span></div>
            <label class="review"><input type="checkbox" v-model="reviewed">人工已核对（仅本地状态）</label>
          </div>
          <p class="fine" v-else>候选没有进入可确认草稿区。</p>
        </template>
        <details v-if="candidateText"><summary>查看模拟候选 JSON</summary><pre class="candidate">{{ candidateText }}</pre></details>
        <p class="fine">没有申请提交、开票、邮件或付款接口。</p>
      </section>
    </div>
    <footer>固定虚构数据 · Vue 3 + TypeScript · 结构预检不等于真实开票资格</footer>
  </main>`
}).mount('#app')
