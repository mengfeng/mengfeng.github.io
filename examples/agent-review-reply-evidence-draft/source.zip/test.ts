import assert from 'node:assert/strict'
import { collect, mockCandidate, verify, type Scenario } from './src/core'

let checks = 0
function check(condition: unknown, message: string) { assert.ok(condition, message); checks++ }

async function caseOf(scenario: Scenario) {
  const evidence = await collect(scenario, 1)
  const candidate = mockCandidate(evidence, 1, scenario === 'forged_claim')
  return { evidence, candidate, answer: verify(evidence, candidate, 1) }
}

const ready = await caseOf('ready')
check(ready.answer.state === 'ready', 'complete evidence should be ready')
check(ready.answer.claims.length === 3, 'three supported claims')
check(ready.answer.sourceIds.length === 3, 'three citations')
check(ready.answer.draft.includes('售后申请'), 'route sentence is present')
check(!ready.answer.draft.includes('退款获批'), 'no refund approval promise')
check(ready.evidence.order.kind === 'ok', 'order available')

const missing = await caseOf('missing_order')
check(missing.answer.state === 'partial', 'missing order is partial')
check(missing.evidence.order.kind === 'missing', 'order failure shown')
check(!missing.answer.draft.includes('已送达'), 'must not claim delivery')
check(missing.answer.sourceIds.length === 2, 'only available citations')

const timeout = await caseOf('policy_timeout')
check(timeout.answer.state === 'partial', 'policy timeout partial')
check(timeout.evidence.policy.kind === 'timeout', 'timeout shown')
check(!timeout.answer.draft.includes('售后申请'), 'must not claim policy route')
check(timeout.answer.sourceIds.length === 2, 'no policy citation')

const mismatch = await caseOf('order_mismatch')
check(mismatch.answer.state === 'blocked', 'mismatched order blocked')
check(mismatch.answer.draft === '', 'no draft for mismatch')

const stale = await caseOf('stale_review')
check(verify(stale.evidence, stale.candidate, 2).state === 'stale', 'review revision must match current')
check(verify(stale.evidence, stale.candidate, 2).draft === '', 'old review has no draft')

const forged = await caseOf('forged_claim')
check(forged.answer.state === 'rejected', 'unsupported refund claim rejected')
check(forged.answer.draft === '', 'forged claim not rendered')
check(verify(ready.evidence, { ...ready.candidate, sourceIds: ['order.write#fake'] }, 1).state === 'rejected', 'forged citation rejected')
check(verify(ready.evidence, { ...ready.candidate, revision: 0 }, 1).state === 'rejected', 'old candidate rejected')
check(verify(ready.evidence, { ...ready.candidate, claims: ['acknowledge'] }, 1).state === 'rejected', 'incomplete candidate rejected')

console.log(`${checks} offline assertions passed`)
