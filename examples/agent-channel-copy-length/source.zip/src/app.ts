import { computed, createApp, nextTick, ref } from 'vue'
import { assess, measure, verifySuggestion, type Unit } from './core'
import { channels, samples } from './fixtures'

const statuses = {
  unavailable: '当前环境无法按对应规则计数',
  empty: '请填写标题',
  fits: '长度符合规则',
  'over-limit': '标题超出渠道限制',
}
const messages = {
  idle: '',
  missing: '本次暂无改写建议，可继续手动编辑。',
  stale: '候选对应旧文案或旧规则，已保留当前输入。',
  invalid: '候选为空或格式无效，已保留当前输入。',
  'over-limit': '候选改写后仍超限，请继续编辑。',
}
const unitNames: Record<Unit, string> = { graphemes: '个字素簇', utf8Bytes: '字节' }

createApp({
  setup() {
    const scenario = ref<string>(samples[0].id)
    const channel = ref<string>(samples[0].channel)
    const draft = ref<string>(samples[0].text)
    const editor = ref<HTMLTextAreaElement | null>(null)
    const sample = computed(() => samples.find(item => item.id === scenario.value) ?? samples[0])
    const rule = computed(() => channels.find(item => item.id === channel.value) ?? channels[0])
    const counts = computed(() => measure(draft.value))
    const result = computed(() => assess(draft.value, rule.value, counts.value))
    const suggestion = computed(() => verifySuggestion(draft.value, rule.value, sample.value.candidate))

    function loadSample() {
      draft.value = sample.value.text
      channel.value = sample.value.channel
    }

    async function applySuggestion() {
      const current = suggestion.value
      if (current.kind === 'ready') {
        draft.value = current.text
        await nextTick()
        editor.value?.focus()
      }
    }

    return { scenario, channel, draft, editor, samples, channels, counts, rule, result, suggestion,
      statuses, messages, unitNames, loadSample, applySuggestion }
  },
  template: `
    <main>
      <header>
        <h1>渠道文案长度检查</h1>
        <p>两个虚构渠道使用不同计数规则。所有 Agent 候选均为固定样本。</p>
      </header>
      <div class="toolbar">
        <label for="scenario">示例</label>
        <select id="scenario" v-model="scenario" @change="loadSample">
          <option v-for="example in samples" :key="example.id" :value="example.id">{{ example.label }}</option>
        </select>
      </div>
      <div class="workspace">
        <section class="editor" aria-labelledby="editor-title">
          <h2 id="editor-title">当前文案</h2>
          <div class="fields">
            <label for="channel">目标渠道</label>
            <select id="channel" v-model="channel">
              <option v-for="item in channels" :key="item.id" :value="item.id">{{ item.name }}</option>
            </select>
            <label for="copy">标题</label>
            <textarea id="copy" ref="editor" v-model="draft" rows="3"></textarea>
          </div>
          <div role="status" class="status" :data-assessment="result.kind">
            <strong>{{ statuses[result.kind] }}</strong>
            <p v-if="result.kind !== 'unavailable'" data-testid="usage">
              已用 {{ result.used }} / {{ rule.limit }} {{ unitNames[rule.unit] }}
            </p>
          </div>
        </section>

        <section aria-labelledby="measure-title">
          <h2 id="measure-title">同一标题的两种计数</h2>
          <dl class="comparison">
            <div><dt>字素簇</dt><dd data-testid="graphemes">{{ counts.graphemes ?? '不可用' }}</dd></div>
            <div><dt>UTF-8 字节</dt><dd data-testid="bytes">{{ counts.utf8Bytes ?? '不可用' }}</dd></div>
          </dl>
          <div v-if="suggestion.kind === 'ready'" class="proposal" data-testid="proposal">
            <h3>Agent 建议</h3>
            <p class="suggestion">{{ suggestion.text }}</p>
            <p>使用 {{ suggestion.used }} / {{ rule.limit }} {{ unitNames[rule.unit] }}</p>
            <button type="button" @click="applySuggestion">替换当前文案</button>
          </div>
          <p v-else-if="suggestion.kind !== 'idle'" class="notice" :data-suggestion="suggestion.kind">
            {{ messages[suggestion.kind] }}
          </p>
        </section>
      </div>
    </main>
  `
}).mount('#app')
