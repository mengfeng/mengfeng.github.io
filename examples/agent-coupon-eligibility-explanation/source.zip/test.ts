import assert from 'node:assert/strict'
import { decide, mockAgentAnswer, readDemoTools, validateAnswer, type Scenario, type Selection } from './src/core'

const selection = (scenario: Scenario): Selection => ({ scenario, revision: 1 })
const expected = { eligible: 'eligible', threshold: 'ineligible', excluded: 'ineligible', expired: 'ineligible', timeout: 'unknown', stale: 'unknown' } as const
let assertions = 0
for (const scenario of Object.keys(expected) as Scenario[]) {
  const current = selection(scenario)
  const snapshot = readDemoTools(current)
  assert.equal(decide(snapshot).verdict, expected[scenario]); assertions++
  assert.equal(validateAnswer(mockAgentAnswer(snapshot, 'bounded'), snapshot, current).ok, true); assertions++
}
const good = readDemoTools(selection('eligible'))
assert.equal(decide(good).qualifiedCents, 13600); assertions++
assert.equal(validateAnswer(mockAgentAnswer(good, 'overpromise'), good, selection('eligible')).ok, false); assertions++
assert.equal(validateAnswer(mockAgentAnswer(good, 'bounded'), good, { scenario: 'eligible', revision: 2 }).ok, false); assertions++
assert.equal(validateAnswer(mockAgentAnswer(good, 'bounded'), good, selection('threshold')).ok, false); assertions++
assert.equal(validateAnswer({ ...mockAgentAnswer(good, 'bounded') as object, extra: true }, good, selection('eligible')).ok, false); assertions++
assert.equal(validateAnswer(null, good, selection('eligible')).ok, false); assertions++
assert.equal(decide(good, '2026-11-09T19:58:00+08:00').verdict, 'unknown'); assertions++
const timeout = readDemoTools(selection('timeout'))
assert.deepEqual(timeout.rule.status === 'timeout' ? Object.keys(timeout.rule).sort() : [], ['requestId', 'status']); assertions++
console.log(`${assertions} offline assertions passed`)
