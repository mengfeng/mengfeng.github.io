import { createApp, ref } from 'vue'
import { collect, mockCandidate, verify, type Answer, type Scenario, type Snapshot } from './core'

const scenarios: { value: Scenario; label: string }[] = [
  { value: 'ready', label: '时间、商品与叠加规则均通过' },
  { value: 'invalid_window', label: '活动开始晚于结束' },
  { value: 'ineligible_product', label: '商品不适用本活动' },
  { value: 'no_stack', label: '优惠券不可叠加' },
  { value: 'coupon_timeout', label: '券规则查询超时' },
  { value: 'version_conflict', label: '券规则引用旧版活动' },
  { value: 'stale_evidence', label: '活动记录已经过期' },
  { value: 'missing_activity', label: '活动记录未找到' }
]

const verdictLabels = {
  ready: '本轮通过', blocked: '需要修正', partial: '部分未知',
  conflict: '记录冲突', stale: '证据失效', unknown: '无法判断'
}

createApp({
  setup() {
    const scenario = ref<Scenario>('ready')
    const couponRequested = ref(true)
    const pageRevision = ref(7)
    const busy = ref(false)
    const forged = ref(false)
    const snapshot = ref<Snapshot | null>(null)
    const answer = ref<Answer | null>(null)
    let requestId = 0

    function clear(): void {
      requestId += 1
      busy.value = false
      snapshot.value = null
      answer.value = null
    }
    function chooseScenario(): void {
      pageRevision.value = 7
      clear()
    }
    function simulateEdit(): void {
      requestId += 1
      busy.value = false
      pageRevision.value += 1
      if (snapshot.value) {
        answer.value = verify(snapshot.value, { verdict: 'stale', sourceIds: [], message: '' }, pageRevision.value)
      }
    }
    async function query(): Promise<void> {
      clear()
      const currentRequest = requestId
      const selectedScenario = scenario.value
      const selectedCoupon = couponRequested.value
      const selectedRevision = pageRevision.value
      busy.value = true
      try {
        const evidence = await collect(selectedScenario, selectedCoupon, selectedRevision)
        if (currentRequest !== requestId) { return }
        const candidate = mockCandidate(evidence)
        snapshot.value = evidence
        answer.value = verify(evidence, forged.value
          ? { ...candidate, sourceIds: [...candidate.sourceIds, 'publish.write#fake'] }
          : candidate, pageRevision.value)
      } finally {
        if (currentRequest === requestId) { busy.value = false }
      }
    }
    return {
      scenarios, scenario, couponRequested, pageRevision, busy, forged, snapshot, answer,
      verdictLabels, clear, chooseScenario, simulateEdit, query
    }
  }
}).mount('#app')
