import type { Selection, Snapshot, Variant } from './core'

export const initial: Selection = { color: 'linen', size: 'S' }
export const colors = { linen: '燕麦色', charcoal: '炭灰色' }
const groupId = 'SHIRT-DEMO'
const variants: readonly Variant[] = [
  { id: 'LN-S', color: 'linen', size: 'S', stock: 'sold-out' },
  { id: 'LN-M', color: 'linen', size: 'M', stock: 'available' },
  { id: 'CH-S', color: 'charcoal', size: 'S', stock: 'available' },
  { id: 'CH-M', color: 'charcoal', size: 'M', stock: 'available' },
]
const withoutLinenS = variants.filter(row => row.id !== 'LN-S')

function scenario(id: string, label: string, changes: Partial<Snapshot> = {}, overrides: Record<string, unknown> = {}) {
  const snapshot: Snapshot = { id, groupId, complete: true, variants, ...changes }
  const candidate: unknown = {
    snapshotId: id, groupId, requestedColor: initial.color, requestedSize: initial.size,
    variantId: 'CH-S', ...overrides,
  }
  return { id, label, snapshot, candidate }
}

export const scenarios = [
  scenario('missing-stock', '原组合售罄，仅换颜色'),
  scenario('not-offered', '完整清单缺少原组合', { variants: withoutLinenS }),
  scenario('partial', '部分清单缺少原组合', { variants: withoutLinenS, complete: false }),
  scenario('unknown', '原组合库存未返回', {
    variants: variants.map(row => row.id === 'LN-S' ? { ...row, stock: 'unknown' } : row),
  }),
  scenario('wrong-size', 'Agent 擅自更换尺码', {}, { variantId: 'CH-M' }),
  scenario('stale', 'Agent 使用旧库存快照', {}, { snapshotId: 'expired' }),
  scenario('unavailable', '备选组合也已售罄', {
    variants: variants.map(row => row.id === 'CH-S' ? { ...row, stock: 'sold-out' } : row),
  }),
]
