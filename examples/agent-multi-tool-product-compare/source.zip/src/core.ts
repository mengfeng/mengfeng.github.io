export type ProductId = 'P1' | 'P2'
export type Scenario = 'complete' | 'stock_timeout' | 'offer_timeout' | 'stale'
export type Selection = { ids: readonly ProductId[]; revision: number }
export type CatalogRow = { id: ProductId; name: string; batteryHours: number; weightGrams: number; priceCents: number }
export type StockRow = { id: ProductId; available: boolean }
export type OfferRow = { id: ProductId; discountCents: number }
export type ToolName = 'catalog' | 'stock' | 'offer'
export type ToolPayload = {
  catalog: readonly CatalogRow[]
  stock: readonly StockRow[]
  offer: readonly OfferRow[]
}
export type ToolRecord<K extends ToolName = ToolName> = {
  tool: K; sourceId: string; checkedAt: number; selectionKey: string; data: ToolPayload[K]
}
export type ToolOutcome = { tool: ToolName; status: 'ok'; record: ToolRecord } | { tool: ToolName; status: 'error'; message: string }
export type Snapshot = { selection: Selection; key: string; outcomes: readonly ToolOutcome[] }
export type CompareRow = {
  id: ProductId; name: string; batteryHours: number; weightGrams: number
  priceCents: number; available: boolean | null; finalCents: number | null
}
export type Comparison = { status: 'ready' | 'partial' | 'stale'; rows: readonly CompareRow[]; sourceIds: readonly string[]; notes: readonly string[] }
export type Candidate = { key: string; sourceIds: readonly string[]; claim: string }
export type AnswerCheck = { accepted: boolean; message: string }

export const DEMO_NOW = Date.parse('2026-11-10T20:00:00+08:00')
const FRESH_MS = 3 * 60_000
const catalog: readonly CatalogRow[] = [
  { id: 'P1', name: '演示耳机 A', batteryHours: 32, weightGrams: 220, priceCents: 39900 },
  { id: 'P2', name: '演示耳机 B', batteryHours: 25, weightGrams: 185, priceCents: 42900 },
]
const stock: readonly StockRow[] = [{ id: 'P1', available: true }, { id: 'P2', available: true }]
const offer: readonly OfferRow[] = [{ id: 'P1', discountCents: 4000 }, { id: 'P2', discountCents: 10000 }]

export function selectionKey(selection: Selection): string {
  return `${selection.revision}:${selection.ids.join(',')}`
}

function makeRecord<K extends ToolName>(tool: K, data: ToolPayload[K], selection: Selection, scenario: Scenario): ToolRecord<K> {
  return { tool, data, sourceId: `${tool}:${selectionKey(selection)}:v1`, selectionKey: selectionKey(selection), checkedAt: scenario === 'stale' ? DEMO_NOW - 10 * 60_000 : DEMO_NOW - 60_000 }
}

function readTool<K extends ToolName>(tool: K, selection: Selection, scenario: Scenario): Promise<ToolRecord<K>> {
  if ((tool === 'stock' && scenario === 'stock_timeout') || (tool === 'offer' && scenario === 'offer_timeout')) {
    return Promise.reject(new Error(`${tool} 演示超时`))
  }
  const data = ({ catalog, stock, offer } as ToolPayload)[tool]
  return Promise.resolve(makeRecord(tool, data, selection, scenario))
}

export async function queryTools(selection: Selection, scenario: Scenario): Promise<Snapshot> {
  const ids = [...new Set(selection.ids)]
  if (ids.length !== 2 || ids.some(id => id !== 'P1' && id !== 'P2')) {
    throw new Error('请选择两件不同的演示商品。')
  }
  const fixedSelection: Selection = { ids, revision: selection.revision }
  const names: readonly ToolName[] = ['catalog', 'stock', 'offer']
  const settled = await Promise.allSettled(names.map(name => readTool(name, fixedSelection, scenario)))
  const outcomes: ToolOutcome[] = settled.map((item, index) => {
    const tool = names[index]
    return item.status === 'fulfilled'
      ? { tool, status: 'ok', record: item.value }
      : { tool, status: 'error', message: item.reason instanceof Error ? item.reason.message : `${tool} 查询失败` }
  })
  return { selection: fixedSelection, key: selectionKey(fixedSelection), outcomes }
}

function isFresh(record: ToolRecord, snapshot: Snapshot): boolean {
  return record.selectionKey === snapshot.key && record.checkedAt <= DEMO_NOW && DEMO_NOW - record.checkedAt <= FRESH_MS
}

export function compare(snapshot: Snapshot, current: Selection): Comparison {
  if (snapshot.key !== selectionKey(current)) {
    return { status: 'stale', rows: [], sourceIds: [], notes: ['商品选择或版本已变化，请重新查询。'] }
  }
  const valid = new Map<ToolName, ToolRecord>()
  const notes: string[] = []
  let hasStale = false
  for (const outcome of snapshot.outcomes) {
    if (outcome.status === 'error') {
      notes.push(`${outcome.tool} 查询失败：${outcome.message}`)
    } else if (!isFresh(outcome.record, snapshot)) {
      notes.push(`${outcome.tool} 结果已过期，不能用于当前比较。`)
      hasStale = true
    } else {
      valid.set(outcome.tool, outcome.record)
    }
  }
  if (hasStale) {
    return { status: 'stale', rows: [], sourceIds: [], notes }
  }
  const catalogRecord = valid.get('catalog')
  if (!catalogRecord) {
    return { status: 'partial', rows: [], sourceIds: [], notes: [...notes, '没有商品资料，无法生成比较表。'] }
  }
  const catalogRows = catalogRecord.data as readonly CatalogRow[]
  const stockRows = (valid.get('stock')?.data ?? []) as readonly StockRow[]
  const offerRows = (valid.get('offer')?.data ?? []) as readonly OfferRow[]
  const rows: CompareRow[] = snapshot.selection.ids.flatMap(id => {
    const item = catalogRows.find(row => row.id === id)
    if (!item) { return [] }
    const stockItem = stockRows.find(row => row.id === id)
    const offerItem = offerRows.find(row => row.id === id)
    return [{
      ...item,
      available: stockItem?.available ?? null,
      finalCents: offerItem ? item.priceCents - offerItem.discountCents : null,
    }]
  })
  if (rows.length !== 2) {
    return { status: 'partial', rows, sourceIds: [catalogRecord.sourceId], notes: [...notes, '有商品资料缺失，不能给出完整比较。'] }
  }
  const sourceIds = [...valid.values()].map(record => record.sourceId)
  if (!valid.has('stock')) { notes.push('库存未知；不能称商品现货可买。') }
  if (!valid.has('offer')) { notes.push('优惠未知；不能比较优惠后价格。') }
  const status = valid.size === 3 ? 'ready' : 'partial'
  return { status, rows, sourceIds, notes }
}

export function mockCandidate(snapshot: Snapshot, result: Comparison, badSource: boolean): Candidate {
  return {
    key: snapshot.key,
    sourceIds: badSource ? [...result.sourceIds, 'stock:invented'] : result.sourceIds,
    claim: result.status === 'ready' ? '演示数据中，B 优惠后更低；A 续航更长。' : '证据不完整，暂不做综合推荐。',
  }
}

export function validateCandidate(raw: unknown, snapshot: Snapshot, current: Selection, result: Comparison): AnswerCheck {
  if (result.status !== 'ready') { return { accepted: false, message: '比较证据不完整，只展示已核实字段。' } }
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    return { accepted: false, message: '模拟回答结构错误。' }
  }
  const candidate = raw as Record<string, unknown>
  if (candidate.key !== snapshot.key || snapshot.key !== selectionKey(current)) {
    return { accepted: false, message: '商品选择或版本已变化。' }
  }
  if (!Array.isArray(candidate.sourceIds) || candidate.sourceIds.length !== result.sourceIds.length ||
      candidate.sourceIds.some((value, index) => value !== result.sourceIds[index])) {
    return { accepted: false, message: '模拟回答引用了错误或伪造的来源。' }
  }
  if (candidate.claim !== '演示数据中，B 优惠后更低；A 续航更长。') {
    return { accepted: false, message: '模拟回答与已核实数据不一致。' }
  }
  return { accepted: true, message: '已接受模拟回答：演示数据中，B 优惠后更低；A 续航更长。' }
}
