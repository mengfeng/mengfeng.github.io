import assert from 'node:assert/strict'
import { collect, mockCandidate, verify, type Candidate } from './src/core'
let checks = 0
function eq(actual: unknown, expected: unknown): void { assert.equal(actual, expected); checks++ }
function yes(value: unknown): void { assert.ok(value); checks++ }
const reviewing = await collect('reviewing', 7)
const answerReview = verify(reviewing, mockCandidate(reviewing))
eq(answerReview.verdict, 'ready')
yes(answerReview.headline.includes('正在审核'))
yes(answerReview.detail.includes('未知'))
eq(answerReview.sourceIds.length, 2)
const processing = await collect('processing', 7)
eq(verify(processing, mockCandidate(processing)).verdict, 'ready')
yes(verify(processing, mockCandidate(processing)).detail.includes('不能承诺'))
const channelDone = await collect('channel_done', 7)
yes(verify(channelDone, mockCandidate(channelDone)).headline.includes('渠道标记'))
yes(verify(channelDone, mockCandidate(channelDone)).detail.includes('本人账单'))
const missing = await collect('not_found', 7)
eq(verify(missing, mockCandidate(missing)).verdict, 'unknown')
eq(verify(missing, mockCandidate(missing)).sourceIds.length, 0)
const timeout = await collect('channel_timeout', 7)
eq(verify(timeout, mockCandidate(timeout)).verdict, 'partial')
eq(verify(timeout, mockCandidate(timeout)).sourceIds.length, 1)
const conflict = await collect('conflict', 7)
eq(verify(conflict, mockCandidate(conflict)).verdict, 'conflict')
yes(verify(conflict, mockCandidate(conflict)).detail.includes('人工'))
const stale = await collect('stale', 7)
eq(verify(stale, mockCandidate(stale)).verdict, 'stale')
const versionChange = await collect('reviewing', 8)
eq(verify(versionChange, mockCandidate(versionChange)).verdict, 'stale')
const valid = mockCandidate(processing)
const forged: Candidate = { ...valid, sourceIds: [...valid.sourceIds, 'refund.write#fake'] }
eq(verify(processing, forged).verdict, 'conflict')
eq(verify(processing, { ...valid, claim: 'actual_arrival' }).verdict, 'conflict')
eq(verify(processing, { ...valid, claim: 'reviewing' }).verdict, 'conflict')
const mismatched = { ...processing, channel: processing.channel.ok ? { ok: true as const, value: { ...processing.channel.value, refundId: 'OTHER' } } : processing.channel }
eq(verify(mismatched, mockCandidate(mismatched)).verdict, 'conflict')
const wrongAmount = { ...processing, channel: processing.channel.ok ? { ok: true as const, value: { ...processing.channel.value, amountCents: 999 } } : processing.channel }
eq(verify(wrongAmount, mockCandidate(wrongAmount)).verdict, 'conflict')
console.log(`${checks} offline assertions passed`)
