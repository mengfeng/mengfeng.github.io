export type Scenario = 'normal' | 'duplicate' | 'unknown_review' | 'wrong_quote' | 'old_sample' | 'empty' | 'malformed'
export type Topic = 'packing' | 'shipping'
export type Review = Readonly<{ id: string; text: string }>
export type Sample = Readonly<{ id: string; product: string; filter: string; reviews: readonly Review[] }>

export type Citation = Readonly<{ review: Review; quote: string }>
export type Theme = Readonly<{ topic: Topic; citations: readonly Citation[] }>
export type Result =
  | { kind: 'blocked'; reason: 'empty' | 'old_sample' | 'invalid_proposal' }
  | { kind: 'checked'; themes: readonly Theme[]; excluded: number; duplicates: number }

export const topicLabels: Record<Topic, string> = {
  packing: '包装破损', shipping: '发货等待'
}

const reviews = [
  { id: 'R-01', text: '杯子没坏，但外盒有压痕。' },
  { id: 'R-02', text: '下单后三天才发货。外盒有折痕。' },
  { id: 'R-03', text: '等了两天才看到发货通知。' },
  { id: 'R-04', text: '把手尺寸刚好，颜色比照片浅。' },
  { id: 'R-05', text: '标签上印着 <小件>，颜色和描述一致。' }
] as const

export function readSample(scenario: Scenario): Sample {
  return {
    id: scenario === 'empty' ? 'mug-demo/empty/v2' : 'mug-demo/first-page/v2',
    product: '演示商品 · 陶瓷杯',
    filter: '按最新时间取第一页，全部星级',
    reviews: scenario === 'empty' ? [] : reviews
  }
}

export function mockProposal(scenario: Scenario): unknown {
  const first = { reviewId: 'R-01', quote: '外盒有压痕' }
  const packing = [first, { reviewId: 'R-02', quote: '外盒有折痕' }]
  if (scenario === 'duplicate') packing.push(first)
  if (scenario === 'unknown_review') packing.push({ reviewId: 'R-99', quote: '外盒明显破损' })
  if (scenario === 'wrong_quote') packing[0] = { reviewId: 'R-01', quote: '杯子摔碎了' }
  const groups = [
    { topic: 'packing', citations: packing },
    { topic: 'shipping', citations: [
      { reviewId: 'R-02', quote: '下单后三天才发货' },
      { reviewId: 'R-03', quote: '等了两天才看到发货通知' }
    ] }
  ]
  return {
    sampleId: scenario === 'old_sample' ? 'mug-demo/first-page/v1' : readSample(scenario).id,
    groups: scenario === 'malformed' ? '包装和发货' : groups
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

export function checkProposal(sample: Sample, raw: unknown): Result {
  if (sample.reviews.length === 0) return { kind: 'blocked', reason: 'empty' }
  if (!isRecord(raw) || typeof raw.sampleId !== 'string' || !Array.isArray(raw.groups) ||
      raw.groups.length > 6) return { kind: 'blocked', reason: 'invalid_proposal' }
  if (raw.sampleId !== sample.id) return { kind: 'blocked', reason: 'old_sample' }

  const reviewsById = new Map(sample.reviews.map(review => [review.id, review]))
  const byTopic = new Map<Topic, Map<string, Citation>>()
  let excluded = 0
  let duplicates = 0
  for (const group of raw.groups as unknown[]) {
    if (!isRecord(group) || (group.topic !== 'packing' && group.topic !== 'shipping') ||
        !Array.isArray(group.citations) || group.citations.length > 12) {
      return { kind: 'blocked', reason: 'invalid_proposal' }
    }
    const accepted = byTopic.get(group.topic) ?? new Map<string, Citation>()
    byTopic.set(group.topic, accepted)
    for (const ref of group.citations as unknown[]) {
      if (!isRecord(ref) || typeof ref.reviewId !== 'string' || typeof ref.quote !== 'string') {
        excluded++
        continue
      }
      const review = reviewsById.get(ref.reviewId)
      if (!review || ref.quote.trim().length < 4 || ref.quote.length > 80 || !review.text.includes(ref.quote)) {
        excluded++
        continue
      }
      if (accepted.has(review.id)) {
        duplicates++
        continue
      }
      accepted.set(review.id, { review, quote: ref.quote })
    }
  }

  const themes: Theme[] = []
  for (const [topic, accepted] of byTopic) {
    if (accepted.size > 0) themes.push({ topic, citations: [...accepted.values()] })
  }
  return { kind: 'checked', themes, excluded, duplicates }
}
