import type { Placement } from './core'

const imageRevision = 'mug-photo-r2'
const informative: Placement = {
  id: 'product-gallery', imageRevision, role: 'informative', subject: '钴蓝色马克杯',
  details: [{ id: 'handle', phrase: '右侧有圆形杯柄' }, { id: 'interior', phrase: '杯内为白色' }],
}
const decorative: Placement = { id: 'text-illustration', imageRevision, role: 'decorative' }
const functional: Placement = {
  id: 'spec-link', imageRevision, role: 'functional', actionLabel: '查看马克杯规格',
}

function scenario(id: string, label: string, placement: Placement, detailIds: string[],
  overrides: Record<string, unknown> = {}) {
  const candidate: unknown = {
    placementId: placement.id, imageRevision: placement.imageRevision,
    role: placement.role, detailIds, ...overrides,
  }
  return { id, label, placement, candidate }
}

export const scenarios = [
  scenario('gallery', '商品详情图', informative, ['handle', 'interior']),
  scenario('decoration', '图旁已完整描述', decorative, []),
  scenario('link', '独立图片链接', functional, []),
  scenario('wrong-role', '误把链接当装饰', functional, [], { role: 'decorative' }),
  scenario('unsupported', '引用未经登记的卖点', informative, ['dishwasher-safe']),
  scenario('stale', '候选来自上一版图片', informative, ['handle'], { imageRevision: 'mug-photo-r1' }),
  scenario('wrong-place', '候选来自别的位置', informative, ['handle'], { placementId: 'text-illustration' }),
]
