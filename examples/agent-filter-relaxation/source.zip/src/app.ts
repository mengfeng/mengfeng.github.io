import { createApp, ref } from 'vue'
import { initialFilters, mockModelProposal, searchProducts, validateProposal, versionOf, type CandidateKind, type Filters, type ProposalCheck, type SearchResult } from './core'

createApp({
  setup() {
    const filters = ref<Filters>(initialFilters)
    const lastSearch = ref<SearchResult | null>(null)
    const candidate = ref<CandidateKind>('safe')
    const simulateTimeout = ref(false)
    const check = ref<ProposalCheck | null>(null)
    const toolCalls = ref(0)
    const message = ref('先执行查询，再让模拟 Agent 给出建议。')
    const runSearch = () => {
      check.value = null
      toolCalls.value += 1
      lastSearch.value = searchProducts(filters.value, simulateTimeout.value)
      message.value = lastSearch.value.status === 'timeout' ? '商品查询超时：结果未知，请重试。' : lastSearch.value.status === 'empty' ? '已确认无结果，可请求一项放宽建议。' : '找到商品；无需放宽条件。'
    }
    const suggest = () => {
      if (!lastSearch.value) { message.value = '请先执行查询。'; return }
      check.value = validateProposal(mockModelProposal(candidate.value, filters.value), filters.value, lastSearch.value)
      message.value = check.value.ok ? '建议待确认；原筛选条件尚未改变。' : check.value.error
    }
    const confirm = () => {
      if (!check.value?.ok || !lastSearch.value) return
      if (lastSearch.value.version !== versionOf(filters.value)) { check.value = null; message.value = '筛选条件已变化，请重新查询。'; return }
      filters.value = check.value.value.next
      runSearch()
    }
    const reset = () => { filters.value = initialFilters; lastSearch.value = null; check.value = null; simulateTimeout.value = false; toolCalls.value = 0; message.value = '已恢复初始筛选。' }
    return { filters, lastSearch, candidate, simulateTimeout, check, toolCalls, message, runSearch, suggest, confirm, reset }
  },
  template: `
  <main class="shell">
    <header class="hero"><div class="eyebrow">AGENT / FILTER LAB 07</div><h1>没搜到商品，先别乱改条件</h1><p>把 Agent 的“放宽建议”变成可审查的差异。锁定条件始终由应用控制。</p></header>
    <section class="panel" aria-label="当前筛选"><div class="section-head"><h2>当前筛选条件</h2><button class="ghost" type="button" @click="reset">重置演示</button></div>
      <div class="chips"><span>关键词：{{ filters.query }}</span><span class="locked">🔒 分类：耳机</span><span class="locked">🔒 必须有货</span><span>颜色：{{ filters.color === 'blue' ? '蓝色' : '不限' }}</span><span>价格 ≤ {{ filters.maxPrice }}</span></div>
      <label class="tick"><input type="checkbox" v-model="simulateTimeout">模拟只读查询超时</label>
      <button type="button" @click="runSearch">① 查询演示商品</button>
    </section>
    <div class="layout"><section class="panel" aria-label="查询结果"><h2>查询结果</h2><p class="status" role="status">{{ message }}</p>
      <p v-if="!lastSearch" class="muted">还没有调用商品查询工具。</p><p v-else-if="lastSearch.status === 'timeout'" class="error">超时不是无结果，不能据此放宽条件。</p>
      <p v-else-if="lastSearch.status === 'empty'" class="empty">0 件符合全部条件的演示商品。</p>
      <ul v-else class="products"><li v-for="p in lastSearch.items" :key="p.id"><strong>{{ p.name }}</strong><span>¥{{ p.price }} · 库存 {{ p.stock }}</span></li></ul>
      <p class="muted">只读商品查询工具已调用 {{ toolCalls }} 次；数据固定写在本地代码中。</p></section>
    <section class="panel" aria-label="Agent 建议"><h2>Agent 建议</h2><label>模拟候选输出 <select v-model="candidate"><option value="safe">可接受：只提高价格上限</option><option value="unsafe">危险：试图去掉有货要求</option><option value="stale">过期：基于旧筛选条件</option></select></label>
      <button type="button" @click="suggest">② 生成并校验建议</button>
      <div v-if="check?.ok" class="proposal"><p>{{ check.value.reason }}</p><div class="diff"><span>原条件：{{ check.value.changed === 'maxPrice' ? '价格 ≤ ' + filters.maxPrice : '蓝色' }}</span><b>→</b><span>建议：{{ check.value.changed === 'maxPrice' ? '价格 ≤ ' + check.value.next.maxPrice : '颜色不限' }}</span></div><p class="muted">分类和“必须有货”保持锁定；用户确认前不重新查询。</p><button type="button" @click="confirm">③ 确认调整并重新查询</button></div>
      <p v-else-if="check" class="error">{{ check.error }}</p><p v-else class="muted">建议只是一份待确认的模拟模型输出。</p></section></div>
    <footer>演示数据与模型响应均为固定样本。没有真实模型调用、付款、订单写入或外部消息。</footer>
  </main>`
}).mount('#app')
