import { createApp, ref } from 'vue'
import { collect, mockCandidate, verify, type Assessment, type Collected, type Scenario } from './core'

createApp({
  setup() {
    const scenario = ref<Scenario>('ready')
    const revision = ref(3)
    const evidence = ref<Collected | null>(null)
    const assessment = ref<Assessment | null>(null)
    const candidateText = ref('')
    const pending = ref(false)
    const reviewed = ref(false)
    let requestId = 0
    function invalidate(): void {
      requestId++
      evidence.value = null
      assessment.value = null
      candidateText.value = ''
      pending.value = false
      reviewed.value = false
    }
    function updateTickets(): void { revision.value++; invalidate() }
    async function run(): Promise<void> {
      const id = ++requestId
      const selected = scenario.value
      const currentRevision = revision.value
      pending.value = true
      reviewed.value = false
      try {
        const next = await collect(selected, currentRevision)
        if (id !== requestId) return
        const candidate = mockCandidate(selected, currentRevision)
        evidence.value = next
        candidateText.value = JSON.stringify(candidate, null, 2)
        assessment.value = verify(next, currentRevision, candidate)
      } catch {
        if (id === requestId) assessment.value = { state: 'blocked', message: '本地演示运行失败，请刷新后重试。', draft: null }
      } finally {
        if (id === requestId) pending.value = false
      }
    }
    return { scenario, revision, evidence, assessment, candidateText, pending, reviewed, invalidate, updateTickets, run }
  },
  template: `
  <main class="shell">
    <header class="hero"><div class="eyebrow">FRONTEND AGENT LAB · 10</div>
      <h1>两张工单是一件事吗？</h1>
      <p>先核对归属、订单、问题类型、状态和版本，再展示待人工审阅的合并建议。这里没有真实客服系统或合并接口。</p>
    </header>
    <section class="panel"><h2>选择演示情况</h2>
      <label>核对场景<select v-model="scenario" @change="invalidate">
        <option value="ready">同一问题，证据齐全</option>
        <option value="foreign_ticket">另一账户的工单被拒绝读取</option>
        <option value="different_order">订单不同</option>
        <option value="different_issue">问题类型不同</option>
        <option value="closed_ticket">一张工单已关闭</option>
        <option value="stale_ticket">工单版本已变化</option>
        <option value="ticket_timeout">工单读取超时</option>
        <option value="account_timeout">归属读取超时</option>
        <option value="policy_timeout">规则读取超时</option>
        <option value="forged_source">候选伪造规则来源</option>
        <option value="malformed_candidate">候选版本字段类型错误</option>
        <option value="wrong_primary">候选主次工单颠倒</option>
      </select></label>
      <div class="actions"><button @click="run" :disabled="pending">{{ pending ? '核对中…' : '读取证据并核对' }}</button>
        <button class="quiet" @click="updateTickets">模拟工单更新（当前 r{{ revision }}）</button></div>
    </section>
    <div class="grid">
      <section class="panel"><h2>本轮只读证据</h2>
        <p class="fine" v-if="!evidence">点击核对后显示两张工单、账户归属和演示规则。</p>
        <template v-else>
          <div class="evidence"><b>工单读取</b>
            <template v-if="evidence.tickets.kind === 'ok'"><span class="ok">已授权读取</span><code>{{ evidence.tickets.value.sourceId }}</code>
              <div class="ticket" v-for="ticket in [evidence.tickets.value.first, evidence.tickets.value.second]" :key="ticket.id">
                <strong>{{ ticket.id }}</strong><p>{{ ticket.summary }}</p>
                <small>{{ ticket.orderId }} · {{ ticket.issueCode }} · {{ ticket.status }} · r{{ ticket.revision }}</small>
              </div>
            </template>
            <span v-else class="error">{{ evidence.tickets.message }}；不展示未获授权的工单详情。</span>
          </div>
          <div class="evidence"><b>账户归属</b>
            <template v-if="evidence.ownership.kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence.ownership.value.sourceId }}</code><p>当前演示账户可访问 {{ evidence.ownership.value.allowedTicketIds.length }} 张示例工单。</p></template>
            <span v-else class="error">{{ evidence.ownership.message }}</span>
          </div>
          <div class="evidence"><b>演示规则</b>
            <template v-if="evidence.policy.kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence.policy.value.sourceId }}</code><p>仅同账户、同订单、同问题且都开放时，才给出合并建议。</p></template>
            <span v-else class="error">{{ evidence.policy.message }}</span>
          </div>
        </template>
      </section>
      <section class="panel"><div class="panel-head"><h2>合并建议草稿</h2><span v-if="assessment" class="badge" :class="assessment.state">{{ assessment.state }}</span></div>
        <p class="fine" v-if="!assessment">尚未核对。候选由固定本地函数生成，并非真实模型输出。</p>
        <template v-else><p class="notice">{{ assessment.message }}</p>
          <div class="draft" v-if="assessment.draft">
            <p><b>保留主工单</b> {{ assessment.draft.primaryId }}<br><b>建议关联</b> {{ assessment.draft.secondaryId }}<br><b>关联订单</b> {{ assessment.draft.orderId }}<br><b>问题类型</b> {{ assessment.draft.issueCode }}</p>
            <p>{{ assessment.draft.reason }}</p>
            <div class="sources"><span v-for="id in assessment.draft.sourceIds" :key="id">{{ id }}</span></div>
            <label class="review"><input type="checkbox" v-model="reviewed">人工已审阅（仅本地状态）</label>
          </div>
          <p class="fine" v-else>没有可供确认的合并建议。</p>
        </template>
        <details v-if="candidateText"><summary>查看固定模拟候选 JSON</summary><pre class="candidate">{{ candidateText }}</pre></details>
        <p class="fine">没有合并、关闭工单或对外发送接口。</p>
      </section>
    </div>
    <footer>虚构工单与固定模拟候选 · Vue 3 + TypeScript · 前端核对不替代服务端鉴权和人工决定</footer>
  </main>`
}).mount('#app')
