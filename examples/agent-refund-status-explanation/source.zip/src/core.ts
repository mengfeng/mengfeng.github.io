export type Scenario = 'reviewing' | 'processing' | 'channel_done' | 'not_found' | 'channel_timeout' | 'conflict' | 'stale'
export type ReviewStatus = 'submitted' | 'reviewing' | 'approved' | 'rejected'
export type ChannelStatus = 'not_started' | 'processing' | 'channel_complete'
export type ToolResult<T> = { ok: true; value: T } | { ok: false; reason: 'not_found' | 'timeout' }
export type RefundRecord = {
  sourceId: string; refundId: string; orderId: string; version: number
  status: ReviewStatus; amountCents: number; checkedAt: string
}
export type ChannelRecord = {
  sourceId: string; refundId: string; refundVersion: number
  status: ChannelStatus; amountCents: number; checkedAt: string
}
export type Snapshot = {
  refund: ToolResult<RefundRecord>; channel: ToolResult<ChannelRecord>
  requestedVersion: number
}
export type Claim = 'reviewing' | 'processing' | 'channel_done' | 'actual_arrival' | 'unknown'
export type Candidate = { claim: Claim; sourceIds: string[]; message: string }
export type Verdict = 'ready' | 'partial' | 'conflict' | 'stale' | 'unknown'
export type Answer = { verdict: Verdict; headline: string; detail: string; sourceIds: string[]; steps: string[] }

const NOW = '2026-11-12T20:00:00+08:00'
const FRESHNESS_MS = 5 * 60 * 1000
const REFUND_ID = 'RF-DEMO-024'

// Both tools are local read-only fixtures. No model, payment gateway or refund API is called.
export async function readRefund(scenario: Scenario): Promise<RefundRecord> {
  if (scenario === 'not_found') { throw new Error('not_found') }
  const status: ReviewStatus = scenario === 'reviewing' || scenario === 'conflict' ? 'reviewing' : 'approved'
  return {
    sourceId: 'refund.read#RF-DEMO-024-v7', refundId: REFUND_ID, orderId: 'ORDER-DEMO-83',
    version: 7, status, amountCents: 12900,
    checkedAt: scenario === 'stale' ? '2026-11-12T19:40:00+08:00' : '2026-11-12T19:59:00+08:00'
  }
}

export async function readChannel(scenario: Scenario): Promise<ChannelRecord> {
  if (scenario === 'channel_timeout') { throw new Error('timeout') }
  const status: ChannelStatus = scenario === 'channel_done' || scenario === 'conflict'
    ? 'channel_complete' : scenario === 'processing' || scenario === 'stale'
      ? 'processing' : 'not_started'
  return {
    sourceId: 'channel.read#RF-DEMO-024-v7', refundId: REFUND_ID,
    refundVersion: 7, status, amountCents: 12900,
    checkedAt: scenario === 'stale' ? '2026-11-12T19:40:00+08:00' : '2026-11-12T19:59:00+08:00'
  }
}

export async function collect(scenario: Scenario, requestedVersion: number): Promise<Snapshot> {
  const [refund, channel] = await Promise.allSettled([readRefund(scenario), readChannel(scenario)])
  return {
    refund: refund.status === 'fulfilled'
      ? { ok: true, value: refund.value } : { ok: false, reason: 'not_found' },
    channel: channel.status === 'fulfilled'
      ? { ok: true, value: channel.value } : { ok: false, reason: 'timeout' },
    requestedVersion
  }
}

function isFresh(checkedAt: string): boolean {
  const delta = Date.parse(NOW) - Date.parse(checkedAt)
  return Number.isFinite(delta) && delta >= 0 && delta <= FRESHNESS_MS
}

function classify(snapshot: Snapshot): Verdict | 'reviewing' | 'processing' | 'channel_done' {
  if (!snapshot.refund.ok) { return 'unknown' }
  const refund = snapshot.refund.value
  if (refund.version !== snapshot.requestedVersion || !isFresh(refund.checkedAt)) { return 'stale' }
  if (!snapshot.channel.ok) { return 'partial' }
  const channel = snapshot.channel.value
  if (!isFresh(channel.checkedAt)) { return 'stale' }
  if (channel.refundId !== refund.refundId || channel.refundVersion !== refund.version || channel.amountCents !== refund.amountCents) { return 'conflict' }
  if (refund.status === 'reviewing' && channel.status === 'not_started') { return 'reviewing' }
  if (refund.status === 'approved' && channel.status === 'processing') { return 'processing' }
  if (refund.status === 'approved' && channel.status === 'channel_complete') { return 'channel_done' }
  return 'conflict'
}

export function mockCandidate(snapshot: Snapshot): Candidate {
  const state = classify(snapshot)
  const claim: Claim = state === 'reviewing' || state === 'processing' || state === 'channel_done' ? state : 'unknown'
  return {
    claim,
    sourceIds: snapshot.refund.ok
      ? [snapshot.refund.value.sourceId, ...(snapshot.channel.ok ? [snapshot.channel.value.sourceId] : [])]
      : [],
    message: '这是固定模拟回答，不会发送给真实用户。'
  }
}

export function verify(snapshot: Snapshot, candidate: Candidate): Answer {
  const state = classify(snapshot)
  const steps = ['退款申请', '商家审核', '支付渠道处理', '用户实际到账']
  const knownSources = snapshot.refund.ok
    ? [snapshot.refund.value.sourceId, ...(snapshot.channel.ok ? [snapshot.channel.value.sourceId] : [])]
    : []
  if (candidate.sourceIds.length !== knownSources.length || candidate.sourceIds.some((source, index) => source !== knownSources[index])) {
    return { verdict: 'conflict', headline: '引用未通过核对', detail: '模拟回答引用了缺失或伪造的证据，已拒绝展示。', sourceIds: [], steps }
  }
  if (candidate.claim === 'actual_arrival') {
    return { verdict: 'conflict', headline: '不能宣称实际到账', detail: '当前只有退款单和支付渠道记录，没有用户账户到账证据。', sourceIds: knownSources, steps }
  }
  if (state === 'unknown') {
    return { verdict: 'unknown', headline: '暂不能定位退款单', detail: '示例退款单未找到；不能据此断言用户从未申请退款。', sourceIds: [], steps }
  }
  if (state === 'stale') {
    return { verdict: 'stale', headline: '证据已过期', detail: '退款版本或查询时间不在本轮有效范围，请重新查询。', sourceIds: [], steps }
  }
  if (state === 'partial') {
    return { verdict: 'partial', headline: '只确认商家审核状态', detail: '支付渠道查询超时，不能推断渠道处理结果或实际到账。', sourceIds: snapshot.refund.ok ? [snapshot.refund.value.sourceId] : [], steps }
  }
  if (state === 'conflict') {
    return { verdict: 'conflict', headline: '两套状态有冲突', detail: '退款单仍在审核，渠道却标记完成；请人工核对，暂不承诺到账。', sourceIds: knownSources, steps }
  }
  if (candidate.claim !== state) {
    return { verdict: 'conflict', headline: '模拟回答与证据不符', detail: '候选阶段不等于工具核对出的阶段，已拒绝展示。', sourceIds: knownSources, steps }
  }
  const content = {
    reviewing: ['申请已提交，正在审核', '支付渠道尚未开始处理；审核通过和实际到账时间都未知。'],
    processing: ['审核通过，渠道处理中', '尚无渠道完成记录，更不能承诺用户账户已到账。'],
    channel_done: ['渠道标记退款完成', '这是支付渠道的完成记录；用户实际到账仍需以本人账单核对。']
  }[state]
  return { verdict: 'ready', headline: content[0], detail: content[1], sourceIds: knownSources, steps }
}
