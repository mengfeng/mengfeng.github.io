import { computed, createApp, ref } from 'vue'
import { checkProposal, mockProposal, readSample, topicLabels, type Result, type Scenario } from './core'

const scenarios: ReadonlyArray<{ id: Scenario; label: string }> = [
  { id: 'normal', label: '引用与原文一致' },
  { id: 'duplicate', label: '同一主题重复引用' },
  { id: 'unknown_review', label: '引用样本外评价' },
  { id: 'wrong_quote', label: '编号正确，引文不符' },
  { id: 'old_sample', label: '候选来自旧快照' },
  { id: 'empty', label: '当前样本为空' },
  { id: 'malformed', label: '候选结构错误' }
]
type Blocked = Extract<Result, { kind: 'blocked' }>
const reasons: Record<Blocked['reason'], string> = {
  empty: '当前没有评价可归纳。调整筛选条件后再试。',
  old_sample: '候选绑定了另一份快照。请基于当前评价重新归纳。',
  invalid_proposal: '候选结构不符合约定。请重新生成后核对。'
}

createApp({
  setup() {
    const selected = ref<Scenario>('normal')
    const sample = computed(() => readSample(selected.value))
    const result = computed(() => checkProposal(sample.value, mockProposal(selected.value)))
    return { selected, scenarios, sample, result, topicLabels, reasons }
  },
  template: `
    <main class="shell">
      <header>
        <h1>商品评价主题核对</h1>
        <p>用虚构评价和固定的 Agent 候选，核对样本内的主题引用。</p>
      </header>
      <label for="scenario">演示场景</label>
      <select id="scenario" v-model="selected">
        <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
      </select>
      <section class="sample">
        <h2>{{ sample.product }}</h2>
        <p>{{ sample.filter }} · 本次样本 {{ sample.reviews.length }} 条</p>
        <code>{{ sample.id }}</code>
      </section>
      <section aria-labelledby="results" aria-live="polite">
        <h2 id="results">通过引用核对的主题</h2>
        <p v-if="result.kind === 'blocked'" class="notice">{{ reasons[result.reason] }}</p>
        <template v-else>
          <p v-if="result.excluded || result.duplicates" class="notice">
            已排除 {{ result.excluded }} 条无效引用，合并 {{ result.duplicates }} 条重复引用。
          </p>
          <p v-if="!result.themes.length" class="notice">本次候选没有可核对的引用。</p>
          <div class="themes" v-else>
            <article v-for="theme in result.themes" :key="theme.topic" class="theme">
              <h3>{{ topicLabels[theme.topic] }}</h3>
              <p>本次 {{ sample.reviews.length }} 条样本中有 <strong>{{ theme.citations.length }}</strong> 条被引用</p>
              <details :key="sample.id + ':' + selected + ':' + theme.topic">
                <summary>查看评价原文</summary>
                <ul>
                  <li v-for="citation in theme.citations" :key="citation.review.id">
                    <p><b>{{ citation.review.id }}</b> · “{{ citation.quote }}”</p>
                    <blockquote>{{ citation.review.text }}</blockquote>
                  </li>
                </ul>
              </details>
            </article>
          </div>
        </template>
      </section>
      <details v-if="sample.reviews.length" class="all" :key="sample.id">
        <summary>查看本次全部 {{ sample.reviews.length }} 条样本</summary>
        <ul><li v-for="review in sample.reviews" :key="review.id">{{ review.id }} · {{ review.text }}</li></ul>
      </details>
    </main>`
}).mount('#app')
