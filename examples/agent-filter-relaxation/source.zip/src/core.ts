export type Filters = Readonly<{
  query: '耳机'
  category: 'headphones'
  inStock: true
  color: 'blue' | 'any'
  maxPrice: number
}>
export type Product = Readonly<{ id: string; name: string; color: 'blue' | 'black'; price: number; stock: number }>
export type SearchResult = Readonly<{
  status: 'found' | 'empty' | 'timeout'
  version: string
  items: readonly Product[]
}>
export type ValidProposal = Readonly<{ next: Filters; changed: 'maxPrice' | 'color'; reason: string }>
export type ProposalCheck = Readonly<{ ok: true; value: ValidProposal } | { ok: false; error: string }>
export type CandidateKind = 'safe' | 'unsafe' | 'stale'

const catalog: readonly Product[] = [
  { id: 'P01', name: '演示蓝色耳机 A', color: 'blue', price: 399, stock: 4 },
  { id: 'P02', name: '演示黑色耳机 B', color: 'black', price: 269, stock: 8 },
  { id: 'P03', name: '演示蓝色耳机 C', color: 'blue', price: 259, stock: 0 }
]

export const initialFilters: Filters = Object.freeze({ query: '耳机', category: 'headphones', inStock: true, color: 'blue', maxPrice: 300 })
export const versionOf = (f: Filters): string => `${f.query}|${f.category}|${f.inStock}|${f.color}|${f.maxPrice}`

export function searchProducts(f: Filters, simulateTimeout = false): SearchResult {
  const version = versionOf(f)
  if (simulateTimeout) return { status: 'timeout', version, items: [] }
  const items = catalog.filter(p => p.name.includes(f.query) && p.stock > 0 && p.price <= f.maxPrice && (f.color === 'any' || p.color === f.color))
  return { status: items.length ? 'found' : 'empty', version, items }
}

function isRecord(input: unknown): input is Record<string, unknown> {
  return typeof input === 'object' && input !== null && !Array.isArray(input)
}

export function validateProposal(raw: unknown, current: Filters, lastSearch: SearchResult): ProposalCheck {
  if (lastSearch.status !== 'empty') return { ok: false, error: '只有确定查询无结果时才能提出放宽建议；超时需要重试查询。' }
  if (lastSearch.version !== versionOf(current)) return { ok: false, error: '筛选条件已变化，请重新查询后再获取建议。' }
  if (!isRecord(raw) || typeof raw.baseVersion !== 'string' || !isRecord(raw.changes) || typeof raw.reason !== 'string') {
    return { ok: false, error: '建议结构不完整，不能应用。' }
  }
  if (Object.keys(raw).sort().join(',') !== 'baseVersion,changes,reason') return { ok: false, error: '建议包含未知字段，已拒绝。' }
  if (raw.baseVersion !== versionOf(current)) return { ok: false, error: '建议基于旧版筛选条件，已拒绝。' }
  if (raw.reason.trim().length === 0 || raw.reason.length > 80) return { ok: false, error: '建议理由缺失或过长，已拒绝。' }
  const keys = Object.keys(raw.changes)
  if (keys.length !== 1) return { ok: false, error: '每次只能调整一项可选条件。' }
  const key = keys[0]
  if (key === 'maxPrice') {
    const value = raw.changes.maxPrice
    if (typeof value !== 'number' || !Number.isInteger(value) || value <= current.maxPrice || value > 500) {
      return { ok: false, error: '价格上限必须提高，且不能超过演示上限 500。' }
    }
    return { ok: true, value: { next: { ...current, maxPrice: value }, changed: 'maxPrice', reason: raw.reason.trim() } }
  }
  if (key === 'color' && current.color === 'blue' && raw.changes.color === 'any') {
    return { ok: true, value: { next: { ...current, color: 'any' }, changed: 'color', reason: raw.reason.trim() } }
  }
  return { ok: false, error: '建议试图修改锁定条件或使用未知字段，已拒绝。' }
}

export function mockModelProposal(kind: CandidateKind, current: Filters): unknown {
  if (kind === 'unsafe') return { baseVersion: versionOf(current), changes: { inStock: false }, reason: '去掉有货要求' }
  if (kind === 'stale') return { baseVersion: 'old-query-version', changes: { maxPrice: 400 }, reason: '基于旧筛选条件的建议' }
  if (current.maxPrice < 400) return { baseVersion: versionOf(current), changes: { maxPrice: 400 }, reason: '把价格上限从 300 调到 400，蓝色与有货保持不变。' }
  return { baseVersion: versionOf(current), changes: { color: 'any' }, reason: '允许其他颜色，保留价格和有货要求。' }
}
