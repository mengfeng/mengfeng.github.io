import { initialFilters, mockModelProposal, searchProducts, validateProposal, versionOf } from './src/core'

let assertions = 0
function check(condition: boolean, message: string): void {
  assertions += 1
  if (!condition) throw new Error(message)
}

const empty = searchProducts(initialFilters)
check(empty.status === 'empty', 'initial search must be empty')
check(empty.items.length === 0, 'initial result must have zero items')
const accepted = validateProposal(mockModelProposal('safe', initialFilters), initialFilters, empty)
check(accepted.ok, 'safe proposal must be accepted')
if (!accepted.ok) throw new Error('expected safe proposal')
check(accepted.value.next.maxPrice === 400, 'price must become 400')
check(accepted.value.next.inStock === true, 'in-stock lock must remain true')
check(accepted.value.next.category === 'headphones', 'category must remain locked')
check(searchProducts(accepted.value.next).items[0]?.id === 'P01', 'confirmed search must find P01')
check(initialFilters.maxPrice === 300, 'proposal must not mutate current filters')
check(!validateProposal(mockModelProposal('unsafe', initialFilters), initialFilters, empty).ok, 'unsafe proposal must fail')
check(!validateProposal(mockModelProposal('stale', initialFilters), initialFilters, empty).ok, 'stale proposal must fail')
check(!validateProposal(mockModelProposal('safe', initialFilters), initialFilters, searchProducts(initialFilters, true)).ok, 'timeout must not count as empty')
check(!validateProposal({ baseVersion: versionOf(initialFilters), changes: { maxPrice: 900 }, reason: 'too broad' }, initialFilters, empty).ok, 'price over bound must fail')
check(!validateProposal({ baseVersion: versionOf(initialFilters), changes: { maxPrice: 400, color: 'any' }, reason: 'two fields' }, initialFilters, empty).ok, 'multiple changes must fail')
check(!validateProposal(mockModelProposal('safe', initialFilters), accepted.value.next, empty).ok, 'old search result must fail')
check(searchProducts(accepted.value.next, true).status === 'timeout', 'timeout state must be explicit')
console.log(`${assertions} offline assertions passed`)
