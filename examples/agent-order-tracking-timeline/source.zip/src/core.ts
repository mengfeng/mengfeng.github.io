export type Scenario = 'normal' | 'tracking_timeout' | 'late_event' | 'cancelled' | 'stale'
export type OrderStatus = 'shipped' | 'cancelled'
export type CarrierStatus = 'picked_up' | 'in_transit' | 'out_for_delivery' | 'delivered'
export interface OrderEvidence {
  source: 'order.read'
  orderId: string
  version: number
  status: OrderStatus
  trackingId: string | null
  checkedAt: string
}
export interface TrackingEvent {
  id: string
  status: CarrierStatus
  label: string
  occurredAt: string
  receivedAt: string
}
export interface TrackingEvidence {
  source: 'carrier.read'
  trackingId: string
  events: TrackingEvent[]
  checkedAt: string
}
export interface Snapshot {
  order: OrderEvidence
  tracking: TrackingEvidence | null
  trackingError: string | null
  requestedVersion: number
}
export type Verdict = 'ready' | 'partial' | 'conflict' | 'stale'
export interface Answer {
  verdict: Verdict
  text: string
  citations: string[]
  timeline: TrackingEvent[]
  notes: string[]
}

const NOW = '2026-11-11T12:00:00+08:00'
const event = (id: string, status: CarrierStatus, label: string, occurredAt: string, receivedAt: string): TrackingEvent => ({ id, status, label, occurredAt, receivedAt })
const BASE_EVENTS: TrackingEvent[] = [
  event('c1', 'picked_up', '承运商已揽收', '2026-11-10T09:00:00+08:00', '2026-11-10T09:03:00+08:00'),
  event('c2', 'in_transit', '包裹运输中', '2026-11-10T16:00:00+08:00', '2026-11-10T16:08:00+08:00'),
  event('c3', 'out_for_delivery', '配送员正在派送', '2026-11-11T08:30:00+08:00', '2026-11-11T08:33:00+08:00')
]

// Two read-only local demo tools. A real integration needs a server-side identity and authorization check.
export async function readOrder(scenario: Scenario): Promise<OrderEvidence> {
  return {
    source: 'order.read', orderId: 'DEMO-2048', version: scenario === 'stale' ? 8 : 7,
    status: scenario === 'cancelled' ? 'cancelled' : 'shipped',
    trackingId: 'TRACK-DEMO-7', checkedAt: NOW
  }
}
export async function readTracking(scenario: Scenario): Promise<TrackingEvidence> {
  if (scenario === 'tracking_timeout') throw new Error('物流查询超时（演示）')
  const late = event('c-late', 'in_transit', '中转站扫描记录晚到', '2026-11-10T18:00:00+08:00', '2026-11-11T11:00:00+08:00')
  const delivered = event('c4', 'delivered', '承运商记录为已签收', '2026-11-11T10:30:00+08:00', '2026-11-11T10:35:00+08:00')
  const events = scenario === 'late_event' ? [...BASE_EVENTS, late] : scenario === 'cancelled' ? [...BASE_EVENTS, delivered] : BASE_EVENTS
  return { source: 'carrier.read', trackingId: 'TRACK-DEMO-7', events, checkedAt: NOW }
}

export async function collect(scenario: Scenario, requestedVersion = 7): Promise<Snapshot> {
  const [orderResult, trackingResult] = await Promise.allSettled([readOrder(scenario), readTracking(scenario)])
  if (orderResult.status !== 'fulfilled') throw new Error('订单查询失败，无法核对身份与状态')
  return {
    order: orderResult.value,
    tracking: trackingResult.status === 'fulfilled' ? trackingResult.value : null,
    trackingError: trackingResult.status === 'rejected' ? '物流查询超时；只显示订单已知状态' : null,
    requestedVersion
  }
}

export function sortTimeline(events: TrackingEvent[]): TrackingEvent[] {
  return [...events].sort((a, b) => Date.parse(a.occurredAt) - Date.parse(b.occurredAt) || a.id.localeCompare(b.id))
}

// Fixed, simulated "model" candidate: it never calls an actual model or an external service.
export function mockCandidate(snapshot: Snapshot): { text: string; citations: string[] } {
  if (snapshot.order.version !== snapshot.requestedVersion) return { text: '订单状态已变化，请重新查询。', citations: ['order.read'] }
  if (snapshot.order.status === 'cancelled') return { text: '订单显示已取消；物流侧有不同记录，请人工核对，暂不能确认签收。', citations: ['order.read', 'carrier.read'] }
  if (!snapshot.tracking) return { text: '订单显示已发货，物流查询暂不可用，暂不能确认当前位置。', citations: ['order.read'] }
  return { text: '订单显示已发货；物流最新有效事件为配送中，尚无可核实的签收记录。', citations: ['order.read', 'carrier.read'] }
}

export function verify(snapshot: Snapshot, candidate: { text: string; citations: string[] }): Answer {
  const notes: string[] = []
  const timeline = snapshot.tracking ? sortTimeline(snapshot.tracking.events) : []
  const allowed = new Set<string>(['order.read', ...(snapshot.tracking ? ['carrier.read'] : [])])
  if (candidate.citations.length === 0 || candidate.citations.some(c => !allowed.has(c))) {
    return { verdict: 'conflict', text: '模拟回答引用了不存在的来源，已拒绝展示。', citations: [], timeline, notes: ['引用校验失败'] }
  }
  if (snapshot.order.version !== snapshot.requestedVersion) {
    return { verdict: 'stale', text: '订单版本已变化，请重新查询。', citations: ['order.read'], timeline: [], notes: ['旧快照已失效'] }
  }
  if (snapshot.tracking && snapshot.order.trackingId !== snapshot.tracking.trackingId) {
    return { verdict: 'conflict', text: '订单与物流单号不一致，请人工核对。', citations: ['order.read'], timeline: [], notes: ['轨迹归属校验失败'] }
  }
  if (snapshot.order.status === 'cancelled') {
    notes.push('取消订单与承运商记录需要人工核对')
    return { verdict: 'conflict', text: '订单已取消；物流侧记录不能直接作为签收结论。请人工核对。', citations: ['order.read', ...(snapshot.tracking ? ['carrier.read'] : [])], timeline, notes }
  }
  if (!snapshot.tracking) {
    notes.push(snapshot.trackingError ?? '物流暂不可用')
    return { verdict: 'partial', text: '订单显示已发货；物流暂不可用，不能确认当前位置或签收。', citations: ['order.read'], timeline: [], notes }
  }
  if (timeline.some((e, i) => i > 0 && Date.parse(e.receivedAt) < Date.parse(timeline[i-1].receivedAt))) notes.push('轨迹按事件发生时间重排；有晚到记录')
  const latest = timeline.at(-1)
  if (!latest) return { verdict: 'partial', text: '订单已发货，但没有可核实的物流事件。', citations: ['order.read', 'carrier.read'], timeline, notes }
  if (latest.status === 'delivered') {
    if (!candidate.text.includes('签收')) return { verdict: 'conflict', text: '模拟回答与物流事件不一致，已拒绝展示。', citations: [], timeline, notes }
    return { verdict: 'ready', text: '订单已发货；承运商最新记录为已签收。该记录仍以承运商事件为准。', citations: ['order.read', 'carrier.read'], timeline, notes }
  }
  if (candidate.text.includes('已签收') && !candidate.text.includes('尚无') && !candidate.text.includes('不能确认')) {
    return { verdict: 'conflict', text: '没有签收事件，已拒绝模拟回答。', citations: [], timeline, notes }
  }
  return { verdict: 'ready', text: `订单已发货；最新物流事件：${latest.label}。尚无可核实的签收记录。`, citations: ['order.read', 'carrier.read'], timeline, notes }
}
