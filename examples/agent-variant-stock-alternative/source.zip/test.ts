import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { resolveCurrent, resolveRecommendation } from './src/core'
import { initial, scenarios } from './src/fixtures'

const samples = [
  ['missing-stock', 'sold-out', 'ready'],
  ['not-offered', 'not-offered', 'ready'],
  ['partial', 'unknown', 'none'],
  ['unknown', 'unknown', 'none'],
  ['wrong-size', 'sold-out', 'rejected'],
  ['stale', 'sold-out', 'rejected'],
  ['unavailable', 'sold-out', 'rejected'],
] as const

for (const [id, current, suggested] of samples) {
  test(id, () => {
    const sample = scenarios.find(item => item.id === id)
    assert.ok(sample)
    assert.equal(resolveCurrent(sample.snapshot, initial).kind, current)
    assert.equal(resolveRecommendation(sample.snapshot, initial, true, sample.candidate).kind, suggested)
  })
}

const { snapshot, candidate } = scenarios[0]

test('存在一个有货的颜色和一个有货的尺码，仍不能推断交叉组合有货', () => {
  assert.equal(resolveCurrent(snapshot, { color: 'linen', size: 'M' }).kind, 'available')
  assert.equal(resolveCurrent(snapshot, { color: 'charcoal', size: 'S' }).kind, 'available')
  assert.equal(resolveCurrent(snapshot, initial).kind, 'sold-out')
})

test('未允许换色时不展示建议，允许后保持尺码不变', () => {
  assert.deepEqual(resolveRecommendation(snapshot, initial, false, candidate), { kind: 'none' })
  const result = resolveRecommendation(snapshot, initial, true, candidate)
  assert.equal(result.kind, 'ready')
  assert.equal(result.variant.id, 'CH-S')
  assert.equal(result.variant.size, initial.size)
  assert.equal(initial.color, 'linen')
})

test('用户改选有货组合后，不再使用旧候选', () => {
  assert.equal(resolveRecommendation(snapshot, { ...initial, size: 'M' }, true, candidate).kind, 'none')
})

test('原组合库存冲突出错时不出建议', () => {
  const conflict = { ...snapshot, variants: [...snapshot.variants, { ...snapshot.variants[0], id: 'duplicate' }] }
  assert.equal(resolveCurrent(conflict, initial).kind, 'conflict')
  assert.equal(resolveRecommendation(conflict, initial, true, candidate).kind, 'none')
})

test('备选 SKU 或组合重复时拒绝采用', () => {
  const source = snapshot.variants[2]
  for (const extra of [{ ...source, id: 'another-id' }, { ...source, color: 'linen', size: 'M' } as const]) {
    const conflict = { ...snapshot, variants: [...snapshot.variants, extra] }
    assert.equal(resolveRecommendation(conflict, initial, true, candidate).kind, 'rejected')
  }
})

test('证据必须绑定同一商品组、选择及备选 SKU', () => {
  const base = { snapshotId: snapshot.id, groupId: snapshot.groupId, requestedColor: initial.color,
    requestedSize: initial.size, variantId: 'CH-S' }
  for (const invalid of [null, [], {}, { ...base, groupId: 'other' }, { ...base, requestedSize: 'M' },
    { ...base, variantId: 3 }, { ...base, variantId: 'missing' }]) {
    assert.equal(resolveRecommendation(snapshot, initial, true, invalid).kind, 'rejected')
  }
})
