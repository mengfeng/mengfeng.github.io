import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { planMerge } from './src/core'
import { base, scenarios } from './src/fixtures'

test('独立字段修改可合并，并保留人工标题', () => {
  const sample = scenarios[0]
  const result = planMerge(base, sample.local, sample.candidate)
  assert.equal(result.kind, 'ready')
  assert.deepEqual(result.next, { ...sample.local, summary: '握柄宽大，适合日常热饮。' })
  assert.equal(result.changeCount, 1)
  assert.equal(sample.local.summary, base.copy.summary)
})

test('同字段两个值不同时，未选择前不生成合并结果', () => {
  const sample = scenarios[1]
  const result = planMerge(base, sample.local, sample.candidate)
  assert.equal(result.kind, 'ready')
  assert.equal(result.rows[0].kind, 'conflict')
  assert.equal(result.next, undefined)
})

test('显式保留人工标题后，可只合入其他字段', () => {
  const sample = scenarios[1]
  const result = planMerge(base, sample.local, sample.candidate, { title: { side:'local', local: sample.local.title } })
  assert.equal(result.kind, 'ready')
  assert.equal(result.next?.title,sample.local.title)
  assert.equal(result.changeCount,1)
})

test('选择 Agent 的标题后，返回两项修改', () => {
  const sample = scenarios[1]
  const result = planMerge(base, sample.local, sample.candidate, { title: { side:'agent', local: sample.local.title } })
  assert.equal(result.kind, 'ready')
  assert.equal(result.next?.title,'海边午后马克杯')
  assert.equal(result.changeCount,2)
})

test('选择一边后，人工继续编辑该字段会使旧决定失效', () => {
  const sample = scenarios[1]
  const result = planMerge(base, { ...sample.local, title:'手工重写' }, sample.candidate,
    { title: { side:'agent', local: sample.local.title } })
  assert.equal(result.kind,'ready')
  assert.equal(result.next,undefined)
})

test('双方得到同一标题时无需重复应用', () => {
  const sample = scenarios[2]
  const result = planMerge(base, sample.local, sample.candidate)
  assert.equal(result.kind,'ready')
  assert.equal(result.rows[0].kind,'same')
  assert.equal(result.changeCount,0)
})

test('明确清空角标有别于候选未提及角标', () => {
  const sample = scenarios[3]
  const result = planMerge(base, sample.local, sample.candidate)
  assert.equal(result.kind,'ready')
  assert.equal(result.next?.badge,'')
  assert.equal(result.next?.title,sample.local.title)
})

test('版本或商品不匹配时，候选不得合并', () => {
  assert.equal(planMerge(base,scenarios[4].local,scenarios[4].candidate).kind,'stale')
  assert.equal(planMerge(base,base.copy,{productId:'OTHER',baseRevision:base.revision,patch:{}}).kind,'stale')
})

test('意外字段、空标题与错误结构使整份候选失效', () => {
  assert.equal(planMerge(base,scenarios[5].local,scenarios[5].candidate).kind,'invalid')
  for (const patch of [null, ['bad'], { title: ' ' }, { summary: 123 }]) {
    assert.equal(planMerge(base,base.copy,{productId:base.productId,baseRevision:base.revision,patch}).kind,'invalid')
  }
})
