import assert from 'node:assert/strict'
import { collect, mockCandidate, parseCandidate, verify, type Collected, type Scenario } from './src/core'

let checks = 0
function equal(actual: unknown, expected: unknown): void { assert.equal(actual, expected); checks++ }
function ok(value: unknown): void { assert.ok(value); checks++ }
async function runScenario(scenario: Scenario) {
  const evidence = await collect(scenario, 3)
  return { evidence, assessment: verify(evidence, 3, mockCandidate(scenario, 3)) }
}
const ready = await runScenario('ready')
equal(ready.assessment.state, 'ready')
equal(ready.assessment.draft?.primaryId, 'T-DEMO-41')
equal(ready.assessment.draft?.secondaryId, 'T-DEMO-42')
equal(ready.assessment.draft?.orderId, 'ORD-DEMO-72')
equal(ready.assessment.draft?.sourceIds.length, 3)
if (ready.evidence.tickets.kind === 'ok') {
  equal(ready.evidence.tickets.value.first.accountId, 'acct-demo-7')
  equal(ready.evidence.tickets.value.second.status, 'open')
} else throw Error('ready fixture unavailable')
for (const scenario of ['different_order','different_issue','closed_ticket','forged_source','malformed_candidate','wrong_primary'] as const) {
  const x = await runScenario(scenario)
  equal(x.assessment.state, 'rejected')
  equal(x.assessment.draft, null)
}
for (const scenario of ['ticket_timeout','account_timeout','policy_timeout','foreign_ticket'] as const) {
  const x = await runScenario(scenario)
  equal(x.assessment.state, 'blocked')
  equal(x.assessment.draft, null)
}
const foreign = await runScenario('foreign_ticket')
equal(foreign.evidence.tickets.kind, 'error')
ok(!JSON.stringify(foreign.evidence).includes('acct-demo-8'))
const stale = await runScenario('stale_ticket')
equal(stale.assessment.state, 'stale')
equal(stale.assessment.draft, null)
if (ready.evidence.tickets.kind === 'ok') {
  const changed: Collected = { ...ready.evidence, tickets: { kind: 'ok', value: { ...ready.evidence.tickets.value,
    first: { ...ready.evidence.tickets.value.first, revision: 4 } } } }
  equal(verify(changed, 3, mockCandidate('ready', 3)).state, 'stale')
}
const good = mockCandidate('ready', 3)
ok(parseCandidate(good) !== null)
equal(parseCandidate(null), null)
equal(parseCandidate([]), null)
equal(parseCandidate({ ...good as object, decision: 'merge_now' }), null)
equal(parseCandidate({ ...good as object, primaryId: 'T-DEMO-41', secondaryId: 'T-DEMO-41' }), null)
equal(parseCandidate({ ...good as object, sourceIds: ['x'] }), null)
equal(parseCandidate({ ...good as object, revisions: [0, 3] }), null)
equal(parseCandidate({ ...good as object, sourceIds: [42, 'x', 'y'] }), null)
const wrongOwnership: Collected = { ...ready.evidence,
  ownership: { kind:'ok', value: { accountId:'acct-demo-7', allowedTicketIds:['T-DEMO-41'], sourceId:'account.read#demo@r1' } } }
equal(verify(wrongOwnership, 3, good).state, 'blocked')
equal(verify(wrongOwnership, 3, good).draft, null)
equal(verify(ready.evidence, 3, { ...good as object, revisions:[2,3] }).state, 'stale')
console.log(`${checks} offline assertions passed`)
