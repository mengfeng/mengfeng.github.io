import { computed, createApp, ref, watch } from 'vue'
import { decide, formatYuan, mockAgentAnswer, readDemoTools, selectionKey, validateAnswer, type AnswerCheck, type ModelMode, type Revision, type Scenario, type Selection, type Snapshot } from './core'

const verdictLabel = { eligible: '演示规则：符合使用条件', ineligible: '演示规则：当前不可用', unknown: '演示规则：暂不能判断' } as const

createApp({
  setup() {
    const scenario = ref<Scenario>('eligible')
    const revision = ref<Revision>(1)
    const mode = ref<ModelMode>('bounded')
    const snapshot = ref<Snapshot | null>(null)
    const check = ref<AnswerCheck | null>(null)
    const message = ref('先查询购物车与优惠券规则。')
    const current = (): Selection => ({ scenario: scenario.value, revision: revision.value })
    const query = () => { snapshot.value = readDemoTools(current()); check.value = null; message.value = '两项本地只读函数已返回，请核验模拟回答。' }
    const answer = () => {
      if (!snapshot.value) { message.value = '请先查询演示数据。'; return }
      check.value = validateAnswer(mockAgentAnswer(snapshot.value, mode.value), snapshot.value, current())
      message.value = check.value.ok ? verdictLabel[check.value.decision.verdict] : check.value.error
    }
    const reset = () => { scenario.value = 'eligible'; revision.value = 1; mode.value = 'bounded'; snapshot.value = null; check.value = null; message.value = '已重置演示。' }
    const isCurrent = computed(() => snapshot.value?.key === selectionKey(current()))
    const decision = computed(() => snapshot.value && isCurrent.value ? decide(snapshot.value) : null)
    watch([scenario, revision], () => { check.value = null; message.value = '条件已改变，请重新查询。' })
    watch(mode, () => { check.value = null })
    return { scenario, revision, mode, snapshot, check, message, query, answer, reset, isCurrent, decision, verdictLabel, formatYuan }
  },
  template: `
  <main class="shell">
    <header class="hero"><div class="eyebrow">AGENT / COUPON LAB 09</div><h1>这张券为什么不能用？</h1><p>先核对购物车和券规则，再让 Agent 解释资格。所有金额与规则都是演示数据。</p></header>
    <section class="panel controls" aria-label="演示条件"><div class="section-head"><h2>演示条件</h2><button class="ghost" type="button" @click="reset">重置</button></div>
      <div class="form-grid"><label>工具结果 <select v-model="scenario"><option value="eligible">符合门槛</option><option value="threshold">未达到门槛</option><option value="excluded">商品不适用</option><option value="expired">券已过期</option><option value="timeout">规则查询超时</option><option value="stale">规则结果过期</option></select></label>
      <label>购物车版本 <select v-model.number="revision"><option :value="1">版本 1</option><option :value="2">版本 2</option></select></label>
      <label>模拟 Agent 输出 <select v-model="mode"><option value="bounded">按证据回答</option><option value="overpromise">伪造证据并承诺</option></select></label></div>
      <p class="muted">固定演示时间：2026-11-09 20:00（北京时间）。优惠券 SAVE20 的适用商品仅为 TEA，门槛 ¥100.00，减 ¥20.00。这里没有实际优惠券。</p>
      <div class="actions"><button type="button" @click="query">① 查询购物车与规则</button><button type="button" @click="answer">② 验证模拟回答</button></div>
    </section>
    <div class="layout"><section class="panel" aria-label="工具结果"><h2>只读工具结果</h2><p v-if="!snapshot" class="muted">尚未查询。</p><template v-else>
      <div class="tool-card"><strong>购物车工具</strong><small>{{ snapshot.cart.sourceId }}</small><p>版本 {{ snapshot.cart.revision }} · {{ snapshot.cart.lines.map(x => x.sku + ' × ' + x.quantity).join('，') }}<br>查询时间 {{ snapshot.cart.checkedAt }}</p></div>
      <div class="tool-card"><strong>优惠券规则工具</strong><small>{{ snapshot.rule.status === 'ok' ? snapshot.rule.sourceId : snapshot.rule.requestId }}</small><p v-if="snapshot.rule.status === 'ok'">适用商品 {{ snapshot.rule.eligibleSkus.join('，') }} · 门槛 ¥{{ formatYuan(snapshot.rule.minCents) }}<br>到期 {{ snapshot.rule.expiresAt }} · 查询时间 {{ snapshot.rule.checkedAt }}</p><p v-else class="warning">规则查询超时；没有可用的规则证据。</p></div>
      <p class="muted">切换条件后，旧结果保留供比较，但不得用于新回答。</p></template></section>
      <section class="panel" aria-label="回答核验"><h2>回答核验</h2><p role="status" class="status">{{ message }}</p>
        <p v-if="snapshot && !isCurrent" class="warning">购物车或场景已变化，请重新查询。</p>
        <p v-if="decision" class="rule">{{ verdictLabel[decision.verdict] }}：{{ decision.reason }}</p>
        <p v-if="check?.ok" class="success">已接受模拟回答：{{ check.decision.reason }}<br>证据：{{ check.sourceRefs.length ? check.sourceRefs.join(' + ') : '规则查询失败，无资格证据' }}</p>
        <p v-else-if="check" class="error">模拟回答被拒绝：{{ check.error }}<template v-if="isCurrent"><br>页面保留规则结论：{{ verdictLabel[check.fallback.verdict] }}</template></p>
        <p v-else class="muted">模型只提供候选解释；页面按工具数据重新计算并显示结论。</p>
      </section></div>
    <footer>本页只运行本地固定函数，没有真实模型、真实优惠券、真实购物车或结算请求；“符合条件”不表示优惠已到账。</footer>
  </main>`
}).mount('#app')
