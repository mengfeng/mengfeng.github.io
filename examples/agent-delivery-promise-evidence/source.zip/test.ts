const equal = (actual: unknown, expected: unknown): void => { if (actual !== expected) throw new Error(`expected ${String(expected)}, got ${String(actual)}`) }
import { DEMO_NOW, decide, initialSelection, mockAgentAnswer, readDemoTools, validateAnswer, type Scenario } from './src/core'

const snapshot = readDemoTools(initialSelection)
equal(snapshot.toolCalls, 2)
equal(decide(snapshot).verdict, 'tomorrow')
equal(validateAnswer(mockAgentAnswer(snapshot, 'bounded'), snapshot, initialSelection).ok, true)
equal(validateAnswer(mockAgentAnswer(snapshot, 'overpromise'), snapshot, initialSelection).ok, false)
for (const [scenario, expected] of [
  ['noStock', 'unavailable'], ['outside', 'unavailable'], ['stockTimeout', 'unknown'],
  ['routeTimeout', 'unknown'], ['stale', 'unknown']
] as const) {
  const selection = { ...initialSelection, scenario: scenario as Scenario }
  const tools = readDemoTools(selection)
  equal(decide(tools).verdict, expected)
  equal(validateAnswer(mockAgentAnswer(tools, 'bounded'), tools, selection).ok, true)
}
equal(validateAnswer(mockAgentAnswer(snapshot, 'bounded'), snapshot, { ...initialSelection, area: 'B' }).ok, false)
equal(validateAnswer({ key: snapshot.key, verdict: 'tomorrow', reason: 'ok', evidence: ['fake', 'fake'] }, snapshot, initialSelection).ok, false)
equal(validateAnswer({ key: snapshot.key, verdict: 'unavailable', reason: 'ok', evidence: [snapshot.inventory.sourceId, snapshot.delivery.sourceId] }, snapshot, initialSelection).ok, false)
equal(validateAnswer({ key: snapshot.key, verdict: 'tomorrow', reason: 'ok', evidence: [snapshot.inventory.sourceId, snapshot.delivery.sourceId], secret: true }, snapshot, initialSelection).ok, false)
equal(validateAnswer(null, snapshot, initialSelection).ok, false)
equal(decide(snapshot, '2026-11-08T12:01:00+08:00').verdict, 'unknown')
equal(decide(snapshot, '2026-11-08T09:55:00+08:00').verdict, 'unknown')
equal(DEMO_NOW, '2026-11-08T10:00:00+08:00')
console.log('22 core assertions passed; all data and model outputs are fixed demonstrations.')
