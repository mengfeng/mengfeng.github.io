import { createApp, ref } from 'vue'
import { collect, mockCandidate, verify, type Answer, type Scenario, type Snapshot } from './core'

const options: { value: Scenario; label: string }[] = [
  { value: 'normal', label: '正常：正在派送' },
  { value: 'tracking_timeout', label: '物流查询超时' },
  { value: 'late_event', label: '轨迹晚到' },
  { value: 'cancelled', label: '订单已取消且轨迹冲突' },
  { value: 'stale', label: '订单版本变化' }
]
const formatTime = (iso: string): string => new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(iso))

createApp({
  setup() {
    const scenario = ref<Scenario>('normal')
    const busy = ref(false)
    const snapshot = ref<Snapshot | null>(null)
    const answer = ref<Answer | null>(null)
    const error = ref('')
    const forged = ref(false)
    const uiVersion = ref(7)
    const onQuery = async () => {
      busy.value = true; error.value = ''; answer.value = null; snapshot.value = null
      try {
        const evidence = await collect(scenario.value, 7)
        snapshot.value = evidence
        const candidate = mockCandidate(evidence)
        answer.value = verify(evidence, forged.value ? { ...candidate, citations: [...candidate.citations, 'warehouse.write'] } : candidate)
      } catch (e) { error.value = e instanceof Error ? e.message : '未知错误' }
      finally { busy.value = false }
    }
    const invalidate = () => { uiVersion.value++; if (answer.value) answer.value = { verdict: 'stale', text: '页面订单状态已变化，请重新查询。', citations: [], timeline: [], notes: ['页面版本变化'] } }
    return { options, scenario, busy, snapshot, answer, error, forged, uiVersion, onQuery, invalidate, formatTime }
  },
  template: `
    <main class="shell">
      <header class="hero"><div class="eyebrow">AGENT / ORDER TRACKING</div><h1>包裹到哪了？</h1><p>用订单和承运商两项只读证据生成一条可信的物流时间线。所有数据、工具和回答均为本地演示；没有真实模型、订单服务或对外消息。</p></header>
      <section class="panel" aria-labelledby="controls-title"><h2 id="controls-title">选择一个演示场景</h2><div class="controls"><label>场景<select v-model="scenario"><option v-for="item in options" :key="item.value" :value="item.value">{{ item.label }}</option></select></label><label class="checkbox"><input type="checkbox" v-model="forged"> 注入伪造引用</label><div class="version">页面订单版本 <strong>{{ uiVersion }}</strong></div></div><div class="actions"><button @click="onQuery" :disabled="busy">{{ busy ? '查询中…' : '查询并核对' }}</button><button class="quiet" @click="invalidate">模拟页面状态变化</button></div><p class="fine">查询后更改页面版本会使已显示结果失效。两个工具都是本地 Promise；不会执行写操作。</p></section>
      <section v-if="error" class="panel alert" role="alert">{{ error }}</section>
      <div v-if="snapshot && answer" class="grid"><section class="panel"><h2>证据快照</h2><dl><dt>订单工具</dt><dd>{{ snapshot.order.source }} · v{{ snapshot.order.version }} · {{ snapshot.order.status === 'cancelled' ? '已取消' : '已发货' }}</dd><dt>物流工具</dt><dd>{{ snapshot.tracking ? snapshot.tracking.source + ' · ' + snapshot.tracking.events.length + ' 条事件' : '查询超时' }}</dd><dt>核对时间</dt><dd><time :datetime="snapshot.order.checkedAt">{{ formatTime(snapshot.order.checkedAt) }}</time></dd></dl><p class="fine">演示订单 DEMO-2048；来源是本地模拟工具，并非真实物流数据。</p></section><section class="panel"><div class="panel-head"><h2>Agent 回答</h2><span class="status" :class="answer.verdict">{{ { ready:'已核对',partial:'部分已知',conflict:'需核对',stale:'已失效' }[answer.verdict] }}</span></div><p class="answer" aria-live="polite">{{ answer.text }}</p><p class="fine">引用：<span v-if="!answer.citations.length">无</span><code v-for="source in answer.citations" :key="source">{{ source }}</code></p><ul v-if="answer.notes.length" class="notes"><li v-for="note in answer.notes" :key="note">{{ note }}</li></ul></section></div>
      <section v-if="answer" class="panel timeline-panel"><h2>事件时间线</h2><p class="fine">按事件发生时间排序，晚到记录不会覆盖更晚发生的事件；接收时间另列。</p><ol v-if="answer.timeline.length" class="timeline"><li v-for="item in answer.timeline" :key="item.id"><div class="dot"></div><div><strong>{{ item.label }}</strong><p>发生 <time :datetime="item.occurredAt">{{ formatTime(item.occurredAt) }}</time> · 收到 <time :datetime="item.receivedAt">{{ formatTime(item.receivedAt) }}</time></p></div></li></ol><p v-else class="muted">当前没有可展示的物流事件。</p></section>
      <footer>离线教学示例 · 没有真实模型调用 · 没有付款、退款或消息发送</footer>
    </main>`
}).mount('#app')
