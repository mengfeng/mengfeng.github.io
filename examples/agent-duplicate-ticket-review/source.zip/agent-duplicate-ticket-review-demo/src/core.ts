export type Scenario =
  | 'ready' | 'foreign_ticket' | 'different_order' | 'different_issue'
  | 'closed_ticket' | 'stale_ticket' | 'ticket_timeout' | 'account_timeout'
  | 'policy_timeout' | 'forged_source' | 'malformed_candidate' | 'wrong_primary'

export type Ticket = {
  id: string
  accountId: string
  orderId: string
  issueCode: 'delivery_delay' | 'damaged_item'
  status: 'open' | 'closed'
  revision: number
  summary: string
}
export type TicketPair = { first: Ticket; second: Ticket; sourceId: string }
export type Ownership = { accountId: string; allowedTicketIds: string[]; sourceId: string }
export type MergePolicy = { rule: 'same-account-order-issue-open'; sourceId: string }
export type Evidence<T> = { kind: 'ok'; value: T } | { kind: 'error'; message: string }
export type Collected = {
  tickets: Evidence<TicketPair>
  ownership: Evidence<Ownership>
  policy: Evidence<MergePolicy>
}
export type MergeDraft = {
  primaryId: string
  secondaryId: string
  orderId: string
  issueCode: Ticket['issueCode']
  reason: string
  sourceIds: string[]
}
export type Assessment = {
  state: 'ready' | 'blocked' | 'stale' | 'rejected'
  message: string
  draft: MergeDraft | null
}
type Candidate = {
  decision: 'suggest_merge'
  primaryId: string
  secondaryId: string
  revisions: [number, number]
  sourceIds: [string, string, string]
}

function asEvidence<T>(settled: PromiseSettledResult<T>, label: string): Evidence<T> {
  return settled.status === 'fulfilled'
    ? { kind: 'ok', value: settled.value }
    : { kind: 'error', message: `${label}未取得（固定模拟）` }
}

// 教学夹具：把账户归属检查放在读取工具内部，拒绝返回其他账户的工单详情。
// 真实系统必须从服务端会话识别账户，并逐对象鉴权；浏览器传参不可信。
function readTickets(scenario: Scenario, revision: number, sessionAccountId: string): Promise<TicketPair> {
  if (scenario === 'ticket_timeout') return Promise.reject(new Error('simulated timeout'))
  const actualRevision = scenario === 'stale_ticket' ? revision - 1 : revision
  const first: Ticket = {
    id: 'T-DEMO-41', accountId: sessionAccountId, orderId: 'ORD-DEMO-72',
    issueCode: 'delivery_delay', status: 'open', revision: actualRevision,
    summary: '物流停在分拨中心，询问预计送达时间。'
  }
  const second: Ticket = {
    id: 'T-DEMO-42', accountId: scenario === 'foreign_ticket' ? 'acct-demo-8' : sessionAccountId,
    orderId: scenario === 'different_order' ? 'ORD-DEMO-99' : 'ORD-DEMO-72',
    issueCode: scenario === 'different_issue' ? 'damaged_item' : 'delivery_delay',
    status: scenario === 'closed_ticket' ? 'closed' : 'open', revision: actualRevision,
    summary: scenario === 'different_issue' ? '收到商品后发现外包装破损。' : '同一订单的物流进度仍没有更新。'
  }
  if (first.accountId !== sessionAccountId || second.accountId !== sessionAccountId) {
    return Promise.reject(new Error('not authorized'))
  }
  return Promise.resolve({ first, second, sourceId: `tickets.read#pair@r${actualRevision}` })
}

function readOwnership(scenario: Scenario, sessionAccountId: string): Promise<Ownership> {
  if (scenario === 'account_timeout') return Promise.reject(new Error('simulated timeout'))
  return Promise.resolve({
    accountId: sessionAccountId,
    allowedTicketIds: scenario === 'foreign_ticket' ? ['T-DEMO-41'] : ['T-DEMO-41', 'T-DEMO-42'],
    sourceId: 'account.read#demo@r1'
  })
}

function readPolicy(scenario: Scenario): Promise<MergePolicy> {
  if (scenario === 'policy_timeout') return Promise.reject(new Error('simulated timeout'))
  return Promise.resolve({ rule: 'same-account-order-issue-open', sourceId: 'policy.read#merge@r2' })
}

export async function collect(scenario: Scenario, revision: number): Promise<Collected> {
  const sessionAccountId = 'acct-demo-7'
  const [tickets, ownership, policy] = await Promise.allSettled([
    readTickets(scenario, revision, sessionAccountId),
    readOwnership(scenario, sessionAccountId),
    readPolicy(scenario)
  ] as const)
  return {
    tickets: asEvidence(tickets, '工单'),
    ownership: asEvidence(ownership, '账户归属'),
    policy: asEvidence(policy, '合并规则')
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
function validRevision(value: unknown): value is number {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 1
}
function validId(value: unknown): value is string {
  return typeof value === 'string' && /^T-DEMO-\d{1,3}$/.test(value)
}

// 候选被当作未知输入；编译期类型不会自动验证运行时模型输出。
export function parseCandidate(value: unknown): Candidate | null {
  if (!isRecord(value) || value.decision !== 'suggest_merge' ||
      !validId(value.primaryId) || !validId(value.secondaryId) ||
      value.primaryId === value.secondaryId || !Array.isArray(value.revisions) ||
      value.revisions.length !== 2 || !validRevision(value.revisions[0]) ||
      !validRevision(value.revisions[1]) || !Array.isArray(value.sourceIds) ||
      value.sourceIds.length !== 3) return null
  const ids: string[] = []
  for (const id of value.sourceIds as unknown[]) {
    if (typeof id !== 'string' || id.length < 1 || id.length > 80) return null
    ids.push(id)
  }
  return {
    decision: 'suggest_merge', primaryId: value.primaryId,
    secondaryId: value.secondaryId, revisions: [value.revisions[0], value.revisions[1]],
    sourceIds: [ids[0], ids[1], ids[2]]
  }
}

export function mockCandidate(scenario: Scenario, revision: number): unknown {
  const value = {
    decision: 'suggest_merge',
    primaryId: scenario === 'wrong_primary' ? 'T-DEMO-42' : 'T-DEMO-41',
    secondaryId: scenario === 'wrong_primary' ? 'T-DEMO-41' : 'T-DEMO-42',
    revisions: [revision, revision],
    sourceIds: [
      `tickets.read#pair@r${revision}`,
      'account.read#demo@r1',
      scenario === 'forged_source' ? 'policy.read#other@r2' : 'policy.read#merge@r2'
    ]
  }
  return scenario === 'malformed_candidate' ? { ...value, revisions: ['3', revision] } : value
}

function result(state: Assessment['state'], message: string): Assessment {
  return { state, message, draft: null }
}

export function verify(collected: Collected, currentRevision: number, rawCandidate: unknown): Assessment {
  if (collected.tickets.kind !== 'ok' || collected.ownership.kind !== 'ok' || collected.policy.kind !== 'ok') {
    return result('blocked', '只读证据不完整或无权读取；不显示合并建议。')
  }
  const { first, second, sourceId } = collected.tickets.value
  const ownership = collected.ownership.value
  const policy = collected.policy.value
  if (first.revision !== currentRevision || second.revision !== currentRevision) {
    return result('stale', '工单版本已变化，请重读后再判断。')
  }
  if (first.accountId !== ownership.accountId || second.accountId !== ownership.accountId ||
      !ownership.allowedTicketIds.includes(first.id) || !ownership.allowedTicketIds.includes(second.id)) {
    return result('blocked', '账户归属未通过；不显示合并建议。')
  }
  if (policy.rule !== 'same-account-order-issue-open' || first.status !== 'open' || second.status !== 'open' ||
      first.orderId !== second.orderId || first.issueCode !== second.issueCode) {
    return result('rejected', '两张工单不满足演示规则；保留独立处理。')
  }
  const candidate = parseCandidate(rawCandidate)
  if (candidate === null) return result('rejected', '模拟候选结构无效。')
  if (candidate.revisions[0] !== first.revision || candidate.revisions[1] !== second.revision) {
    return result('stale', '候选引用的工单版本已过期。')
  }
  const expectedSources: [string, string, string] = [sourceId, ownership.sourceId, policy.sourceId]
  if (candidate.sourceIds.some((id, index) => id !== expectedSources[index])) {
    return result('rejected', '候选引用与本轮证据不一致。')
  }
  if (candidate.primaryId !== first.id || candidate.secondaryId !== second.id) {
    return result('rejected', '候选主次工单与本轮读取结果不一致。')
  }
  return {
    state: 'ready', message: '演示规则通过；是否重复仍需客服人工判断。',
    draft: {
      primaryId: first.id, secondaryId: second.id, orderId: first.orderId,
      issueCode: first.issueCode,
      reason: '同一演示账户、订单与问题类型，且两张工单仍开放。',
      sourceIds: expectedSources
    }
  }
}
