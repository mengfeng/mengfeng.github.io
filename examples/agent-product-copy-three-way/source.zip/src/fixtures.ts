import type { Base, Copy } from './core'

export const base: Base = {
  productId: 'MUG-DEMO', revision: 'copy-r4',
  copy: { title: '午后马克杯', summary: '适合日常使用。', badge: '新品' },
}

function scenario(id: string, label: string, local: Partial<Copy>, patch: unknown,
  rule: Record<string, unknown> = {}) {
  const candidate: unknown = { productId: base.productId, baseRevision: base.revision, patch, ...rule }
  return { id, label, local: { ...base.copy, ...local }, candidate }
}

export const scenarios = [
  scenario('independent', '双方修改不同字段', { title: '海盐蓝马克杯' }, { summary: '握柄宽大，适合日常热饮。' }),
  scenario('conflict', '双方给标题写了不同结果', { title: '海盐蓝马克杯' }, { title: '海边午后马克杯', summary: '握柄宽大，适合日常热饮。' }),
  scenario('same', '双方写成相同标题', { title: '海盐蓝马克杯' }, { title: '海盐蓝马克杯' }),
  scenario('clear', '建议清空旧角标', { title: '海盐蓝马克杯' }, { badge: '' }),
  scenario('stale', '候选基于旧版本', { title: '海盐蓝马克杯' }, { summary: '握柄宽大，适合日常热饮。' }, { baseRevision: 'copy-r3' }),
  scenario('invalid', '候选含有未开放字段', {}, { title: '海盐蓝马克杯', price: '9.9' }),
]
