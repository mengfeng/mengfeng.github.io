export const DEMO_NOW = '2026-11-09T20:00:00+08:00'
const CHECKED_AT = '2026-11-09T19:59:00+08:00'
const STALE_AT = '2026-11-09T19:50:00+08:00'
const MAX_AGE_MS = 3 * 60 * 1000

export type Scenario = 'eligible' | 'threshold' | 'excluded' | 'expired' | 'timeout' | 'stale'
export type Revision = 1 | 2
export type ModelMode = 'bounded' | 'overpromise'
export type Selection = { scenario: Scenario; revision: Revision }
export type CartLine = { sku: string; quantity: number; unitCents: number }
export type CartOk = { status: 'ok'; sourceId: string; checkedAt: string; revision: Revision; lines: CartLine[] }
export type CartResult = CartOk
export type RuleOk = { status: 'ok'; sourceId: string; checkedAt: string; couponId: 'SAVE20'; minCents: number; discountCents: number; eligibleSkus: string[]; expiresAt: string; ruleVersion: 'v1' }
export type RuleTimeout = { status: 'timeout'; requestId: string }
export type RuleResult = RuleOk | RuleTimeout
export type Snapshot = { key: string; cart: CartResult; rule: RuleResult }
export type Verdict = 'eligible' | 'ineligible' | 'unknown'
export type Decision = { verdict: Verdict; reason: string; qualifiedCents: number }
export type AnswerCheck = { ok: true; decision: Decision; sourceRefs: string[] } | { ok: false; error: string; fallback: Decision }

export function selectionKey(selection: Selection): string {
  return `${selection.scenario}:cart-r${selection.revision}`
}

function cartLines(scenario: Scenario): CartLine[] {
  if (scenario === 'threshold') return [{ sku: 'TEA', quantity: 1, unitCents: 6800 }, { sku: 'CUP', quantity: 1, unitCents: 5400 }]
  if (scenario === 'excluded') return [{ sku: 'CUP', quantity: 2, unitCents: 5400 }]
  return [{ sku: 'TEA', quantity: 2, unitCents: 6800 }, { sku: 'CUP', quantity: 1, unitCents: 5400 }]
}

export function readCart(selection: Selection): CartOk {
  const key = selectionKey(selection)
  return { status: 'ok', sourceId: `cart:${key}`, checkedAt: CHECKED_AT, revision: selection.revision, lines: cartLines(selection.scenario) }
}

export function readCouponRule(selection: Selection): RuleResult {
  const key = selectionKey(selection)
  if (selection.scenario === 'timeout') return { status: 'timeout', requestId: `rule-request:${key}` }
  return {
    status: 'ok', sourceId: `rule:SAVE20:v1:${key}`,
    checkedAt: selection.scenario === 'stale' ? STALE_AT : CHECKED_AT,
    couponId: 'SAVE20', minCents: 10000, discountCents: 2000,
    eligibleSkus: ['TEA'], expiresAt: selection.scenario === 'expired' ? '2026-11-09T19:00:00+08:00' : '2026-11-10T00:00:00+08:00',
    ruleVersion: 'v1'
  }
}

export function readDemoTools(selection: Selection): Snapshot {
  return { key: selectionKey(selection), cart: readCart(selection), rule: readCouponRule(selection) }
}

function isFresh(value: string, now: string): boolean {
  const age = Date.parse(now) - Date.parse(value)
  return Number.isFinite(age) && age >= 0 && age <= MAX_AGE_MS
}

export function decide(snapshot: Snapshot, now = DEMO_NOW): Decision {
  if (snapshot.rule.status === 'timeout') return { verdict: 'unknown', reason: '优惠券规则查询超时，尚不能确认资格。', qualifiedCents: 0 }
  const { cart, rule } = snapshot
  if (!isFresh(cart.checkedAt, now) || !isFresh(rule.checkedAt, now)) return { verdict: 'unknown', reason: '购物车或规则数据已过期，需要重新查询。', qualifiedCents: 0 }
  const qualifiedCents = cart.lines.reduce((sum, line) => sum + (rule.eligibleSkus.includes(line.sku) ? line.quantity * line.unitCents : 0), 0)
  if (!Number.isSafeInteger(qualifiedCents) || qualifiedCents < 0) return { verdict: 'unknown', reason: '金额数据无效，不能判断优惠资格。', qualifiedCents: 0 }
  if (Date.parse(now) >= Date.parse(rule.expiresAt)) return { verdict: 'ineligible', reason: '演示券已过期。', qualifiedCents }
  if (qualifiedCents === 0) return { verdict: 'ineligible', reason: '购物车没有适用此券的商品。', qualifiedCents }
  if (qualifiedCents < rule.minCents) return { verdict: 'ineligible', reason: `适用商品金额 ${formatYuan(qualifiedCents)} 元，未达到 ${formatYuan(rule.minCents)} 元门槛。`, qualifiedCents }
  return { verdict: 'eligible', reason: `适用商品金额 ${formatYuan(qualifiedCents)} 元，达到演示门槛；结算时仍需重新核验。`, qualifiedCents }
}

export function formatYuan(cents: number): string { return (cents / 100).toFixed(2) }

export function mockAgentAnswer(snapshot: Snapshot, mode: ModelMode): unknown {
  const decision = decide(snapshot)
  const refs = snapshot.rule.status === 'ok' ? [snapshot.cart.sourceId, snapshot.rule.sourceId] : []
  return { key: snapshot.key, couponId: 'SAVE20', cartRevision: snapshot.cart.revision, verdict: mode === 'overpromise' ? 'eligible' : decision.verdict,
    sourceRefs: mode === 'overpromise' ? ['rule:invented'] : refs, reason: mode === 'overpromise' ? '优惠一定到账，直接付款吧。' : decision.reason }
}

function isRecord(value: unknown): value is Record<string, unknown> { return typeof value === 'object' && value !== null && !Array.isArray(value) }
function reject(error: string, fallback: Decision): AnswerCheck { return { ok: false, error, fallback } }

export function validateAnswer(raw: unknown, snapshot: Snapshot, current: Selection): AnswerCheck {
  const fallback = decide(snapshot)
  if (snapshot.key !== selectionKey(current) || snapshot.cart.revision !== current.revision) return reject('购物车或演示条件已变化，旧结果不能使用。', fallback)
  if (!isRecord(raw)) return reject('模拟回答结构无效。', fallback)
  const keys = Object.keys(raw).sort().join(',')
  if (keys !== 'cartRevision,couponId,key,reason,sourceRefs,verdict') return reject('模拟回答字段不符合约定。', fallback)
  if (raw.key !== snapshot.key || raw.couponId !== 'SAVE20' || raw.cartRevision !== snapshot.cart.revision) return reject('模拟回答对应的券或购物车版本不匹配。', fallback)
  if (typeof raw.reason !== 'string' || raw.reason.length > 300 || raw.reason.length === 0) return reject('模拟回答理由无效。', fallback)
  const refs = snapshot.rule.status === 'ok' ? [snapshot.cart.sourceId, snapshot.rule.sourceId] : []
  if (!Array.isArray(raw.sourceRefs) || raw.sourceRefs.length !== refs.length || !raw.sourceRefs.every((ref, index) => ref === refs[index])) return reject('模拟回答引用了缺失或不属于本次查询的证据。', fallback)
  if (raw.verdict !== fallback.verdict) return reject('模拟回答与可核验的资格结果冲突。', fallback)
  return { ok: true, decision: fallback, sourceRefs: refs }
}
