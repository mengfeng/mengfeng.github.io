export type Area = 'A' | 'B'
export type Scenario = 'ready' | 'noStock' | 'outside' | 'stockTimeout' | 'routeTimeout' | 'stale'
export type ModelMode = 'bounded' | 'overpromise'
export type Verdict = 'tomorrow' | 'unavailable' | 'unknown'
export type Selection = Readonly<{ productId: 'SKU-01'; area: Area; scenario: Scenario }>
export type Inventory = Readonly<
  | { status: 'ok'; sourceId: string; quantity: number; checkedAt: string }
  | { status: 'timeout'; sourceId: string }
>
export type Delivery = Readonly<
  | { status: 'ok'; sourceId: string; covered: boolean; earliestDate: string | null; cutoffAt: string; checkedAt: string }
  | { status: 'timeout'; sourceId: string }
>
export type ToolSnapshot = Readonly<{ selection: Selection; key: string; inventory: Inventory; delivery: Delivery; toolCalls: 2 }>
export type Decision = Readonly<{ verdict: Verdict; reason: string }>
export type AnswerCheck = Readonly<
  | { ok: true; verdict: Verdict; reason: string; evidence: readonly string[] }
  | { ok: false; error: string; fallback: Decision }
>

// All dates, stock, delivery coverage and model outputs below are fictional, fixed demonstration data.
export const DEMO_NOW = '2026-11-08T10:00:00+08:00'
export const initialSelection: Selection = { productId: 'SKU-01', area: 'A', scenario: 'ready' }
export const selectionKey = (value: Selection): string => `${value.productId}|${value.area}|${value.scenario}`

function checkedAtFor(scenario: Scenario): string {
  return scenario === 'stale' ? '2026-11-08T09:45:00+08:00' : '2026-11-08T09:58:00+08:00'
}

export function readInventory(selection: Selection): Inventory {
  const sourceId = `stock:${selection.productId}`
  if (selection.scenario === 'stockTimeout') return { status: 'timeout', sourceId }
  return { status: 'ok', sourceId, quantity: selection.scenario === 'noStock' ? 0 : 4, checkedAt: checkedAtFor(selection.scenario) }
}

export function readDelivery(selection: Selection): Delivery {
  const sourceId = `route:${selection.area}`
  if (selection.scenario === 'routeTimeout') return { status: 'timeout', sourceId }
  return {
    status: 'ok', sourceId, covered: selection.scenario !== 'outside',
    earliestDate: selection.scenario === 'outside' ? null : '2026-11-09',
    cutoffAt: '2026-11-08T12:00:00+08:00', checkedAt: checkedAtFor(selection.scenario)
  }
}

export function readDemoTools(selection: Selection): ToolSnapshot {
  const inventory = readInventory(selection)
  const delivery = readDelivery(selection)
  return { selection: { ...selection }, key: selectionKey(selection), inventory, delivery, toolCalls: 2 }
}

function fresh(checkedAt: string, now: string): boolean {
  const age = Date.parse(now) - Date.parse(checkedAt)
  return Number.isFinite(age) && age >= 0 && age <= 5 * 60_000
}

export function decide(snapshot: ToolSnapshot, now = DEMO_NOW): Decision {
  const { inventory, delivery } = snapshot
  if (inventory.status === 'timeout' || delivery.status === 'timeout') return { verdict: 'unknown', reason: '至少一项只读查询超时，无法核实配送条件。' }
  if (!fresh(inventory.checkedAt, now) || !fresh(delivery.checkedAt, now)) return { verdict: 'unknown', reason: '库存或配送数据已过期，需要重新查询。' }
  if (inventory.quantity <= 0) return { verdict: 'unavailable', reason: '演示库存为 0，不能给出次日送达结论。' }
  if (!delivery.covered) return { verdict: 'unavailable', reason: '演示配送范围未覆盖所选区域。' }
  if (Date.parse(now) >= Date.parse(delivery.cutoffAt) || delivery.earliestDate !== '2026-11-09') {
    return { verdict: 'unknown', reason: '演示截单时间已过，或最早日期不是次日。' }
  }
  return { verdict: 'tomorrow', reason: '演示库存、配送范围、最早日期和截单时间均满足固定规则。' }
}

export function mockAgentAnswer(snapshot: ToolSnapshot, mode: ModelMode): unknown {
  if (mode === 'overpromise') return { key: snapshot.key, verdict: 'tomorrow', reason: '明天保证送到。', evidence: ['stock:invented', 'route:invented'] }
  const decision = decide(snapshot)
  return { key: snapshot.key, verdict: decision.verdict, reason: decision.reason, evidence: [snapshot.inventory.sourceId, snapshot.delivery.sourceId] }
}

function isRecord(input: unknown): input is Record<string, unknown> {
  return typeof input === 'object' && input !== null && !Array.isArray(input)
}

export function validateAnswer(raw: unknown, snapshot: ToolSnapshot, current: Selection, now = DEMO_NOW): AnswerCheck {
  const fallback = decide(snapshot, now)
  const reject = (error: string): AnswerCheck => ({ ok: false, error, fallback })
  if (snapshot.key !== selectionKey(current)) return reject('区域或场景已变化，旧查询结果不能用于当前回答。')
  if (!isRecord(raw) || Object.keys(raw).sort().join(',') !== 'evidence,key,reason,verdict') return reject('模拟回答结构无效或包含未知字段。')
  if (raw.key !== snapshot.key) return reject('回答所依据的查询版本不匹配。')
  if (typeof raw.reason !== 'string' || raw.reason.trim().length === 0 || raw.reason.length > 100) return reject('回答理由缺失或过长。')
  if (!Array.isArray(raw.evidence) || raw.evidence.length !== 2 || raw.evidence[0] !== snapshot.inventory.sourceId || raw.evidence[1] !== snapshot.delivery.sourceId) {
    return reject('回答引用的工具结果与本次查询不一致。')
  }
  if (raw.verdict !== 'tomorrow' && raw.verdict !== 'unavailable' && raw.verdict !== 'unknown') return reject('回答状态不在允许范围内。')
  if (raw.verdict !== fallback.verdict) return reject('回答与已核实的库存或配送结果冲突。')
  return { ok: true, verdict: raw.verdict, reason: raw.reason.trim(), evidence: [...raw.evidence] }
}
