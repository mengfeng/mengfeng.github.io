import assert from 'node:assert/strict'
import { collect, mockCandidate, verify, type Candidate, type Snapshot } from './src/core'

let checks = 0
function equal(actual: unknown, expected: unknown): void {
  assert.equal(actual, expected)
  checks += 1
}

const visible = await collect('visible', 'all', 1)
const visibleAnswer = verify(visible, mockCandidate(visible), 1)
equal(visibleAnswer.verdict, 'ready')
equal(visibleAnswer.headline, '满足本轮展示条件')
equal(visibleAnswer.sourceIds.length, 2)
equal(visibleAnswer.detail.includes('不保证搜索索引'), true)

const draft = await collect('unpublished', 'all', 1)
equal(verify(draft, mockCandidate(draft), 1).headline, '仍是草稿，尚未上架')
equal(verify(draft, mockCandidate(draft), 1).sourceIds.length, 1)

const blocked = await collect('rule_block', 'all', 1)
equal(verify(blocked, mockCandidate(blocked), 1).headline, '展示规则未放行')

const filtered = await collect('visible', 'outdoor', 1)
equal(verify(filtered, mockCandidate(filtered), 1).headline, '被当前筛选条件排除')
equal(verify(filtered, mockCandidate(filtered), 1).detail.includes('杯具'), true)

const timeout = await collect('rule_timeout', 'all', 1)
equal(verify(timeout, mockCandidate(timeout), 1).verdict, 'partial')
equal(verify(timeout, mockCandidate(timeout), 1).sourceIds.length, 1)
equal(verify(timeout, mockCandidate(timeout), 1).detail.includes('不能推断'), true)

const mismatch = await collect('version_conflict', 'all', 1)
equal(verify(mismatch, mockCandidate(mismatch), 1).verdict, 'conflict')
equal(verify(mismatch, mockCandidate(mismatch), 1).headline, '记录版本不一致')

const stale = await collect('stale', 'all', 1)
equal(verify(stale, mockCandidate(stale), 1).verdict, 'stale')
equal(verify(stale, mockCandidate(stale), 1).sourceIds.length, 0)

const missing = await collect('not_found', 'all', 1)
equal(verify(missing, mockCandidate(missing), 1).verdict, 'unknown')
equal(verify(missing, mockCandidate(missing), 1).detail.includes('不能据此断言'), true)

const fake: Candidate = { ...mockCandidate(visible), sourceIds: ['publish.write#fake'] }
equal(verify(visible, fake, 1).headline, '引用未通过核对')
equal(verify(visible, { ...mockCandidate(visible), claim: 'rule_block' }, 1).headline, '回答与证据不符')
equal(verify(visible, mockCandidate(visible), 2).verdict, 'stale')

const wrongSku: Snapshot = {
  ...visible,
  rule: visible.rule.ok ? { ok: true, value: { ...visible.rule.value, sku: 'OTHER-DEMO' } } : visible.rule
}
equal(verify(wrongSku, mockCandidate(wrongSku), 1).headline, '记录版本不一致')

console.log(`${checks} offline assertions passed`)
