type VisibleDetail = { readonly id: string; readonly phrase: string }
type PlacementScope = { readonly id: string; readonly imageRevision: string }

export type Placement = PlacementScope & (
  | { readonly role: 'informative'; readonly subject: string; readonly details: readonly VisibleDetail[] }
  | { readonly role: 'decorative' }
  | { readonly role: 'functional'; readonly actionLabel: string }
)

export type Decision =
  | { readonly kind: 'review'; readonly reason: 'shape' | 'stale' | 'purpose' | 'facts' }
  | { readonly kind: 'ready'; readonly alt: string }

export function proposeAlt(placement: Placement, candidate: unknown): Decision {
  if (typeof candidate !== 'object' || candidate === null || Array.isArray(candidate)) {
    return { kind: 'review', reason: 'shape' }
  }
  if (!('placementId' in candidate) || typeof candidate.placementId !== 'string'
    || !('imageRevision' in candidate) || typeof candidate.imageRevision !== 'string'
    || !('role' in candidate) || typeof candidate.role !== 'string'
    || !('detailIds' in candidate) || !Array.isArray(candidate.detailIds)) {
    return { kind: 'review', reason: 'shape' }
  }
  if (candidate.placementId !== placement.id || candidate.imageRevision !== placement.imageRevision) {
    return { kind: 'review', reason: 'stale' }
  }
  if (candidate.role !== placement.role) return { kind: 'review', reason: 'purpose' }

  const ids: readonly unknown[] = candidate.detailIds
  if (placement.role === 'decorative' && ids.length === 0) return { kind: 'ready', alt: '' }
  if (placement.role === 'functional' && ids.length === 0 && placement.actionLabel.trim()) {
    return { kind: 'ready', alt: placement.actionLabel }
  }
  if (placement.role !== 'informative' || ids.length === 0 || ids.length > 2 ||
    !ids.every((id): id is string => typeof id === 'string')) {
    return { kind: 'review', reason: 'facts' }
  }

  const known = new Set(placement.details.map(detail => detail.id))
  if (!ids.every(id => known.has(id)) || new Set(ids).size !== ids.length) {
    return { kind: 'review', reason: 'facts' }
  }

  const details = placement.details.filter(detail => ids.includes(detail.id)).map(detail => detail.phrase)
  return { kind: 'ready', alt: placement.subject + '，' + details.join('，') }
}
