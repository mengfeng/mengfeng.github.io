import { computed, createApp, ref } from 'vue'
import { proposeAlt } from './core'
import { scenarios } from './fixtures'

const reasons = {
  shape: '候选缺少结构化字段。',
  stale: '候选对应别的位置或图片版本，请按当前素材重新生成。',
  purpose: '候选用途与页面配置不一致，请核对这张图在页面里的作用。',
  facts: '候选引用了不在当前位置可用范围内的细节，或引用存在重复。',
}
const roles = { informative: '详情图', decorative: '装饰图', functional: '图片链接' }

createApp({
  setup() {
    const selection = ref(scenarios[0].id)
    const active = computed(() => scenarios.find(item => item.id === selection.value) ?? scenarios[0])
    const result = computed(() => proposeAlt(active.value.placement, active.value.candidate))
    return { selection, active, result, scenarios, reasons, roles }
  },
  template: `
    <main>
      <header>
        <h1>商品图片替代文本复核</h1>
        <p>切换同一张图的页面位置，检查浏览器实际获得的替代文本。</p>
        <p class="muted">虚构商品、固定模型候选。本页只做本地预览。</p>
      </header>
      <div class="toolbar">
        <label for="scenario">演示场景</label>
        <select id="scenario" v-model="selection">
          <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
        </select>
      </div>
      <div class="workspace">
        <section class="preview" aria-labelledby="preview-title">
          <h2 id="preview-title">{{ roles[active.placement.role] }}预览</h2>
          <div v-if="result.kind === 'ready'" class="sample" :key="selection">
            <a v-if="active.placement.role === 'functional'" class="image-link" href="#product-spec">
              <img src="./mug.webp" :alt="result.alt" width="480" height="480">
            </a>
            <template v-else>
              <img src="./mug.webp" :alt="result.alt" width="480" height="480">
              <p v-if="active.placement.role === 'decorative'">钴蓝色马克杯，右侧有圆形杯柄，杯内为白色。</p>
            </template>
          </div>
          <p v-else class="placeholder">待复核。当前没有生成页面预览。</p>
        </section>
        <section class="result" :data-decision="result.kind">
          <div role="status">
            <h2>{{ result.kind === 'ready' ? '已生成预览' : '需要人工复核' }}</h2>
            <p v-if="result.kind === 'review'">{{ reasons[result.reason] }}</p>
            <p v-else class="attribute"><code :data-testid="'output'">alt="{{ result.alt }}"</code></p>
            <p v-if="result.kind === 'ready' && active.placement.role === 'functional'">
              替代文本用于给这个图片链接命名，目标是下方商品规格。
            </p>
            <p v-if="result.kind === 'ready' && active.placement.role === 'decorative'">
              相邻文字已给出同样的信息，浏览器仍会收到显式空值。
            </p>
          </div>
          <details :key="selection">
            <summary>查看固定的 Agent 候选</summary>
            <pre>{{ JSON.stringify(active.candidate, null, 2) }}</pre>
          </details>
        </section>
      </div>
      <section v-if="result.kind === 'ready' && active.placement.role === 'functional'" class="spec">
        <h2 id="product-spec" tabindex="-1">马克杯规格</h2>
        <p>样品为钴蓝色，右侧有圆形杯柄，杯内为白色。</p>
      </section>
    </main>
  `
}).mount('#app')
