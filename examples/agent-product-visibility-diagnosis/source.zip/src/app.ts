import { createApp, ref } from 'vue'
import { collect, mockCandidate, verify, type Answer, type Category, type Scenario, type Snapshot } from './core'

const scenarios: { value: Scenario; label: string }[] = [
  { value: 'visible', label: '已上架且满足展示条件' },
  { value: 'unpublished', label: '商品仍是草稿' },
  { value: 'rule_block', label: '展示规则未放行' },
  { value: 'rule_timeout', label: '展示规则查询超时' },
  { value: 'version_conflict', label: '记录版本不一致' },
  { value: 'stale', label: '证据查询时间过期' },
  { value: 'not_found', label: '商品记录未找到' }
]
const categoryLabels = { all: '全部分类', mugs: '杯具', outdoor: '户外' }

createApp({
  setup() {
    const scenario = ref<Scenario>('visible')
    const category = ref<Category>('all')
    const pageVersion = ref(1)
    const forged = ref(false)
    const busy = ref(false)
    const snapshot = ref<Snapshot | null>(null)
    const answer = ref<Answer | null>(null)
    function clear(): void { snapshot.value = null; answer.value = null }
    function changeCategory(): void {
      pageVersion.value += 1
      if (answer.value) {
        answer.value = { ...answer.value, verdict: 'stale', headline: '页面筛选已改变', detail: '旧证据不能解释新的列表条件，请重新查询。', sourceIds: [] }
      }
    }
    async function query(): Promise<void> {
      busy.value = true
      clear()
      try {
        const evidence = await collect(scenario.value, category.value, pageVersion.value)
        const candidate = mockCandidate(evidence)
        snapshot.value = evidence
        answer.value = verify(evidence, forged.value
          ? { ...candidate, sourceIds: [...candidate.sourceIds, 'publish.write#fake'] }
          : candidate, pageVersion.value)
      } finally { busy.value = false }
    }
    function simulatePageChange(): void { changeCategory() }
    return { scenarios, scenario, category, categoryLabels, pageVersion, forged, busy, snapshot, answer, clear, query, changeCategory, simulatePageChange }
  },
  template: `
    <main class="shell">
      <header class="hero"><span class="eyebrow">AGENT / PRODUCT VISIBILITY</span><h1>商品上架了，为什么看不到？</h1><p>把上架记录、展示规则和当前页面筛选分开核对。全部商品与回答都是虚构的本地演示，不调用真实模型或商城服务。</p></header>
      <section class="panel controls" aria-labelledby="scene-title"><h2 id="scene-title">选择演示证据</h2><div class="control-grid"><label>商品与规则场景<select v-model="scenario" @change="clear"><option v-for="item in scenarios" :key="item.value" :value="item.value">{{ item.label }}</option></select></label><label>页面分类筛选<select v-model="category" @change="changeCategory"><option v-for="(label,key) in categoryLabels" :key="key" :value="key">{{ label }}</option></select></label><label class="check"><input type="checkbox" v-model="forged">注入伪造引用</label><div class="version">页面版本 <strong>{{ pageVersion }}</strong></div></div><div class="actions"><button @click="query" :disabled="busy">{{ busy ? '查询中…' : '查询并核对' }}</button><button class="quiet" @click="simulatePageChange">模拟页面状态变化</button></div><p class="fine">两项工具都是本地只读 Promise。切换筛选或页面版本后，旧回答立即失效；页面不会自动上架或修改展示规则。</p></section>
      <div v-if="snapshot && answer" class="grid"><section class="panel evidence"><h2>本轮只读证据</h2><dl><dt>目录记录</dt><dd v-if="snapshot.catalog.ok">{{ snapshot.catalog.value.status === 'published' ? '已上架' : '草稿' }} · v{{ snapshot.catalog.value.version }}<small>{{ snapshot.catalog.value.sourceId }}</small></dd><dd v-else>未找到演示商品</dd><dt>展示规则</dt><dd v-if="snapshot.catalog.ok && snapshot.catalog.value.status === 'draft'">草稿状态，无需据此判断展示规则</dd><dd v-else-if="snapshot.catalog.ok && snapshot.rule.ok">{{ snapshot.rule.value.enabled ? '已启用' : '未放行' }} · 关联 v{{ snapshot.rule.value.catalogVersion }}<small>{{ snapshot.rule.value.sourceId }}</small></dd><dd v-else-if="snapshot.catalog.ok">查询超时</dd><dd v-else>目录记录未核对，规则结果不展示</dd><dt>页面筛选</dt><dd>{{ categoryLabels[snapshot.filter] }} · 华东演示区域</dd></dl><p class="fine">虚构 SKU：MUG-DEMO-17 · 本例不读取真实搜索索引</p></section><section class="panel answer"><div class="panel-head"><h2>Agent 核验后回答</h2><span class="badge" :class="answer.verdict">{{ {ready:'已核对',partial:'部分已知',unknown:'无法定位',conflict:'需核对',stale:'证据失效'}[answer.verdict] }}</span></div><h3 aria-live="polite">{{ answer.headline }}</h3><p>{{ answer.detail }}</p><p class="fine">引用：<span v-if="!answer.sourceIds.length">无</span><code v-for="source in answer.sourceIds" :key="source">{{ source }}</code></p></section></div>
      <section v-if="answer" class="panel journey"><h2>三个独立关口</h2><ol><li v-for="(gate,index) in answer.gates" :key="gate"><span class="step-number">{{ index + 1 }}</span><span>{{ gate }}</span><small v-if="index === 2">筛选变化时必须重新核对</small></li></ol><p class="fine">通过这三关也不等于真实搜索索引已更新；真实店铺还需核对索引、缓存、权限和投放策略。</p></section>
      <footer>离线教学示例 · 无真实模型调用 · 无真实上架、下架、消息或付款操作</footer>
    </main>`
}).mount('#app')
