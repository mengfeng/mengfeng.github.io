import { computed, createApp, nextTick, ref } from 'vue'
import { fields, planMerge, type Choices, type Field } from './core'
import { base, scenarios } from './fixtures'

const names = { title: '标题', summary: '卖点说明', badge: '角标' }
const labels = {
  unchanged: '双方均未改', 'local-only': '保留人工修改', 'agent-only': '可合入建议',
  same: '双方改成同一内容', conflict: '需要选择',
}
const visible = (value: string) => value === '' ? '（空）' : value

createApp({
  setup() {
    const selection = ref(scenarios[0].id)
    const local = ref({ ...scenarios[0].local })
    const choices = ref<Choices>({})
    const applied = ref(false)
    const feedback = ref<HTMLElement | null>(null)
    const active = computed(() => scenarios.find(item => item.id === selection.value) ?? scenarios[0])
    const plan = computed(() => planMerge(base, local.value, active.value.candidate, choices.value))

    function loadScenario() {
      local.value = { ...active.value.local }
      choices.value = {}
      applied.value = false
    }

    function edit(field: Field) {
      delete choices.value[field]
    }

    function choose(field: Field, side: 'local' | 'agent') {
      choices.value[field] = { side, local: local.value[field] }
    }

    async function apply() {
      const result = plan.value
      if (applied.value || result.kind !== 'ready' || !result.next || result.changeCount === 0) return
      local.value = result.next
      choices.value = {}
      applied.value = true
      await nextTick()
      feedback.value?.focus()
    }

    return { selection, scenarios, local, choices, applied, feedback, plan, fields, names,
      labels, visible, loadScenario, edit, choose, apply }
  },
  template: `
    <main>
      <header>
        <h1>商品文案合并预览</h1>
        <p>比较原版、当前草稿和 Agent 建议。采用结果只更新本页样本。</p>
      </header>
      <div class="toolbar">
        <label for="scenario">演示场景</label>
        <select id="scenario" v-model="selection" @change="loadScenario">
          <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
        </select>
      </div>
      <div class="workspace">
        <section class="editor" aria-labelledby="draft-heading">
          <h2 id="draft-heading">当前草稿</h2>
          <label v-for="field in fields" :key="field" :for="'edit-'+field">
            {{ names[field] }}
            <textarea rows="2" :id="'edit-'+field" v-model="local[field]" @input="edit(field)"></textarea>
          </label>
          <p v-if="applied" role="status" tabindex="-1" ref="feedback">已更新当前草稿。</p>
        </section>
        <section aria-labelledby="review-title">
          <h2 id="review-title">合并预览</h2>
          <p v-if="applied">这份候选已处理。</p>
          <template v-else-if="plan.kind === 'ready'">
            <article v-for="row in plan.rows" :key="row.field" class="field"
              :data-field="row.field" :data-state="row.kind">
              <h3>{{ names[row.field] }} <small>{{ labels[row.kind] }}</small></h3>
              <p><span>生成时原版</span> {{ visible(row.base) }}</p>
              <p><span>当前草稿</span> {{ visible(row.local) }}</p>
              <p><span>Agent 建议</span> {{ visible(row.agent) }}</p>
              <fieldset v-if="row.kind === 'conflict'">
                <legend>{{ names[row.field] }}冲突</legend>
                <label><input type="radio" :name="row.field" :checked="choices[row.field]?.side === 'local'" @change="choose(row.field,'local')"> 保留当前草稿</label>
                <label><input type="radio" :name="row.field" :checked="choices[row.field]?.side === 'agent'" @change="choose(row.field,'agent')"> 采用 Agent 建议</label>
              </fieldset>
            </article>
            <p v-if="!plan.next" role="status" class="notice">选完所有冲突字段后，才能采用合并结果。</p>
            <p v-else-if="plan.changeCount === 0">当前草稿没有待合入的改动。</p>
            <button v-if="plan.next && plan.changeCount > 0" type="button" @click="apply">
              应用到本地草稿
            </button>
          </template>
          <p v-else class="notice" role="status" :data-error="plan.kind">
            {{ plan.kind === 'stale' ? '候选属于旧版本或其他商品，请重新生成。' : '候选字段或内容不符合编辑规则。' }}
          </p>
        </section>
      </div>
    </main>
  `
}).mount('#app')
