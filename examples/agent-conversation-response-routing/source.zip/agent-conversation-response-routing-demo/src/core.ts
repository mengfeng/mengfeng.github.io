export type Scope = Readonly<{ customer: string; conversation: string }>
export type Run = Readonly<{ scope: Scope; workspaceVersion: number; id: number }>
export type Entry =
  | { status: 'pending'; id: number }
  | { status: 'ready'; id: number; draft: string }
  | { status: 'error'; id: number; reason: 'invalid_response' | 'tool_error' }
export type Delivery = 'ready' | 'tool_error' | 'invalid_response' | 'superseded' | 'expired_workspace'
type Reply =
  | { kind: 'ok'; draft: string }
  | { kind: 'tool_error' }

export function scopeKey(scope: Scope): string {
  return JSON.stringify([scope.customer, scope.conversation])
}

function parseReply(run: Run, raw: unknown): Reply | undefined {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return
  const value = raw as Record<string, unknown>
  if (value.customer !== run.scope.customer || value.conversation !== run.scope.conversation ||
      value.runId !== run.id) return

  if (value.kind === 'tool_error') return { kind: 'tool_error' }
  if (value.kind === 'ok' && typeof value.draft === 'string' &&
      value.draft.trim().length > 0 && value.draft.length <= 500) {
    return { kind: 'ok', draft: value.draft }
  }
}

export function createRouter() {
  const entries = new Map<string, Entry>()
  let workspaceVersion = 1
  let nextRunId = 0

  function start(scope: Scope): Run {
    const run: Run = { scope: { ...scope }, workspaceVersion, id: ++nextRunId }
    entries.set(scopeKey(run.scope), { status: 'pending', id: run.id })
    return run
  }

  function finish(run: Run, raw: unknown): Delivery {
    if (run.workspaceVersion !== workspaceVersion) return 'expired_workspace'
    const key = scopeKey(run.scope)
    const entry = entries.get(key)
    if (entry?.status !== 'pending' || entry.id !== run.id) return 'superseded'

    const reply = parseReply(run, raw)
    if (reply?.kind === 'ok') {
      entries.set(key, { status: 'ready', id: run.id, draft: reply.draft })
      return 'ready'
    }

    const reason = reply?.kind === 'tool_error' ? 'tool_error' : 'invalid_response'
    entries.set(key, { status: 'error', id: run.id, reason })
    return reason
  }

  function resetWorkspace(): void {
    workspaceVersion++
    entries.clear()
  }

  return {
    start,
    finish,
    resetWorkspace,
    get: (scope: Scope) => entries.get(scopeKey(scope))
  }
}

export type Scenario = 'ok' | 'tool_error' | 'wrong_scope' | 'malformed'

export function simulateReply(run: Run, scenario: Scenario, draft: string): unknown {
  const identity = {
    customer: run.scope.customer,
    conversation: run.scope.conversation,
    runId: run.id
  }
  if (scenario === 'tool_error') return { ...identity, kind: 'tool_error' }
  if (scenario === 'wrong_scope') {
    return { ...identity, customer: 'other-demo-customer', kind: 'ok', draft }
  }
  if (scenario === 'malformed') return { ...identity, kind: 'ok', draft: [draft] }
  return { ...identity, kind: 'ok', draft }
}
