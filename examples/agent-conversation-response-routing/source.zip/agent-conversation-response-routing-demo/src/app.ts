import { computed, createApp, ref } from 'vue'
import { createRouter, simulateReply, type Delivery, type Entry, type Run, type Scenario } from './core'

const conversations = [
  { customer: 'A', conversation: '1', label: '客户 A · 配送', draft: '客户 A 的演示配送记录显示，包裹正在中转。' },
  { customer: 'A', conversation: '2', label: '客户 A · 发票', draft: '客户 A 的演示发票状态为待人工核对。' },
  { customer: 'B', conversation: '1', label: '客户 B · 退货', draft: '客户 B 的演示退货申请已收到，等待审核。' }
] as const

const deliveryLabels: Record<Delivery, string> = {
  ready: '已保存到原会话',
  tool_error: '工具返回失败',
  invalid_response: '返回结构或归属不符',
  superseded: '已被新任务替代或已完成',
  expired_workspace: '工作区已重置'
}

type Pending = { run: Run; scenario: Scenario; label: string; draft: string }
type Receipt = { id: number; label: string; result: Delivery }

createApp({
  setup() {
    const router = createRouter()
    const selected = ref(0)
    const scenario = ref<Scenario>('ok')
    const queue = ref<Pending[]>([])
    const receipts = ref<Receipt[]>([])
    const current = computed(() => conversations[selected.value])
    const entry = ref<Entry>()
    const queueLimit = 8

    function syncVisibleEntry(): void {
      entry.value = router.get(current.value)
    }

    function select(index: number): void {
      selected.value = index
      syncVisibleEntry()
    }

    function start(): void {
      if (queue.value.length >= queueLimit) return
      const { customer, conversation, label, draft } = current.value
      const run = router.start({ customer, conversation })
      queue.value.push({ run, scenario: scenario.value, label, draft })
      syncVisibleEntry()
    }

    function deliver(task: Pending): void {
      const raw = simulateReply(task.run, task.scenario, task.draft)
      const result = router.finish(task.run, raw)
      queue.value = queue.value.filter(item => item.run.id !== task.run.id)
      if (result !== 'expired_workspace') {
        receipts.value = [{ id: task.run.id, label: task.label, result }, ...receipts.value].slice(0, 8)
      } else {
        // Expired entries contain no former conversation label or draft in the receipt.
        receipts.value = [{ id: task.run.id, label: '已失效任务', result }, ...receipts.value].slice(0, 8)
      }
      syncVisibleEntry()
    }

    function reset(): void {
      router.resetWorkspace()
      // Keep demo callbacks available for delivery without retaining their old UI contents.
      queue.value = queue.value.map(task => ({ ...task, label: '已失效任务', draft: '' }))
      receipts.value = []
      syncVisibleEntry()
    }

    return { conversations, selected, current, scenario, queue, receipts, entry, queueLimit, deliveryLabels, select, start, deliver, reset }
  },
  template: `
    <main class="shell">
      <header>
        <h1>切换会话，草稿回到原处</h1>
        <p>启动本地模拟任务，再手动投递结果。用三个演示会话观察草稿归属。</p>
      </header>

      <div class="workspace">
        <div class="panel controls">
          <h2>当前会话</h2>
          <div class="conversations" role="group" aria-label="当前会话">
            <button v-for="(item, index) in conversations" :key="item.label" :aria-pressed="selected === index"
              class="secondary" @click="select(index)">{{ item.label }}</button>
          </div>
          <label for="scenario">模拟结果</label>
          <select id="scenario" v-model="scenario">
            <option value="ok">正常返回</option>
            <option value="tool_error">只读工具失败</option>
            <option value="wrong_scope">返回归属不符</option>
            <option value="malformed">返回字段错误</option>
          </select>
          <div class="actions">
            <button :disabled="queue.length >= queueLimit" @click="start">启动任务</button>
            <button class="secondary" @click="reset">重置工作区</button>
          </div>
          <p v-if="queue.length >= queueLimit" class="muted">队列已满，请先投递一个任务。</p>
        </div>

        <section class="panel result" aria-live="polite">
          <h2>{{ current.label }}的草稿</h2>
          <p v-if="!entry" class="muted">这段会话还没有草稿。</p>
          <p v-else-if="entry.status === 'pending'">等待任务 #{{ entry.id }} 返回。</p>
          <p v-else-if="entry.status === 'error'" class="error">{{ deliveryLabels[entry.reason] }}。可以重新启动当前会话的任务。</p>
          <p v-else class="draft">{{ entry.draft }}</p>
        </section>

        <section class="panel">
          <h2>待投递任务</h2>
          <p v-if="!queue.length" class="muted">启动任务后，可在这里选择返回顺序。</p>
          <ul v-else><li v-for="task in queue" :key="task.run.id">
            <span>#{{ task.run.id }} · {{ task.label }}</span>
            <button class="secondary" @click="deliver(task)">投递 #{{ task.run.id }}</button>
          </li></ul>
        </section>

        <section class="panel" aria-live="polite">
          <h2>投递记录</h2>
          <p v-if="!receipts.length" class="muted">投递后显示处理结果。</p>
          <ul v-else><li v-for="receipt in receipts" :key="receipt.id">
            <span>#{{ receipt.id }} · {{ receipt.label }}</span><strong>{{ deliveryLabels[receipt.result] }}</strong>
          </li></ul>
        </section>
      </div>
    </main>`
}).mount('#app')
