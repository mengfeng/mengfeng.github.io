import { computed, createApp, ref } from 'vue'
import { evaluate } from './core'
import { scenarios } from './fixtures'

const labels = { conflict: '资料冲突，待人工复核', missing: '缺少有效资料', invalid: '候选校验未通过', ready: '可填入本地草稿' }
const reasons = {
  conflict: '同一款商品的有效资料给出了不同高度。请核对两份原始资料。',
  missing: '当前 SKU 和规格版本下没有有效记录。请补齐可用来源。',
  invalid: '请核对候选的快照、引用、单位和值，再重新生成。',
  ready: '有效资料换算后采用同一个高度，且候选引用有效。',
}

createApp({
  setup() {
    const selection = ref(scenarios[0].id)
    const active = computed(() => scenarios.find(item => item.id === selection.value) ?? scenarios[0])
    const result = computed(() => evaluate(active.value.snapshot, active.value.suggestion))
    const included = computed(() => new Set(result.value.evidence.map(fact => fact.id)))
    const localDraft = ref<number>()

    function changeScenario() {
      localDraft.value = undefined
    }

    function copyToDraft() {
      const currentResult = result.value
      if (currentResult.kind === 'ready') localDraft.value = currentResult.proposedMm
    }

    return { scenarios, selection, active, result, included, localDraft, labels, reasons, changeScenario, copyToDraft }
  },
  template: `
    <main>
      <header class="intro">
        <h1>商品规格复核</h1>
        <p>薄荷绿折叠台灯 · {{ active.snapshot.sku }} / {{ active.snapshot.revision }}</p>
        <p class="muted">虚构商品，模拟 Agent 响应。填写操作只影响当前页面的草稿。</p>
      </header>
      <div class="toolbar">
        <label for="scenario">演示场景</label>
        <select id="scenario" v-model="selection" @change="changeScenario">
          <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
        </select>
      </div>
      <div class="workspace">
        <section class="evidence">
          <h2>组装后高度</h2>
          <ul>
            <li v-for="fact in active.snapshot.facts" :key="fact.id">
              <div><strong>{{ fact.title }}</strong><small>{{ fact.id }} · {{ fact.sku }} / {{ fact.revision }}</small></div>
              <div class="reading"><b>{{ fact.amount }} {{ fact.unit }}</b><small>{{ included.has(fact.id) ? '纳入核对' : '超出当前范围' }}</small></div>
            </li>
          </ul>
          <details>
            <summary>查看模拟 Agent 候选</summary>
            <pre>{{ JSON.stringify(active.suggestion, null, 2) }}</pre>
          </details>
        </section>
        <section class="decision" :data-result="result.kind">
          <div role="status">
            <h2>{{ labels[result.kind] }}</h2>
            <p>{{ reasons[result.kind] }}</p>
            <dl>
              <div><dt>详情页原值</dt><dd data-testid="current">{{ active.snapshot.currentMm }} mm</dd></div>
              <div v-if="result.kind === 'ready'"><dt>可采纳值</dt><dd>{{ result.proposedMm }} mm</dd></div>
              <div><dt>本地草稿</dt><dd data-testid="draft">{{ localDraft === undefined ? '空' : localDraft + ' mm' }}</dd></div>
            </dl>
          </div>
          <button v-if="result.kind === 'ready'" type="button" @click="copyToDraft">填入本地草稿</button>
        </section>
      </div>
    </main>
  `
}).mount('#app')
