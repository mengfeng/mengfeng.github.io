export type Scenario = 'visible' | 'unpublished' | 'rule_block' | 'rule_timeout' | 'version_conflict' | 'stale' | 'not_found'
export type Category = 'all' | 'mugs' | 'outdoor'
export type ToolResult<T> = { ok: true; value: T } | { ok: false; reason: 'not_found' | 'timeout' }
export type CatalogRecord = {
  sourceId: string; sku: string; version: number; status: 'published' | 'draft'
  category: 'mugs'; checkedAt: string
}
export type VisibilityRule = {
  sourceId: string; sku: string; catalogVersion: number; enabled: boolean
  allowedRegion: 'east'; checkedAt: string
}
export type Snapshot = {
  catalog: ToolResult<CatalogRecord>; rule: ToolResult<VisibilityRule>
  filter: Category; region: 'east'; pageVersion: number
}
export type Claim = 'visible' | 'unpublished' | 'rule_block' | 'filter_miss' | 'unknown'
export type Candidate = { claim: Claim; sourceIds: string[]; message: string }
export type Verdict = 'ready' | 'partial' | 'unknown' | 'conflict' | 'stale'
export type Answer = { verdict: Verdict; headline: string; detail: string; sourceIds: string[]; gates: string[] }

const NOW = '2026-11-13T20:00:00+08:00'
const MAX_AGE_MS = 5 * 60 * 1000
const SKU = 'MUG-DEMO-17'

// Both tools are fixed local read-only fixtures. No catalog service, search index or model is called.
export async function readCatalog(scenario: Scenario): Promise<CatalogRecord> {
  if (scenario === 'not_found') { throw new Error('not_found') }
  return {
    sourceId: 'catalog.read#MUG-DEMO-17-v4', sku: SKU, version: 4,
    status: scenario === 'unpublished' ? 'draft' : 'published', category: 'mugs',
    checkedAt: scenario === 'stale' ? '2026-11-13T19:40:00+08:00' : '2026-11-13T19:59:00+08:00'
  }
}

export async function readRule(scenario: Scenario): Promise<VisibilityRule> {
  if (scenario === 'rule_timeout') { throw new Error('timeout') }
  return {
    sourceId: scenario === 'version_conflict' ? 'visibility.read#MUG-DEMO-17-v3' : 'visibility.read#MUG-DEMO-17-v4', sku: SKU,
    catalogVersion: scenario === 'version_conflict' ? 3 : 4,
    enabled: scenario !== 'rule_block', allowedRegion: 'east',
    checkedAt: scenario === 'stale' ? '2026-11-13T19:40:00+08:00' : '2026-11-13T19:59:00+08:00'
  }
}

export async function collect(scenario: Scenario, filter: Category, pageVersion: number): Promise<Snapshot> {
  const [catalog, rule] = await Promise.allSettled([readCatalog(scenario), readRule(scenario)])
  return {
    catalog: catalog.status === 'fulfilled'
      ? { ok: true, value: catalog.value } : { ok: false, reason: 'not_found' },
    rule: rule.status === 'fulfilled'
      ? { ok: true, value: rule.value } : { ok: false, reason: 'timeout' },
    filter, region: 'east', pageVersion
  }
}

function isFresh(checkedAt: string): boolean {
  const elapsed = Date.parse(NOW) - Date.parse(checkedAt)
  return Number.isFinite(elapsed) && elapsed >= 0 && elapsed <= MAX_AGE_MS
}

function classify(snapshot: Snapshot, currentPageVersion: number): Claim | 'partial' | 'conflict' | 'stale' {
  if (snapshot.pageVersion !== currentPageVersion) { return 'stale' }
  if (!snapshot.catalog.ok) { return 'unknown' }
  const catalog = snapshot.catalog.value
  if (!isFresh(catalog.checkedAt)) { return 'stale' }
  if (catalog.status === 'draft') { return 'unpublished' }
  if (!snapshot.rule.ok) { return 'partial' }
  const rule = snapshot.rule.value
  if (!isFresh(rule.checkedAt)) { return 'stale' }
  if (rule.sku !== catalog.sku || rule.catalogVersion !== catalog.version) { return 'conflict' }
  if (!rule.enabled || rule.allowedRegion !== snapshot.region) { return 'rule_block' }
  if (snapshot.filter !== 'all' && snapshot.filter !== catalog.category) { return 'filter_miss' }
  return 'visible'
}

function knownSources(snapshot: Snapshot): string[] {
  if (!snapshot.catalog.ok) { return [] }
  if (snapshot.catalog.value.status === 'draft') { return [snapshot.catalog.value.sourceId] }
  return [snapshot.catalog.value.sourceId, ...(snapshot.rule.ok ? [snapshot.rule.value.sourceId] : [])]
}

export function mockCandidate(snapshot: Snapshot): Candidate {
  const state = classify(snapshot, snapshot.pageVersion)
  const claim: Claim = state === 'visible' || state === 'unpublished' || state === 'rule_block' || state === 'filter_miss'
    ? state : 'unknown'
  return { claim, sourceIds: knownSources(snapshot), message: '固定模拟回答：尚未向真实用户发送。' }
}

export function verify(snapshot: Snapshot, candidate: Candidate, currentPageVersion: number): Answer {
  const gates = ['上架状态', '展示规则', '当前筛选条件']
  const state = classify(snapshot, currentPageVersion)
  const sources = knownSources(snapshot)
  if (candidate.sourceIds.length !== sources.length || candidate.sourceIds.some((id, index) => id !== sources[index])) {
    return { verdict: 'conflict', headline: '引用未通过核对', detail: '候选回答引用了缺失或伪造的来源，已拒绝展示。', sourceIds: [], gates }
  }
  if (state === 'stale') {
    return { verdict: 'stale', headline: '证据已失效', detail: '工具查询时间过期或页面筛选版本已变化，请重新取证。', sourceIds: [], gates }
  }
  if (state === 'unknown') {
    return { verdict: 'unknown', headline: '暂不能定位商品记录', detail: '演示目录未找到商品；不能据此断言真实店铺没有该商品。', sourceIds: [], gates }
  }
  if (state === 'partial') {
    return { verdict: 'partial', headline: '已上架，展示状态未知', detail: '展示规则查询超时，不能推断商品对当前用户可见或不可见。', sourceIds: snapshot.catalog.ok ? [snapshot.catalog.value.sourceId] : [], gates }
  }
  if (state === 'conflict') {
    return { verdict: 'conflict', headline: '记录版本不一致', detail: '上架记录与展示规则版本不同；应重新查询或交由运营核对。', sourceIds: sources, gates }
  }
  if (candidate.claim !== state) {
    return { verdict: 'conflict', headline: '回答与证据不符', detail: '模拟结论和本轮核对结果不同，已拒绝展示。', sourceIds: sources, gates }
  }
  const content = {
    visible: ['满足本轮展示条件', '已上架、展示规则启用且当前筛选命中；这不保证搜索索引或真实用户端已经同步。'],
    unpublished: ['仍是草稿，尚未上架', '目录记录为草稿状态；本例不执行上架操作，也不推断其他渠道的状态。'],
    rule_block: ['展示规则未放行', '商品已上架，但演示展示规则关闭；请核对规则配置，不自动修改。'],
    filter_miss: ['被当前筛选条件排除', '商品属于杯具，当前页面选择了户外分类；放宽筛选需要用户自己操作。']
  }[state]
  return { verdict: 'ready', headline: content[0], detail: content[1], sourceIds: sources, gates }
}
