import assert from 'node:assert/strict'
import { assess, collect, mockCandidate, verify, type Scenario } from './src/core'

let count = 0
function check(actual: unknown, expected: unknown, name: string): void {
  assert.deepEqual(actual, expected, name)
  count += 1
}
async function answerFor(scenario: Scenario, couponRequested = true, pageRevision = 7) {
  const snapshot = await collect(scenario, couponRequested, pageRevision)
  return { snapshot, answer: verify(snapshot, mockCandidate(snapshot), pageRevision) }
}

const ready = await answerFor('ready')
check(ready.answer.verdict, 'ready', 'all three gates pass')
check(ready.answer.reason, 'ready', 'ready reason')
check(ready.answer.sourceIds.length, 3, 'three current citations')
check(ready.answer.detail.includes('不代表活动已经发布'), true, 'preflight not publication')
check(ready.snapshot.activity.ok, true, 'activity evidence retained')

const noCoupon = await answerFor('ready', false)
check(noCoupon.answer.reason, 'ready_without_coupon', 'skip unrequested coupon')
check(noCoupon.answer.sourceIds.length, 2, 'no coupon citation')
check(noCoupon.snapshot.coupon.ok, false, 'coupon tool not used')

const invalid = await answerFor('invalid_window')
check(invalid.answer.reason, 'invalid_window', 'invalid window blocks')
check(invalid.answer.sourceIds.length, 1, 'invalid window cites activity only')

const product = await answerFor('ineligible_product')
check(product.answer.reason, 'ineligible_product', 'product not eligible')
check(product.answer.sourceIds.length, 2, 'product block cites relevant records')

const noStack = await answerFor('no_stack')
check(noStack.answer.reason, 'no_stack', 'coupon stacking denied')
check(noStack.answer.verdict, 'blocked', 'denied not ready')

const timeout = await answerFor('coupon_timeout')
check(timeout.answer.verdict, 'partial', 'timeout yields partial result')
check(timeout.answer.sourceIds.length, 2, 'timeout does not cite absent coupon')
check(timeout.answer.detail.includes('不能批准叠加'), true, 'timeout not treated as permission')

const conflict = await answerFor('version_conflict')
check(conflict.answer.verdict, 'conflict', 'old rule version conflicts')
check(conflict.answer.reason, 'version_conflict', 'version conflict reason')

const stale = await answerFor('stale_evidence')
check(stale.answer.verdict, 'stale', 'old evidence rejected')
check(stale.answer.sourceIds.length, 0, 'old evidence not cited as current')

const missing = await answerFor('missing_activity')
check(missing.answer.verdict, 'unknown', 'missing activity unknown')
check(missing.answer.sourceIds.length, 0, 'unowned dependent evidence hidden')

const forged = verify(ready.snapshot, {
  ...mockCandidate(ready.snapshot), sourceIds: [...ready.answer.sourceIds, 'publish.write#fake']
}, 7)
check(forged.reason, 'unverified_claim', 'forged citation rejected')
check(forged.sourceIds.length, 0, 'forged answer has no accepted citations')

const falseClaim = verify(ready.snapshot, { ...mockCandidate(ready.snapshot), verdict: 'blocked' }, 7)
check(falseClaim.reason, 'unverified_claim', 'wrong verdict rejected')

const changed = verify(ready.snapshot, { verdict: 'stale', sourceIds: [], message: '' }, 8)
check(changed.reason, 'page_changed', 'old answer invalid after draft edit')
const requery = await answerFor('ready', true, 8)
check(requery.answer.reason, 'page_changed', 'new query cannot bless old revision fixture')
check(assess(ready.snapshot, 7).reason, 'ready', 'source snapshot remains unchanged')

console.log(count + ' offline assertions passed')
