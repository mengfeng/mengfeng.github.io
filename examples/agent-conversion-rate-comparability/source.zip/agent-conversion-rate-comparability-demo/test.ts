import assert from 'node:assert/strict'
import { acceptsProposal, compare, mockProposal, readEvidence } from './src/core'

const normal = readEvidence('comparable')
const compared = compare(normal)
assert.equal(compared.kind, 'comparable')
if (compared.kind !== 'comparable') throw new Error('expected a comparison')
assert.equal(compared.earlierRate, 0.08)
assert.equal(compared.laterRate, 0.072)
assert.equal(compared.deltaBp, -80)
assert.equal(acceptsProposal(normal, compared, mockProposal('comparable')), true)
assert.equal(acceptsProposal(normal, compared, mockProposal('wrong_delta')), false)
assert.equal(acceptsProposal(normal, compared, mockProposal('wrong_source')), false)
assert.equal(acceptsProposal(normal, compared, { kind: 'week_over_week', deltaBp: '-80' }), false)
assert.equal(acceptsProposal(normal, compared, null), false)

const blocked = [
  ['scope_changed', 'scope_changed'],
  ['provisional', 'provisional'],
  ['empty', 'empty'],
  ['tool_unavailable', 'tool_unavailable']
] as const
for (const [scenario, reason] of blocked) {
  const evidence = readEvidence(scenario)
  const result = compare(evidence)
  assert.deepEqual(result, { kind: 'blocked', reason })
  assert.equal(acceptsProposal(evidence, result, mockProposal(scenario)), false)
}

const zero = readEvidence('zero_paid')
assert.deepEqual(compare(zero), { kind: 'comparable', earlierRate: 0.08, laterRate: 0, deltaBp: -800 })
assert.equal(acceptsProposal(zero, compare(zero), mockProposal('zero_paid')), true)
assert.deepEqual(compare({ earlier: normal.earlier, later: { ...normal.earlier, paidSessions: 10_001 } }),
  { kind: 'blocked', reason: 'invalid_counts' })
assert.deepEqual(compare({ earlier: normal.earlier, later: { ...normal.earlier, definition: {
  ...normal.earlier.definition, timeZone: 'UTC'
} } }), { kind: 'blocked', reason: 'scope_changed' })
assert.deepEqual(compare({ earlier: normal.earlier, later: normal.earlier }),
  { kind: 'comparable', earlierRate: 0.08, laterRate: 0.08, deltaBp: 0 })
console.log('22 offline assertions passed')
