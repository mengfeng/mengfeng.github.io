import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { assess, measure, verifySuggestion } from './src/core'
import { channels, samples } from './src/fixtures'

const [card, partner] = channels
const original = samples[0].text
const candidate = samples[0].candidate

test('普通中文在同一文本下使用不同计数', () => {
  assert.deepEqual(measure('春日新色'), { graphemes: 4, utf8Bytes: 12 })
  assert.deepEqual(measure(original), { graphemes: 10, utf8Bytes: 30 })
})

test('组合重音、ZWJ emoji 和变体选择符按字素簇计数', () => {
  assert.deepEqual(measure('e\u0301'), { graphemes: 1, utf8Bytes: 3 })
  assert.deepEqual(measure('👩‍💻'), { graphemes: 1, utf8Bytes: 11 })
  assert.deepEqual(measure('☕️'), { graphemes: 1, utf8Bytes: 6 })
  assert.deepEqual(measure(samples[1].text), { graphemes: 6, utf8Bytes: 18 })
})

test('相同显示效果的 NFC 与组合序列可能有不同字节长度', () => {
  const decomposed = 'e\u0301'
  assert.equal(measure(decomposed).graphemes,measure(decomposed.normalize('NFC')).graphemes)
  assert.equal(measure(decomposed.normalize('NFC')).utf8Bytes,2)
  assert.equal(measure(decomposed).utf8Bytes,3)
})

test('切换规则后，原题可从符合规则变为超限', () => {
  assert.deepEqual(assess(original,card), { kind:'fits',used:10 })
  assert.deepEqual(assess(original,partner), { kind:'over-limit',used:30 })
})

test('长度等于上限时通过，超出一个单位时拦截', () => {
  assert.deepEqual(assess('a'.repeat(12),card), { kind:'fits',used:12 })
  assert.deepEqual(assess('a'.repeat(13),card), { kind:'over-limit',used:13 })
  assert.deepEqual(assess(samples[2].text,partner), { kind:'fits',used:24 })
  assert.deepEqual(assess(samples[2].text+'A',partner), { kind:'over-limit',used:25 })
})

test('保留原文空格与换行，拒绝完全空白的标题', () => {
  assert.deepEqual(measure(' A\n'), { graphemes:3,utf8Bytes:3 })
  assert.deepEqual(assess('  ',partner), { kind:'empty',used:2 })
  assert.equal(verifySuggestion('  ',partner,candidate).kind,'idle')
})

test('环境无当前计数器时无法确认限制', () => {
  assert.deepEqual(assess(original,card,{graphemes:undefined,utf8Bytes:30}),{kind:'unavailable'})
})

test('展示候选前按当前规则重新计数', () => {
  assert.deepEqual(verifySuggestion(original,partner,candidate),
    { kind:'ready',text:'新色今日到店',used:18 })
  assert.equal(verifySuggestion(original,card,candidate).kind,'idle')
})

test('编辑原文或更新渠道规则后旧候选失效', () => {
  assert.equal(verifySuggestion(original+'！',partner,candidate).kind,'stale')
  assert.equal(verifySuggestion(original,partner,samples[3].candidate).kind,'stale')
})

test('没有建议或改写后仍超限时，保留当前文案', () => {
  assert.equal(verifySuggestion(original,partner,samples[4].candidate).kind,'over-limit')
  assert.equal(verifySuggestion(original,partner,undefined).kind,'missing')
})

test('拒绝空改写或类型不符的响应', () => {
  for (const raw of [null, [], {}, { ...candidate,text:0 }, { ...candidate,text:'   ' }]) {
    assert.equal(verifySuggestion(original,partner,raw).kind,'invalid')
  }
})
