import { createApp, computed, ref, watch } from 'vue'
import { compare, mockCandidate, queryTools, validateCandidate } from './core'
import type { AnswerCheck, Scenario, Selection, Snapshot } from './core'

createApp({
  setup() {
    const scenario = ref<Scenario>('complete')
    const revision = ref(1)
    const badSource = ref(false)
    const snapshot = ref<Snapshot | null>(null)
    const answer = ref<AnswerCheck | null>(null)
    const busy = ref(false)
    const error = ref('')
    const current = (): Selection => ({ ids: ['P1', 'P2'], revision: revision.value })
    const result = computed(() => snapshot.value ? compare(snapshot.value, current()) : null)
    watch(scenario, () => { snapshot.value = null; answer.value = null })
    watch([revision, badSource], () => { answer.value = null })
    async function runQuery(): Promise<void> {
      busy.value = true
      error.value = ''
      answer.value = null
      try {
        snapshot.value = await queryTools(current(), scenario.value)
      } catch (cause) {
        snapshot.value = null
        error.value = cause instanceof Error ? cause.message : '查询失败，请重试。'
      } finally {
        busy.value = false
      }
    }
    function runAnswer(): void {
      if (!snapshot.value || !result.value) { return }
      const candidate = mockCandidate(snapshot.value, result.value, badSource.value)
      answer.value = validateCandidate(candidate, snapshot.value, current(), result.value)
    }
    function reset(): void {
      scenario.value = 'complete'; revision.value = 1; badSource.value = false
      snapshot.value = null; answer.value = null; error.value = ''
    }
    return { scenario, revision, badSource, snapshot, answer, busy, error, result, runQuery, runAnswer, reset }
  },
  template: `
    <main class="shell">
      <header class="hero"><p class="eyebrow">AGENT / COMPARE LAB 10</p><h1>买哪款更合适？</h1><p>先查商品资料、库存和优惠，再核对 Agent 的比较。所有商品与价格均为演示数据。</p></header>
      <section class="panel" aria-label="演示条件"><div class="panel-head"><h2>演示条件</h2><button class="quiet" type="button" @click="reset">重置</button></div>
        <div class="controls"><label>工具场景<select v-model="scenario"><option value="complete">三个工具均成功</option><option value="stock_timeout">库存查询超时</option><option value="offer_timeout">优惠查询超时</option><option value="stale">工具结果过期</option></select></label>
          <label>商品选择版本<select v-model.number="revision"><option :value="1">版本 1</option><option :value="2">版本 2</option></select></label>
          <label class="checkbox"><input type="checkbox" v-model="badSource">模拟回答伪造来源</label></div>
        <p class="hint">演示时间固定为 2026-11-10 20:00（北京时间）。版本改变后，旧工具记录不可用于当前回答。</p>
        <div class="actions"><button type="button" :disabled="busy" @click="runQuery">① 查询三个只读工具</button><button type="button" :disabled="!snapshot || busy" @click="runAnswer">② 验证模拟回答</button></div><p v-if="error" role="alert">{{ error }}</p>
      </section>
      <section class="grid"><div class="panel" aria-label="工具调用记录"><h2>工具调用记录</h2><p v-if="!snapshot" class="muted">尚未查询。</p><ul v-else class="tool-list"><li v-for="item in snapshot.outcomes" :key="item.tool"><strong>{{ item.tool }}</strong><span :class="item.status">{{ item.status === 'ok' ? '已返回' : '失败' }}</span><small>{{ item.status === 'ok' ? item.record.sourceId : item.message }}</small></li></ul></div>
        <div class="panel" aria-label="比较结果"><h2>比较结果</h2><p v-if="!result" class="muted">查询后展示。</p><template v-else><p class="status" :class="result.status">{{ result.status === 'ready' ? '证据齐全' : result.status === 'stale' ? '证据已过期' : '部分证据可用' }}</p><div class="table-wrap"><table v-if="result.rows.length"><caption>固定演示商品比较</caption><thead><tr><th scope="col">商品</th><th scope="col">续航</th><th scope="col">重量</th><th scope="col">库存</th><th scope="col">优惠后价</th></tr></thead><tbody><tr v-for="row in result.rows" :key="row.id"><th scope="row">{{ row.name }}</th><td>{{ row.batteryHours }} 小时</td><td>{{ row.weightGrams }} g</td><td>{{ row.available === null ? '未知' : row.available ? '有货' : '无货' }}</td><td>{{ row.finalCents === null ? '未知' : '¥' + (row.finalCents / 100).toFixed(2) }}</td></tr></tbody></table></div><ul v-if="result.notes.length" class="notes"><li v-for="note in result.notes" :key="note">{{ note }}</li></ul></template></div></section>
      <section class="panel answer" aria-label="回答核验"><h2>回答核验</h2><p v-if="!answer" class="muted">模型只提供候选说明；页面按工具证据核对后才展示。</p><p v-else :class="answer.accepted ? 'accepted' : 'rejected'" role="status">{{ answer.message }}</p><p class="fine">本页只运行本地固定函数，没有真实模型、真实库存、真实优惠或下单请求；商品比较不构成购买承诺。</p></section>
    </main>`
}).mount('#app')
