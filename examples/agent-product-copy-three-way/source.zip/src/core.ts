export const fields = ['title', 'summary', 'badge'] as const
export type Field = typeof fields[number]
export type Copy = Record<Field, string>
export type Base = { readonly productId: string; readonly revision: string; readonly copy: Readonly<Copy> }
type Side = 'local' | 'agent'
export type Choices = Partial<Record<Field, { readonly local: string; readonly side: Side }>>

type Row = {
  readonly field: Field
  readonly base: string
  readonly local: string
  readonly agent: string
  readonly kind: 'unchanged' | 'local-only' | 'agent-only' | 'same' | 'conflict'
  readonly next: string | undefined
}

export type Plan =
  | { readonly kind: 'invalid' | 'stale' }
  | { readonly kind: 'ready'; readonly rows: readonly Row[]; readonly changeCount: number; readonly next: Copy | undefined }

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

export function planMerge(base: Base, local: Readonly<Copy>, raw: unknown, choices: Choices = {}): Plan {
  if (!isObject(raw) || typeof raw.productId !== 'string' || typeof raw.baseRevision !== 'string'
    || !isObject(raw.patch)) return { kind: 'invalid' }
  if (raw.productId !== base.productId || raw.baseRevision !== base.revision) return { kind: 'stale' }

  const patch = new Map<Field, string>()
  for (const [key, value] of Object.entries(raw.patch)) {
    const field = fields.find(allowed => allowed === key)
    if (!field || typeof value !== 'string' || (field !== 'badge' && !value.trim())) {
      return { kind: 'invalid' }
    }
    patch.set(field, value)
  }

  const rows = fields.map((field): Row => {
    const original = base.copy[field]
    const current = local[field]
    const suggested = patch.get(field) ?? original
    const values = { field, base: original, local: current, agent: suggested }

    if (suggested === original) {
      return { ...values, kind: current === original ? 'unchanged' : 'local-only', next: current }
    }
    if (current === suggested) return { ...values, kind: 'same', next: current }
    if (current === original) return { ...values, kind: 'agent-only', next: suggested }

    const choice = choices[field]
    if (!choice || choice.local !== current) return { ...values, kind: 'conflict', next: undefined }
    return { ...values, kind: 'conflict', next: choice.side === 'agent' ? suggested : current }
  })

  const next = { ...local }
  let changeCount = 0
  for (const row of rows) {
    if (row.next === undefined) return { kind: 'ready', rows, changeCount: 0, next: undefined }
    if (row.next !== row.local) changeCount++
    next[row.field] = row.next
  }
  return { kind: 'ready', rows, next, changeCount }
}
