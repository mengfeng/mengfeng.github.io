import assert from 'node:assert/strict'
import { checkProposal, mockProposal, readSample, type Scenario } from './src/core'

function run(scenario: Scenario) {
  return checkProposal(readSample(scenario), mockProposal(scenario))
}
const normal = run('normal')
assert.equal(normal.kind, 'checked')
if (normal.kind !== 'checked') throw new Error('expected checked result')
assert.deepEqual(normal.themes.map(t => t.citations.length), [2, 2])
assert.deepEqual(normal.themes.map(t => t.citations.map(c => c.review.id)), [['R-01', 'R-02'], ['R-02', 'R-03']])
assert.equal(normal.excluded, 0)
assert.equal(normal.duplicates, 0)

for (const [scenario, excluded, duplicates, packingCount] of [
  ['duplicate', 0, 1, 2], ['unknown_review', 1, 0, 2], ['wrong_quote', 1, 0, 1]
] as const) {
  const result = run(scenario)
  if (result.kind !== 'checked') throw new Error('expected partial check')
  assert.equal(result.excluded, excluded)
  assert.equal(result.duplicates, duplicates)
  assert.equal(result.themes[0].citations.length, packingCount)
  assert.equal(result.themes[1].citations.length, 2)
}
assert.deepEqual(run('old_sample'), { kind: 'blocked', reason: 'old_sample' })
assert.deepEqual(run('empty'), { kind: 'blocked', reason: 'empty' })
assert.deepEqual(run('malformed'), { kind: 'blocked', reason: 'invalid_proposal' })
const sample = readSample('normal')
assert.deepEqual(checkProposal(sample, { sampleId: sample.id, groups: [
  { topic: 'packing', citations: [{ reviewId: 'R-01', quote: '   ' }] }
] }), { kind: 'checked', themes: [], excluded: 1, duplicates: 0 })
assert.deepEqual(checkProposal(sample, { sampleId: sample.id, groups: [
  { topic: 'invented', citations: [] }
] }), { kind: 'blocked', reason: 'invalid_proposal' })
console.log('22 offline assertions passed')
