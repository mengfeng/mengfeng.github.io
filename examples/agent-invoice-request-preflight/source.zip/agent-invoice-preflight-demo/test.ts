import assert from 'node:assert/strict'
import {
  availableCents, collect, formatCny, mockCandidate, parseCandidate, verify,
  type Scenario
} from './src/core'

let checks = 0
function check(value: unknown, message: string): void {
  assert.ok(value, message)
  checks++
}

async function run(scenario: Scenario, revision = 3) {
  const evidence = await collect(scenario, revision)
  const candidate = mockCandidate(scenario, revision)
  return { evidence, candidate, result: verify(evidence, revision, candidate) }
}

const ready = await run('ready')
check(ready.result.state === 'ready', 'complete evidence permits review draft')
check(ready.result.draft?.amountCents === 16700, 'available amount is 167 yuan')
check(ready.result.draft?.title === '演示科技有限公司', 'title comes from profile evidence')
check(ready.result.draft?.taxId === 'DEMO-TAX-ID', 'demo tax ID is preserved')
check(ready.result.draft?.sourceIds.length === 3, 'three independent source IDs')
check(ready.evidence.order.kind === 'ok', 'order source was read')
check(ready.evidence.profile.kind === 'ok', 'profile source was read')
check(ready.evidence.policy.kind === 'ok', 'policy source was read')
check(formatCny(16700) === '¥167.00', 'integer cents formatting')
check(formatCny(-1) === '—', 'invalid amount is not formatted')
if (ready.evidence.order.kind === 'ok') {
  check(availableCents(ready.evidence.order.value) === 16700, 'subtract shipping, refund, previous invoice')
  check(availableCents({ ...ready.evidence.order.value, paidCents: Number.MAX_SAFE_INTEGER + 1 }) === -1, 'unsafe integer rejected')
  check(availableCents({ ...ready.evidence.order.value, issuedCents: -1 }) === -1, 'negative deduction rejected')
}
check(parseCandidate(ready.candidate) !== null, 'valid fixed candidate parsed')
check(parseCandidate({}) === null, 'missing fields rejected')

for (const scenario of ['amount_over', 'wrong_title', 'wrong_source', 'new_refund', 'malformed_candidate'] as const) {
  const item = await run(scenario)
  check(item.result.state === 'rejected', `${scenario} rejected`)
  check(item.result.draft === null, `${scenario} leaves no draft`)
}
const newRefund = await run('new_refund')
check(newRefund.result.availableCents === 6700, 'new refund reduces remaining amount')

const stale = await run('stale_order')
check(stale.result.state === 'stale', 'stale order snapshot blocked')
check(stale.result.draft === null, 'stale snapshot leaves no draft')

for (const scenario of ['order_timeout', 'profile_timeout', 'policy_timeout'] as const) {
  const item = await run(scenario)
  check(item.result.state === 'blocked', `${scenario} blocked`)
  check(item.result.draft === null, `${scenario} leaves no draft`)
}

if (ready.evidence.order.kind === 'ok') {
  const base = ready.candidate as Record<string, unknown>
  check(verify(ready.evidence, 3, { ...base, amountCents: 167.5 }).state === 'rejected', 'fractional cents rejected')
  check(verify(ready.evidence, 3, { ...base, amountCents: 0 }).state === 'rejected', 'zero amount rejected')
  check(verify(ready.evidence, 3, { ...base, amountCents: Number.MAX_SAFE_INTEGER + 1 }).state === 'rejected', 'unsafe amount rejected')
  check(verify(ready.evidence, 3, { ...base, orderId: 'ORD-DEMO-99' }).state === 'rejected', 'other order rejected')
  check(verify(ready.evidence, 3, { ...base, currency: 'USD' }).state === 'rejected', 'other currency rejected')
  check(verify(ready.evidence, 3, { ...base, orderRevision: 2 }).state === 'stale', 'old candidate revision rejected')
  check(verify(ready.evidence, 4, base).state === 'stale', 'updated order revision invalidates evidence')
}
console.log(`${checks} offline assertions passed`)
