export type Scenario = 'comparable' | 'scope_changed' | 'provisional' | 'empty' | 'zero_paid' |
  'tool_unavailable' | 'wrong_delta' | 'wrong_source'

type Definition = Readonly<{
  denominator: 'checkout_sessions' | 'all_sessions'
  revision: string
  timeZone: string
  channel: string
  coverageDays: number
}>

export type Snapshot = Readonly<{
  id: string
  period: string
  state: 'final' | 'provisional'
  definition: Definition
  sessions: number
  paidSessions: number
}>

export type Comparison =
  | { kind: 'comparable'; earlierRate: number; laterRate: number; deltaBp: number }
  | { kind: 'blocked'; reason: 'tool_unavailable' | 'provisional' | 'scope_changed' | 'empty' | 'invalid_counts' }

export type Evidence = Readonly<{ earlier: Snapshot; later?: Snapshot }>

const definition: Definition = {
  denominator: 'checkout_sessions', revision: 'v3', timeZone: 'Asia/Shanghai',
  channel: '全站', coverageDays: 7
}

export function readEvidence(scenario: Scenario): Evidence {
  const earlier: Snapshot = {
    id: 'checkout-demo/2026-W45/v3/s1', period: '11月2日—11月8日',
    state: 'final', definition, sessions: 10_000, paidSessions: 800
  }
  if (scenario === 'tool_unavailable') return { earlier }
  const scopeChanged = scenario === 'scope_changed'
  const later: Snapshot = {
    id: scopeChanged ? 'checkout-demo/2026-W46/v4/s2' : 'checkout-demo/2026-W46/v3/s2',
    period: '11月9日—11月15日',
    state: scenario === 'provisional' ? 'provisional' : 'final',
    definition: scopeChanged ? { ...definition, denominator: 'all_sessions', revision: 'v4' } : definition,
    sessions: scenario === 'empty' ? 0 : scopeChanged ? 18_000 : 12_000,
    paidSessions: scenario === 'empty' || scenario === 'zero_paid' ? 0 : 864
  }
  return { earlier, later }
}

function validCounts(snapshot: Snapshot): boolean {
  const { sessions, paidSessions } = snapshot
  return Number.isSafeInteger(sessions) && Number.isSafeInteger(paidSessions) &&
    sessions >= 0 && paidSessions >= 0 && paidSessions <= sessions
}

function sameDefinition(a: Definition, b: Definition): boolean {
  return a.denominator === b.denominator && a.revision === b.revision &&
    a.timeZone === b.timeZone && a.channel === b.channel && a.coverageDays === b.coverageDays
}

export function compare({ earlier, later }: Evidence): Comparison {
  if (!later) return { kind: 'blocked', reason: 'tool_unavailable' }
  if (!validCounts(earlier) || !validCounts(later)) return { kind: 'blocked', reason: 'invalid_counts' }
  if (earlier.state !== 'final' || later.state !== 'final') return { kind: 'blocked', reason: 'provisional' }
  if (!sameDefinition(earlier.definition, later.definition)) return { kind: 'blocked', reason: 'scope_changed' }
  if (earlier.sessions === 0 || later.sessions === 0) return { kind: 'blocked', reason: 'empty' }

  const earlierRate = earlier.paidSessions / earlier.sessions
  const laterRate = later.paidSessions / later.sessions
  const difference = laterRate - earlierRate
  const deltaBp = Math.round(Math.abs(difference) * 10_000) * Math.sign(difference) || 0
  return { kind: 'comparable', earlierRate, laterRate, deltaBp }
}

export function mockProposal(scenario: Scenario): unknown {
  return {
    kind: 'week_over_week',
    earlierId: 'checkout-demo/2026-W45/v3/s1',
    laterId: scenario === 'wrong_source' ? 'checkout-demo/2026-W46/v3/s0' : 'checkout-demo/2026-W46/v3/s2',
    deltaBp: scenario === 'wrong_delta' ? -800 : scenario === 'zero_paid' ? -800 : -80
  }
}

export function acceptsProposal(evidence: Evidence, comparison: Comparison, raw: unknown): boolean {
  if (comparison.kind !== 'comparable' || !evidence.later ||
      typeof raw !== 'object' || raw === null || Array.isArray(raw)) return false
  const value = raw as Record<string, unknown>
  return value.kind === 'week_over_week' && value.earlierId === evidence.earlier.id &&
    value.laterId === evidence.later.id && value.deltaBp === comparison.deltaBp
}
