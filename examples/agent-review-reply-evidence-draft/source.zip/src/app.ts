import { createApp, ref } from 'vue'
import { collect, mockCandidate, verify, type Assessment, type Evidence, type Scenario } from './core'

createApp({
  setup() {
    const scenario = ref<Scenario>('ready')
    const revision = ref(1)
    const evidence = ref<Evidence | null>(null)
    const assessment = ref<Assessment | null>(null)
    const pending = ref(false)
    const reviewed = ref(false)
    let requestId = 0

    function invalidate() {
      requestId += 1
      evidence.value = null
      assessment.value = null
      reviewed.value = false
    }
    function updateReview() {
      revision.value += 1
      invalidate()
    }
    async function run() {
      const thisRequest = ++requestId
      pending.value = true
      reviewed.value = false
      try {
        const snapshot = await collect(scenario.value, revision.value)
        if (thisRequest !== requestId) return
        evidence.value = snapshot
        const effectiveRevision = scenario.value === 'stale_review' ? revision.value + 1 : revision.value
        assessment.value = verify(snapshot, mockCandidate(snapshot, revision.value, scenario.value === 'forged_claim'), effectiveRevision)
      } finally {
        if (thisRequest === requestId) pending.value = false
      }
    }
    return { scenario, revision, evidence, assessment, pending, reviewed, invalidate, updateReview, run }
  },
  template: `
  <main class="shell">
    <header class="hero"><div class="eyebrow">FRONTEND AGENT LAB · 07</div><h1>差评回复，先核实再落笔</h1><p>读取虚构评价、订单和售后规则，生成带引用的待审阅草稿。这里没有真实客户资料、模型调用或发送接口。</p></header>
    <section class="panel"><h2>选择演示情况</h2><label>证据场景<select v-model="scenario" @change="invalidate"><option value="ready">三份证据齐全</option><option value="missing_order">订单未找到</option><option value="policy_timeout">政策读取超时</option><option value="order_mismatch">订单与评价不匹配</option><option value="stale_review">评价版本变化</option><option value="forged_claim">候选擅自承诺退款</option></select></label><div class="actions"><button @click="run" :disabled="pending">{{ pending ? '读取中…' : '读取证据并生成草稿' }}</button><button class="quiet" @click="updateReview">模拟评价更新（当前 r{{ revision }}）</button></div></section>
    <div class="grid"><section class="panel"><h2>本轮只读证据</h2><p class="fine" v-if="!evidence">点击按钮后显示来源和读取状态。</p><template v-else><div class="evidence" v-for="key in ['review','order','policy']" :key="key"><b>{{ key === 'review' ? '评价' : key === 'order' ? '订单' : '售后规则' }}</b><template v-if="evidence[key].kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence[key].value.sourceId }}</code><p v-if="key === 'review'">{{ evidence.review.value.text }}</p><p v-if="key === 'order'">编号 {{ evidence.order.value.id }} · {{ evidence.order.value.status }}</p><p v-if="key === 'policy'">允许引导用户发起售后申请；不代表退款获批。</p></template><span v-else class="error">{{ evidence[key].message }}</span></div></template></section>
    <section class="panel"><div class="panel-head"><h2>回复草稿</h2><span v-if="assessment" class="badge" :class="assessment.state">{{ assessment.state }}</span></div><p class="fine" v-if="!assessment">尚未生成。所有文字只在浏览器本地展示。</p><template v-else><p class="notice">{{ assessment.message }}</p><div v-if="assessment.draft" class="draft"><p>{{ assessment.draft }}</p><div class="sources"><span v-for="id in assessment.sourceIds" :key="id">{{ id }}</span></div><label class="review"><input type="checkbox" v-model="reviewed">人工已审阅（仅本地状态）</label></div><p v-else class="fine">当前没有可展示的回复草稿。</p></template><p class="fine">✉︎ 仅预览 · 不会对外发送，也不会创建退款。</p></section></div>
    <footer>固定虚构夹具 · Vue 3 + TypeScript · 模拟候选经确定性校验</footer>
  </main>`
}).mount('#app')
