import { computed, createApp, ref } from 'vue'
import { agreesWithClock, calculateClock } from './core'
import { scenarios } from './fixtures'

const formatter = new Intl.DateTimeFormat('zh-CN', {
  timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
})
const format = (instant: number) => formatter.format(instant)
const labels = { remaining: '时限内', 'at-limit': '已达时限', 'over-limit': '已超时' }

createApp({
  setup() {
    const selection = ref(scenarios[0].id)
    const active = computed(() => scenarios.find(item => item.id === selection.value) ?? scenarios[0])
    const result = computed(() => calculateClock(active.value.snapshot))
    const agreed = computed(() => agreesWithClock(active.value.snapshot, result.value, active.value.candidate))
    return { scenarios, selection, active, result, agreed, labels, format }
  },
  template: `
    <main>
      <header>
        <h1>工单响应计时</h1>
        <p>首响时限 {{ active.snapshot.budgetMinutes }} 个服务分钟 · 北京时间</p>
        <p class="muted">虚构工单与固定模型候选。切换场景可查看计时区间。</p>
      </header>
      <div class="toolbar">
        <label for="scenario">演示场景</label>
        <select id="scenario" v-model="selection">
          <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
        </select>
      </div>
      <div class="workspace">
        <section aria-label="工单计时结果" class="result" :data-result="result.kind">
          <div role="status" v-if="result.kind === 'measured'">
            <h2 :data-meter-state="result.state">{{ labels[result.state] }}</h2>
            <p class="number"><span data-testid="elapsed">{{ result.elapsedMinutes }}</span> <small>服务分钟</small></p>
            <progress aria-label="已使用的计时额度" :max="active.snapshot.budgetMinutes"
              :value="Math.min(result.elapsedMinutes, active.snapshot.budgetMinutes)"></progress>
            <p data-testid="candidate" class="candidate" :class="{ rejected: !agreed }">
              {{ agreed ? '模拟候选与计时结果一致' : '模拟候选未通过核验，仍显示已复算的计时结果' }}
            </p>
          </div>
          <div role="status" v-else>
            <h2>{{ result.kind === 'uncovered' ? '排班范围不足' : '计时数据有误' }}</h2>
            <p>请补齐可核对的排班，再判断这张工单是否超时。</p>
          </div>
          <dl>
            <div><dt>工单建立</dt><dd>{{ format(active.snapshot.openedAt) }}</dd></div>
            <div><dt>统计时点</dt><dd>{{ format(active.snapshot.asOf) }}</dd></div>
          </dl>
        </section>
        <section class="evidence">
          <h2>本次计入的时段</h2>
          <template v-if="result.kind === 'measured'">
            <ol v-if="result.segments.length">
              <li v-for="segment in result.segments" :key="segment.start" class="segment">
                <span>{{ format(segment.start) }} – {{ format(segment.end) }}</span>
                <b>{{ (segment.end - segment.start) / 60000 }} 分钟</b>
              </li>
            </ol>
            <p v-else>本次等待区间内没有服务时段。</p>
          </template>
          <p v-else>当前无法确认计时区间。</p>
          <details :key="selection">
            <summary>查看原始排班与模拟候选</summary>
            <p>{{ active.snapshot.calendarId }} · {{ format(active.snapshot.coverage.start) }} 至 {{ format(active.snapshot.coverage.end) }}</p>
            <ul class="raw" aria-label="原始排班">
              <li v-for="(shift, index) in active.snapshot.shifts" :key="index">
                {{ format(shift.start) }} – {{ format(shift.end) }}
              </li>
            </ul>
            <pre>{{ JSON.stringify(active.candidate, null, 2) }}</pre>
          </details>
        </section>
      </div>
    </main>
  `
}).mount('#app')
