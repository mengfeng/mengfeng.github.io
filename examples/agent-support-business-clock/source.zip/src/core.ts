export type Interval = { readonly start: number; readonly end: number }

export type Snapshot = {
  readonly id: string
  readonly ticketId: string
  readonly calendarId: string
  readonly openedAt: number
  readonly asOf: number
  readonly budgetMinutes: number
  readonly coverage: Interval
  readonly shifts: readonly Interval[]
}

export type Clock =
  | { kind: 'invalid' | 'uncovered' }
  | { kind: 'measured'; elapsedMinutes: number; segments: readonly Interval[];
      state: 'remaining' | 'at-limit' | 'over-limit' }

const minute = 60_000
const isMinute = (time: number): boolean =>
  Number.isSafeInteger(time) && time >= 0 && time <= 8.64e15 && time % minute === 0
const isInterval = ({ start, end }: Interval): boolean =>
  isMinute(start) && isMinute(end) && start < end

export function calculateClock(snapshot: Snapshot): Clock {
  const { openedAt, asOf, budgetMinutes, coverage, shifts } = snapshot
  if (!isMinute(openedAt) || !isMinute(asOf) || asOf < openedAt ||
      !Number.isSafeInteger(budgetMinutes) || budgetMinutes <= 0 ||
      !isInterval(coverage) || shifts.some(shift => !isInterval(shift))) {
    return { kind: 'invalid' }
  }
  if (coverage.start > openedAt || coverage.end < asOf) return { kind: 'uncovered' }

  const clipped = shifts
    .map(shift => ({ start: Math.max(shift.start, openedAt), end: Math.min(shift.end, asOf) }))
    .filter(segment => segment.start < segment.end)
    .sort((left, right) => left.start - right.start)
  const segments: { start: number; end: number }[] = []
  for (const current of clipped) {
    const last = segments.at(-1)
    if (last && current.start <= last.end) {
      last.end = Math.max(last.end, current.end)
    } else {
      segments.push(current)
    }
  }

  const elapsedMinutes = segments.reduce((sum, segment) => sum + (segment.end - segment.start) / minute, 0)
  if (elapsedMinutes < budgetMinutes) return { kind: 'measured', elapsedMinutes, segments, state: 'remaining' }
  if (elapsedMinutes === budgetMinutes) return { kind: 'measured', elapsedMinutes, segments, state: 'at-limit' }
  return { kind: 'measured', elapsedMinutes, segments, state: 'over-limit' }
}

export function agreesWithClock(snapshot: Snapshot, clock: Clock, candidate: unknown): boolean {
  if (clock.kind !== 'measured' || typeof candidate !== 'object' || candidate === null) return false
  return 'snapshotId' in candidate && candidate.snapshotId === snapshot.id
    && 'ticketId' in candidate && candidate.ticketId === snapshot.ticketId
    && 'elapsedMinutes' in candidate && candidate.elapsedMinutes === clock.elapsedMinutes
    && 'state' in candidate && candidate.state === clock.state
}
