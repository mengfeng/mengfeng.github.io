import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { agreesWithClock, calculateClock } from './src/core'
import { scenarios } from './src/fixtures'

const expectations = [
  ['overnight', 40, 'remaining', true, 2],
  ['lunch', 25, 'remaining', true, 2],
  ['overlap', 40, 'remaining', true, 2],
  ['exact', 60, 'at-limit', true, 2],
  ['late', 75, 'over-limit', true, 2],
  ['gap', 0, 'uncovered', false, 0],
  ['stale', 40, 'remaining', false, 2],
  ['wrong', 40, 'remaining', false, 2],
  ['closed', 0, 'remaining', true, 0],
] as const

for (const [id, minutes, state, agrees, segmentCount] of expectations) {
  test(id, () => {
    const scenario = scenarios.find(item => item.id === id)
    assert.ok(scenario)
    const clock = calculateClock(scenario.snapshot)
    assert.equal(agreesWithClock(scenario.snapshot, clock, scenario.candidate), agrees)
    if (state === 'uncovered') {
      assert.deepEqual(clock, { kind: 'uncovered' })
    } else {
      assert.equal(clock.kind, 'measured')
      assert.equal(clock.state, state)
      assert.equal(clock.elapsedMinutes, minutes)
      assert.equal(clock.segments.length, segmentCount)
    }
  })
}

const { snapshot, candidate } = scenarios[0]

test('拼接相邻班次时没有重复计入边界，也不修改原始班次', () => {
  const start = snapshot.openedAt
  const end = start + 20 * 60_000
  const junction = start + 10 * 60_000
  const shifts = [{ start: junction, end }, { start, end: junction }]
  const original = structuredClone(shifts)
  const clock = calculateClock({ ...snapshot, asOf: end, shifts })
  assert.deepEqual(clock, { kind: 'measured', elapsedMinutes: 20, segments: [{ start, end }], state: 'remaining' })
  assert.deepEqual(shifts, original)
})

test('开始时间恰好位于下班边界时，前一班次不会计入', () => {
  const openedAt = snapshot.shifts[0].end
  const clock = calculateClock({ ...snapshot, openedAt, asOf: openedAt + 60_000 })
  assert.deepEqual(clock, { kind: 'measured', elapsedMinutes: 0, segments: [], state: 'remaining' })
})

test('排班 coverage 右端等于统计时点仍完整，左端晚于建单则不完整', () => {
  const covered = { start: snapshot.openedAt, end: snapshot.asOf }
  assert.equal(calculateClock({ ...snapshot, coverage: covered }).kind, 'measured')
  const uncovered = { ...covered, start: covered.start + 60_000 }
  assert.deepEqual(calculateClock({ ...snapshot, coverage: uncovered }), { kind: 'uncovered' })
})

test('错误时间线、空区间、非法额度与非整分样本返回 invalid', () => {
  const changes = [{ asOf: snapshot.openedAt - 60_000 }, { budgetMinutes: 0 },
    { asOf: snapshot.asOf + 1 }, { shifts: [{ start: snapshot.asOf, end: snapshot.asOf }] }]
  for (const change of changes) {
    assert.deepEqual(calculateClock({ ...snapshot, ...change }), { kind: 'invalid' })
  }
})

test('同值跨工单、状态矛盾和结构错误的模型候选均不采信', () => {
  const clock = calculateClock(snapshot)
  assert.ok(agreesWithClock(snapshot, clock, candidate))
  const base = { snapshotId: snapshot.id, ticketId: snapshot.ticketId, elapsedMinutes: 40, state: 'remaining' }
  for (const raw of [null, [], { ...base, ticketId: 'CASE-74' }, { ...base, state: 'over-limit' },
    { ...base, elapsedMinutes: '40' }]) {
    assert.equal(agreesWithClock(snapshot, clock, raw), false)
  }
})
