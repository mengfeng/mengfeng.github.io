import { createApp, ref } from 'vue'
import { collect, demoSource, mockCandidate, protect, verify, type Assessment, type Evidence, type Scenario } from './core'

createApp({
  setup() {
    const scenario = ref<Scenario>('ready')
    const revision = ref(1)
    const source = ref(demoSource())
    const evidence = ref<Evidence | null>(null)
    const assessment = ref<Assessment | null>(null)
    const pending = ref(false)
    const reviewed = ref(false)
    let requestId = 0
    function invalidate() { requestId++; evidence.value = null; assessment.value = null; reviewed.value = false }
    function updateSource() { revision.value++; source.value = demoSource(revision.value); invalidate() }
    async function run() {
      const id = ++requestId
      pending.value = true
      reviewed.value = false
      try {
        const current = source.value
        const results = await collect(scenario.value)
        if (id !== requestId) return
        evidence.value = results
        const effectiveRevision = scenario.value === 'stale_source' ? revision.value + 1 : revision.value
        assessment.value = verify(current, effectiveRevision, results, mockCandidate(protect(current).masked, current.revision, results, scenario.value))
      } finally { if (id === requestId) pending.value = false }
    }
    return { scenario, revision, source, masked: () => protect(source.value).masked, evidence, assessment, pending, reviewed, invalidate, updateSource, run }
  },
  template: `
  <main class="shell"><header class="hero"><div class="eyebrow">FRONTEND AGENT LAB · 08</div><h1>跨境客服翻译，先锁住关键事实</h1><p>一个只生成待审阅英文回复的本地演示：保护订单号和金额，读取术语与政策，再核对固定模拟候选。不会发送消息或申请退款。</p></header>
  <section class="panel"><h2>选择演示情况</h2><label>翻译场景<select v-model="scenario" @change="invalidate"><option value="ready">术语与政策齐全</option><option value="missing_token">候选遗漏金额占位符</option><option value="changed_amount">候选擅改金额</option><option value="refund_promise">候选擅自承诺退款</option><option value="policy_timeout">政策读取超时</option><option value="glossary_timeout">术语读取超时</option><option value="stale_source">源文版本变化</option></select></label><div class="actions"><button @click="run" :disabled="pending">{{ pending ? '核对中…' : '读取证据并生成英文草稿' }}</button><button class="quiet" @click="updateSource">模拟源文更新（当前 r{{ revision }}）</button></div></section>
  <div class="grid"><section class="panel"><h2>源文与受保护字段</h2><p class="source">{{ source.text }}</p><div class="masked"><small>给模拟翻译器的遮盖版</small><p>{{ masked() }}</p></div><p class="fine">⟦ORDER⟧ 和 ⟦AMOUNT⟧ 仅为本地教学占位符。真实服务须在服务端处理敏感信息。</p><h2 class="subhead">本轮只读证据</h2><p class="fine" v-if="!evidence">点击按钮后查看术语和政策来源。</p><template v-else><div class="evidence"><b>客服术语</b><template v-if="evidence.glossary.kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence.glossary.value.sourceId }}</code><p>after-sales request · manual review</p></template><span v-else class="error">{{ evidence.glossary.message }}</span></div><div class="evidence"><b>售后政策</b><template v-if="evidence.policy.kind === 'ok'"><span class="ok">已读取</span><code>{{ evidence.policy.value.sourceId }}</code><p>可引导申请；未批准退款。</p></template><span v-else class="error">{{ evidence.policy.message }}</span></div></template></section>
  <section class="panel"><div class="panel-head"><h2>英文回复草稿</h2><span v-if="assessment" class="badge" :class="assessment.state">{{ assessment.state }}</span></div><p class="fine" v-if="!assessment">尚未生成。固定模拟候选只在本地校验。</p><template v-else><p class="notice">{{ assessment.message }}</p><div v-if="assessment.draft" class="draft"><p lang="en">{{ assessment.draft }}</p><div class="sources"><span v-for="id in assessment.sourceIds" :key="id">{{ id }}</span></div><label class="review"><input type="checkbox" v-model="reviewed">人工已审阅译意（仅本地状态）</label></div><p v-else class="fine">候选未进入可审阅回复区。</p></template><p class="fine">✉︎ 没有发送接口 · 没有真实模型调用 · 不创建退款。</p></section></div><footer>固定虚构夹具 · Vue 3 + TypeScript · 结构检查不能替代人工翻译审阅</footer></main>`
}).mount('#app')
