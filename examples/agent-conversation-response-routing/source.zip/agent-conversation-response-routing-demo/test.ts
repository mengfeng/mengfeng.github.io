import assert from 'node:assert/strict'
import { createRouter, scopeKey, simulateReply } from './src/core'

const a = { customer: 'A', conversation: '1' }
const b = { customer: 'B', conversation: '1' }
const a2 = { customer: 'A', conversation: '2' }
let count = 0

function equal(actual: unknown, expected: unknown): void {
  assert.deepEqual(actual, expected)
  count++
}

const router = createRouter()
equal(scopeKey(a) === scopeKey(b), false)
equal(scopeKey(a) === scopeKey(a2), false)
const oldA = router.start(a)
const runB = router.start(b)
const secondConversation = router.start(a2)
equal(router.finish(runB, simulateReply(runB, 'ok', '客户 B 的草稿')), 'ready')
equal(router.finish(oldA, simulateReply(oldA, 'ok', '客户 A 的草稿')), 'ready')
equal(router.get(a), { status: 'ready', id: oldA.id, draft: '客户 A 的草稿' })
equal(router.get(b), { status: 'ready', id: runB.id, draft: '客户 B 的草稿' })
equal(router.get(a2), { status: 'pending', id: secondConversation.id })
equal(router.finish(secondConversation, simulateReply(secondConversation, 'tool_error', '')), 'tool_error')
equal(router.get(a2), { status: 'error', id: secondConversation.id, reason: 'tool_error' })
equal(router.finish(oldA, simulateReply(oldA, 'ok', '重复投递')), 'superseded')
equal(router.get(a), { status: 'ready', id: oldA.id, draft: '客户 A 的草稿' })

const first = router.start(a)
const latest = router.start(a)
equal(router.finish(latest, simulateReply(latest, 'ok', '新草稿')), 'ready')
equal(router.finish(first, simulateReply(first, 'tool_error', '')), 'superseded')
equal(router.get(a), { status: 'ready', id: latest.id, draft: '新草稿' })

const wrongScope = router.start(a)
equal(router.finish(wrongScope, simulateReply(wrongScope, 'wrong_scope', '未通过校验')), 'invalid_response')
equal(router.get(a), { status: 'error', id: wrongScope.id, reason: 'invalid_response' })
equal(router.get(b), { status: 'ready', id: runB.id, draft: '客户 B 的草稿' })
const badType = router.start(a)
equal(router.finish(badType, simulateReply(badType, 'malformed', '字段类型错误')), 'invalid_response')
const wrongId = router.start(a)
equal(router.finish(wrongId, { kind: 'ok', customer: 'A', conversation: '1', runId: -1, draft: '错误任务' }), 'invalid_response')

const prior = router.start(a)
router.resetWorkspace()
equal(router.get(a), undefined)
equal(router.get(b), undefined)
equal(router.get(a2), undefined)
const newWorkspaceRun = router.start(a)
equal(router.finish(prior, simulateReply(prior, 'ok', '已过期')), 'expired_workspace')
equal(router.get(a), { status: 'pending', id: newWorkspaceRun.id })
equal(router.finish(newWorkspaceRun, simulateReply(newWorkspaceRun, 'ok', '新工作区草稿')), 'ready')
equal(router.get(a), { status: 'ready', id: newWorkspaceRun.id, draft: '新工作区草稿' })
console.log(`${count} offline assertions passed`)
