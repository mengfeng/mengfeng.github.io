import { strict as assert } from 'node:assert'
import { test } from 'node:test'
import { evaluate } from './src/core'
import { scenarios } from './src/fixtures'

const expected = {
  conflict: 'conflict', ready: 'ready', missing: 'missing',
  stale: 'invalid', foreign: 'invalid', wrong: 'invalid', malformed: 'invalid',
}

for (const sample of scenarios) {
  test(sample.id, () => {
    assert.equal(evaluate(sample.snapshot, sample.suggestion).kind, expected[sample.id as keyof typeof expected])
    assert.equal(sample.snapshot.currentMm, 300)
  })
}
const consistent = scenarios[1]

test('比较所有有效资料，模型漏报冲突也必须拦截', () => {
  const { snapshot, suggestion } = scenarios[0]
  const result = evaluate(snapshot, suggestion)
  assert.equal(result.kind, 'conflict')
  assert.deepEqual(result.evidence.map(fact => fact.mm), [320, 340])
})

test('统一单位，只保留当前 SKU、版本下的有效资料', () => {
  const result = evaluate(consistent.snapshot, consistent.suggestion)
  assert.deepEqual(result.evidence.map(fact => fact.id), ['S2', 'Q2'])
  assert.deepEqual(result.evidence.map(fact => fact.mm), [320, 320])
  assert.equal(result.kind === 'ready' && result.proposedMm, 320)
})

test('同一证据重复提交时拒绝候选', () => {
  const raw = { snapshotId: 'ready', sku: 'LAMP-MINT', field: 'assembledHeight',
    heightMm: 320, evidenceIds: ['S2', 'S2'] }
  assert.equal(evaluate(consistent.snapshot, raw).kind, 'invalid')
})

test('候选需要结构和字段校验', () => {
  const suggestion = { snapshotId: 'ready', sku: 'LAMP-MINT', field: 'assembledHeight',
    heightMm: 320, evidenceIds: ['S2'] }
  for (const invalid of [undefined, null, { ...suggestion, field: 'width' },
    { ...suggestion, sku: 'LAMP-GRAY' }, { ...suggestion, evidenceIds: [] },
    { ...suggestion, heightMm: Number.NaN }]) {
    assert.equal(evaluate(consistent.snapshot, invalid).kind, 'invalid')
  }
})

test('工具快照有重复 ID 或无效高度时拒绝候选', () => {
  const { snapshot, suggestion } = consistent
  const first = snapshot.facts[0]
  for (const facts of [[first, first], [{ ...first, amount: -1 }], [{ ...first, amount: 1.24 }]]) {
    assert.equal(evaluate({ ...snapshot, facts }, suggestion).kind, 'invalid')
  }
})
