import { computed, createApp, ref, watch } from 'vue'
import { decide, initialSelection, mockAgentAnswer, readDemoTools, selectionKey, validateAnswer, type AnswerCheck, type Area, type ModelMode, type Scenario, type Selection, type ToolSnapshot } from './core'

const statusLabel = { tomorrow: '演示规则：可显示次日预计送达', unavailable: '演示规则：当前条件不支持次日送达', unknown: '演示规则：尚不能确认时效' } as const

createApp({
  setup() {
    const area = ref<Area>('A')
    const scenario = ref<Scenario>('ready')
    const mode = ref<ModelMode>('bounded')
    const snapshot = ref<ToolSnapshot | null>(null)
    const check = ref<AnswerCheck | null>(null)
    const message = ref('先查询两项演示数据，再验证模拟 Agent 的回答。')
    const current = (): Selection => ({ productId: 'SKU-01', area: area.value, scenario: scenario.value })
    const query = () => { snapshot.value = readDemoTools(current()); check.value = null; message.value = '两项只读演示工具已返回；请核验回答。' }
    const answer = () => {
      if (!snapshot.value) { message.value = '请先查询演示数据。'; return }
      check.value = validateAnswer(mockAgentAnswer(snapshot.value, mode.value), snapshot.value, current())
      message.value = check.value.ok ? statusLabel[check.value.verdict] : check.value.error
    }
    const reset = () => { area.value = initialSelection.area; scenario.value = initialSelection.scenario; mode.value = 'bounded'; snapshot.value = null; check.value = null; message.value = '已重置演示。' }
    const isCurrent = computed(() => snapshot.value?.key === selectionKey(current()))
    const ruleDecision = computed(() => snapshot.value && isCurrent.value ? decide(snapshot.value) : null)
    watch([area, scenario], () => { check.value = null; message.value = '条件已改变，请重新查询。' })
    watch(mode, () => { check.value = null })
    return { area, scenario, mode, snapshot, check, message, query, answer, reset, isCurrent, ruleDecision, statusLabel }
  },
  template: `
  <main class="shell">
    <header class="hero"><div class="eyebrow">AGENT / DELIVERY LAB 08</div><h1>能不能明天送到？先看证据</h1><p>用两项只读工具核对库存与配送范围，再决定页面能说到哪一步。</p></header>
    <section class="panel controls" aria-label="演示条件"><div class="section-head"><h2>演示条件</h2><button class="ghost" type="button" @click="reset">重置</button></div>
      <div class="form-grid"><label>区域 <select v-model="area"><option value="A">演示区域 A</option><option value="B">演示区域 B</option></select></label>
      <label>工具结果 <select v-model="scenario"><option value="ready">库存与配送都可用</option><option value="noStock">库存为零</option><option value="outside">配送未覆盖</option><option value="stockTimeout">库存查询超时</option><option value="routeTimeout">配送查询超时</option><option value="stale">结果已过期</option></select></label>
      <label>模拟 Agent 输出 <select v-model="mode"><option value="bounded">按证据回答</option><option value="overpromise">虚构证据并承诺</option></select></label></div>
      <p class="muted">固定演示时间：2026-11-08 10:00（北京时间）。商品、库存和配送区域均为虚构数据。</p>
      <div class="actions"><button type="button" @click="query">① 查询库存和配送</button><button type="button" @click="answer">② 验证模拟回答</button></div>
    </section>
    <div class="layout"><section class="panel" aria-label="工具结果"><h2>只读工具结果</h2><p v-if="!snapshot" class="muted">尚未查询。</p><template v-else>
      <div class="tool-card"><strong>库存工具</strong><span>{{ snapshot.inventory.sourceId }}</span><p v-if="snapshot.inventory.status === 'ok'">库存 {{ snapshot.inventory.quantity }} 件 · 更新时间 {{ snapshot.inventory.checkedAt }}</p><p v-else class="warning">查询超时，数量未知</p></div>
      <div class="tool-card"><strong>配送工具</strong><span>{{ snapshot.delivery.sourceId }}</span><p v-if="snapshot.delivery.status === 'ok'">{{ snapshot.delivery.covered ? '范围覆盖' : '范围未覆盖' }} · 最早日期 {{ snapshot.delivery.earliestDate || '未知' }} · 更新时间 {{ snapshot.delivery.checkedAt }}</p><p v-else class="warning">查询超时，覆盖范围未知</p></div>
      <p class="muted">本次固定调用 2 项本地函数。切换区域或场景后，旧结果会在验证时被拒绝。</p></template></section>
      <section class="panel" aria-label="回答核验"><h2>回答核验</h2><p role="status" class="status">{{ message }}</p>
      <p v-if="snapshot && !isCurrent" class="warning">当前条件已变化，所示工具结果属于旧查询，请重新查询。</p>
      <p v-if="ruleDecision" class="rule">{{ statusLabel[ruleDecision.verdict] }}：{{ ruleDecision.reason }}</p>
      <p v-if="check?.ok" class="success">已接受模拟回答：{{ check.reason }}<br>证据：{{ check.evidence.join(' + ') }}</p>
      <p v-else-if="check" class="error">模拟回答被拒绝：{{ check.error }}<br>页面保留规则结论：{{ statusLabel[check.fallback.verdict] }}</p>
      <p v-else class="muted">Agent 文案只是候选；页面根据工具结果独立计算可显示的结论。</p></section></div>
    <footer>本页无真实模型、真实库存、真实配送服务或订单写入；“次日”仅对应固定演示日期 2026-11-09，不构成配送承诺。</footer>
  </main>`
}).mount('#app')
