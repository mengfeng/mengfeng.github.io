import { createApp, computed, ref } from 'vue'
import { fixtures, replay, type Result } from './core'

createApp({
  setup() {
    const candidate = ref<'safe' | 'faulty'>('safe')
    const results = ref<Result[]>([])
    const selected = ref<string | null>(null)
    const passed = computed(() => results.value.filter(row => row.passed).length)
    const active = computed(() => results.value.find(row => row.id === selected.value))
    const run = () => { results.value = replay(candidate.value); selected.value = results.value[0]?.id ?? null }
    return { candidate, results, selected, passed, active, fixtures, run }
  },
  template: `
    <main class="shell">
      <header class="hero"><div class="eyebrow">AGENT / REPLAY LAB 06</div><h1>发布前，先回放一次</h1><p>同一句“答对了”，可能藏着越权调用。这里检查完整工具轨迹，而不只看最终文案。</p></header>
      <section class="panel controls" aria-label="回放控制">
        <label>候选版本 <select v-model="candidate"><option value="safe">基准版本：预期全通过</option><option value="faulty">故障版本：暴露六类问题</option></select></label>
        <button type="button" @click="run">运行离线回放</button>
        <span class="muted">固定演示轨迹 · 无模型调用 · 无真实业务写入</span>
      </section>
      <div v-if="results.length" class="summary" role="status">通过 {{ passed }} / {{ results.length }}　·　失败 {{ results.length - passed }}</div>
      <div class="layout">
        <section class="panel cases" aria-label="评测用例"><h2>六个业务场景</h2>
          <button v-for="f in fixtures" :key="f.id" type="button" class="case" :class="{ chosen: selected === f.id }" @click="selected=f.id">
            <span><strong>{{ f.title }}</strong><small>{{ f.userInput }}</small></span>
            <b v-if="results.length" :class="results.find(r=>r.id===f.id)?.passed ? 'pass' : 'fail'">{{ results.find(r=>r.id===f.id)?.passed ? '通过' : '失败' }}</b>
          </button>
        </section>
        <section class="panel detail" aria-label="轨迹详情"><h2>调用轨迹与判定</h2>
          <div v-if="active"><p class="muted">示例回答</p><blockquote>{{ active.trace.final }}</blockquote><p class="muted">工具调用</p>
            <ol v-if="active.trace.calls.length"><li v-for="(call, i) in active.trace.calls" :key="i"><code>{{ call.name }}</code> · {{ JSON.stringify(call.args) }} · {{ call.outcome }}</li></ol>
            <p v-else class="empty">没有工具调用</p><p class="muted">判定依据</p>
            <p v-if="active.passed" class="pass">调用范围、顺序、参数、结果和文案均符合此用例。</p>
            <ul v-else class="fail"><li v-for="(reason, i) in active.reasons" :key="i">{{ reason }}</li></ul>
          </div><p v-else class="empty">点击“运行离线回放”，再选择一个场景查看证据。</p>
        </section>
      </div><footer>所有商品、订单、地址和工具响应都是虚构数据。评测器检查固定轨迹，不代表真实模型效果。</footer>
    </main>`
}).mount('#app')
