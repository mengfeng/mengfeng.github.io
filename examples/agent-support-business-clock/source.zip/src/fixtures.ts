import type { Interval, Snapshot } from './core'

const time = (day: number, clock: string) =>
  Date.parse(`2026-11-${day}T${clock}:00+08:00`)
const shift = (day: number, start: string, end: string): Interval =>
  ({ start: time(day, start), end: time(day, end) })

const coverage = { start: time(23, '00:00'), end: time(25, '00:00') }
const shifts = [shift(23, '13:00', '18:00'), shift(24, '09:00', '12:00'), shift(24, '13:00', '18:00')]
const standard = {
  ticketId: 'CASE-73',
  calendarId: 'CN-DEMO-R4',
  openedAt: time(23, '17:40'),
  asOf: time(24, '09:20'),
  budgetMinutes: 60,
  coverage,
  shifts,
}

function scenario(id: string, label: string, elapsedMinutes: number, state = 'remaining',
  changes: Partial<Snapshot> = {}, mockChanges: Record<string, unknown> = {}) {
  const snapshot: Snapshot = { ...standard, ...changes, id }
  const candidate: unknown = { snapshotId: id, ticketId: snapshot.ticketId, elapsedMinutes, state, ...mockChanges }
  return { id, label, snapshot, candidate }
}

export const scenarios = [
  scenario('overnight', '跨夜工单', 40),
  scenario('lunch', '午休暂停计时', 25, 'remaining', { openedAt: time(24, '11:50'), asOf: time(24, '13:15') }),
  scenario('overlap', '两份班次相互重叠', 40, 'remaining', { shifts: [shift(24, '09:05', '11:30'), ...shifts] }),
  scenario('exact', '刚好用完时限', 60, 'at-limit', { asOf: time(24, '09:40') }),
  scenario('late', '已超过时限', 75, 'over-limit', { asOf: time(24, '09:55') }),
  scenario('gap', '排班覆盖不足', 40, 'remaining', { coverage: { ...coverage, end: time(24, '00:00') } }),
  scenario('stale', '模型引用旧快照', 40, 'remaining', {}, { snapshotId: 'old-snapshot' }),
  scenario('wrong', '模型错用自然分钟', 940),
  scenario('closed', '整段时间都在休息', 0, 'remaining', { openedAt: time(23, '20:00'), asOf: time(24, '08:30') }),
]
