import { computed, createApp, nextTick, ref } from 'vue'
import { resolveCurrent, resolveRecommendation, type Selection } from './core'
import { colors, initial, scenarios } from './fixtures'

const labels = {
  available: '当前快照有货', 'sold-out': '当前快照售罄', unknown: '库存待确认',
  'not-offered': '未配置这个组合', conflict: '同一组合有重复记录',
}

createApp({
  setup() {
    const chosenScenario = ref(scenarios[0].id)
    const selection = ref<Selection>({ ...initial })
    const allowColorChange = ref(false)
    const stockStatus = ref<HTMLElement | null>(null)
    const active = computed(() => scenarios.find(item => item.id === chosenScenario.value) ?? scenarios[0])
    const current = computed(() => resolveCurrent(active.value.snapshot, selection.value))
    const suggestion = computed(() =>
      resolveRecommendation(active.value.snapshot, selection.value, allowColorChange.value, active.value.candidate))
    const stockRows = computed(() => (['linen', 'charcoal'] as const).map(color => ({
      name: colors[color],
      entries: (['S', 'M'] as const).map(size => {
        const selected: Selection = { color, size }
        return { size, status: resolveCurrent(active.value.snapshot, selected).kind }
      }),
    })))

    function resetSelection() {
      selection.value = { ...initial }
      allowColorChange.value = false
    }

    async function adoptAlternative() {
      const decision = suggestion.value
      if (decision.kind === 'ready') {
        selection.value = { color: decision.variant.color, size: decision.variant.size }
        await nextTick()
        stockStatus.value?.focus()
      }
    }

    return { chosenScenario, selection, allowColorChange, stockStatus, active, current, suggestion, stockRows,
      labels, colors, scenarios, resetSelection, adoptAlternative }
  },
  template: `
    <main>
      <header>
        <h1>棉麻衬衫 · 规格核对</h1>
        <p>按颜色和尺码一起查库存。虚构商品与固定 Agent 候选。</p>
      </header>
      <div class="scenario">
        <label for="scenario">演示场景</label>
        <select id="scenario" v-model="chosenScenario" @change="resetSelection">
          <option v-for="item in scenarios" :key="item.id" :value="item.id">{{ item.label }}</option>
        </select>
      </div>
      <div class="workspace">
        <section class="selection" aria-labelledby="choose-title">
          <h2 id="choose-title">我的选择</h2>
          <div class="fields">
            <label for="color">颜色
              <select id="color" v-model="selection.color"><option value="linen">燕麦色</option><option value="charcoal">炭灰色</option></select>
            </label>
            <label for="size">尺码
              <select id="size" v-model="selection.size"><option value="S">S</option><option value="M">M</option></select>
            </label>
          </div>
          <label class="permission"><input v-model="allowColorChange" type="checkbox"> 允许建议其他颜色，尺码保持不变</label>
          <div role="status" class="status" ref="stockStatus" tabindex="-1" :data-stock="current.kind">
            <span>{{ colors[selection.color] }} / {{ selection.size }}</span>
            <strong>{{ labels[current.kind] }}</strong>
          </div>
          <div class="proposal" v-if="suggestion.kind === 'ready'" data-testid="proposal">
            <p>备选 <strong>{{ colors[suggestion.variant.color] }} / {{ suggestion.variant.size }}</strong></p>
            <p>只更换颜色，本次查询显示有货。</p>
            <button type="button" @click="adoptAlternative">切换到 {{ colors[suggestion.variant.color] }} / {{ suggestion.variant.size }}</button>
          </div>
          <p v-else-if="suggestion.kind === 'rejected'" class="notice" data-testid="rejected">
            当前备选未通过核对，已保留你的选择。
          </p>
          <p v-else-if="current.kind === 'unknown'" class="notice" data-testid="unknown">
            请重新查询这一组合的库存，再决定是否需要备选。
          </p>
        </section>

        <section aria-labelledby="inventory-title">
          <h2 id="inventory-title">库存快照</h2>
          <table>
            <caption>{{ active.snapshot.complete ? '完整规格清单' : '规格清单尚未返回完整' }}</caption>
            <thead><tr><th scope="col">颜色</th><th scope="col">S</th><th scope="col">M</th></tr></thead>
            <tbody>
              <tr v-for="row in stockRows" :key="row.name">
                <th scope="row">{{ row.name }}</th>
                <td v-for="entry in row.entries" :key="entry.size" :data-stock="entry.status">{{ labels[entry.status] }}</td>
              </tr>
            </tbody>
          </table>
          <details :key="chosenScenario">
            <summary>查看模拟 Agent 候选</summary>
            <pre>{{ JSON.stringify(active.candidate, null, 2) }}</pre>
          </details>
        </section>
      </div>
    </main>
  `
}).mount('#app')
